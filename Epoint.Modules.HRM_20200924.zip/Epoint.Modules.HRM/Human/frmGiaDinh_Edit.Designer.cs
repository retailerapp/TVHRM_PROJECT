﻿namespace Epoint.Modules.HRM
{
    partial class frmGiaDinh_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGiaDinh_Edit));
            this.lbtTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.lblGhi_Chu = new Epoint.Systems.Controls.lblControl();
            this.lblNam_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblLoai_QHGD = new Epoint.Systems.Controls.lblControl();
            this.txtGhi_Chu = new Epoint.Systems.Controls.txtTextBox();
            this.lblHo_Ten = new Epoint.Systems.Controls.lblControl();
            this.txtNam_Sinh = new Epoint.Systems.Controls.numUpDown();
            this.txtLoai_QHGD = new Epoint.Systems.Controls.cboControl();
            this.txtHo_Ten = new Epoint.Systems.Controls.txtTextBox();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            ((System.ComponentModel.ISupportInitialize)(this.txtNam_Sinh)).BeginInit();
            this.SuspendLayout();
            // 
            // lbtTen_CbNv
            // 
            this.lbtTen_CbNv.AutoEllipsis = true;
            this.lbtTen_CbNv.AutoSize = true;
            this.lbtTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_CbNv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_CbNv.Location = new System.Drawing.Point(252, 23);
            this.lbtTen_CbNv.Name = "lbtTen_CbNv";
            this.lbtTen_CbNv.Size = new System.Drawing.Size(59, 13);
            this.lbtTen_CbNv.TabIndex = 122;
            this.lbtTen_CbNv.Text = "Ten_CbNv";
            this.lbtTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(437, 168);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(169, 33);
            this.btgAccept.TabIndex = 5;
            // 
            // lblGhi_Chu
            // 
            this.lblGhi_Chu.AutoEllipsis = true;
            this.lblGhi_Chu.AutoSize = true;
            this.lblGhi_Chu.BackColor = System.Drawing.Color.Transparent;
            this.lblGhi_Chu.Location = new System.Drawing.Point(18, 116);
            this.lblGhi_Chu.Name = "lblGhi_Chu";
            this.lblGhi_Chu.Size = new System.Drawing.Size(44, 13);
            this.lblGhi_Chu.TabIndex = 118;
            this.lblGhi_Chu.Tag = "Ghi_Chu";
            this.lblGhi_Chu.Text = "Ghi chú";
            this.lblGhi_Chu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNam_Sinh
            // 
            this.lblNam_Sinh.AutoEllipsis = true;
            this.lblNam_Sinh.AutoSize = true;
            this.lblNam_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNam_Sinh.Location = new System.Drawing.Point(18, 92);
            this.lblNam_Sinh.Name = "lblNam_Sinh";
            this.lblNam_Sinh.Size = new System.Drawing.Size(51, 13);
            this.lblNam_Sinh.TabIndex = 121;
            this.lblNam_Sinh.Tag = "Nam_Sinh";
            this.lblNam_Sinh.Text = "Năm sinh";
            this.lblNam_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLoai_QHGD
            // 
            this.lblLoai_QHGD.AutoEllipsis = true;
            this.lblLoai_QHGD.AutoSize = true;
            this.lblLoai_QHGD.BackColor = System.Drawing.Color.Transparent;
            this.lblLoai_QHGD.Location = new System.Drawing.Point(18, 68);
            this.lblLoai_QHGD.Name = "lblLoai_QHGD";
            this.lblLoai_QHGD.Size = new System.Drawing.Size(69, 13);
            this.lblLoai_QHGD.TabIndex = 119;
            this.lblLoai_QHGD.Tag = "Loai_QHGD";
            this.lblLoai_QHGD.Text = "Loại quan hệ";
            this.lblLoai_QHGD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGhi_Chu
            // 
            this.txtGhi_Chu.bEnabled = true;
            this.txtGhi_Chu.bIsLookup = false;
            this.txtGhi_Chu.bReadOnly = false;
            this.txtGhi_Chu.bRequire = false;
            this.txtGhi_Chu.KeyFilter = "";
            this.txtGhi_Chu.Location = new System.Drawing.Point(127, 112);
            this.txtGhi_Chu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtGhi_Chu.Multiline = true;
            this.txtGhi_Chu.Name = "txtGhi_Chu";
            this.txtGhi_Chu.Size = new System.Drawing.Size(479, 40);
            this.txtGhi_Chu.TabIndex = 4;
            this.txtGhi_Chu.UseAutoFilter = false;
            // 
            // lblHo_Ten
            // 
            this.lblHo_Ten.AutoEllipsis = true;
            this.lblHo_Ten.AutoSize = true;
            this.lblHo_Ten.BackColor = System.Drawing.Color.Transparent;
            this.lblHo_Ten.Location = new System.Drawing.Point(18, 45);
            this.lblHo_Ten.Name = "lblHo_Ten";
            this.lblHo_Ten.Size = new System.Drawing.Size(39, 13);
            this.lblHo_Ten.TabIndex = 120;
            this.lblHo_Ten.Tag = "Ho_Ten";
            this.lblHo_Ten.Text = "Họ tên";
            this.lblHo_Ten.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNam_Sinh
            // 
            this.txtNam_Sinh.Location = new System.Drawing.Point(127, 89);
            this.txtNam_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNam_Sinh.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtNam_Sinh.Name = "txtNam_Sinh";
            this.txtNam_Sinh.Size = new System.Drawing.Size(71, 20);
            this.txtNam_Sinh.TabIndex = 3;
            // 
            // txtLoai_QHGD
            // 
            this.txtLoai_QHGD.InitValue = null;
            this.txtLoai_QHGD.Items.AddRange(new object[] {
            "Ông",
            "Bà",
            "Cha",
            "Mẹ",
            "Anh",
            "Chị",
            "Con",
            "Cháu"});
            this.txtLoai_QHGD.Location = new System.Drawing.Point(127, 65);
            this.txtLoai_QHGD.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtLoai_QHGD.Name = "txtLoai_QHGD";
            this.txtLoai_QHGD.Size = new System.Drawing.Size(140, 21);
            this.txtLoai_QHGD.strValueList = null;
            this.txtLoai_QHGD.TabIndex = 2;
            this.txtLoai_QHGD.UseAutoComplete = false;
            this.txtLoai_QHGD.UseBindingValue = false;
            // 
            // txtHo_Ten
            // 
            this.txtHo_Ten.bEnabled = true;
            this.txtHo_Ten.bIsLookup = false;
            this.txtHo_Ten.bReadOnly = false;
            this.txtHo_Ten.bRequire = false;
            this.txtHo_Ten.KeyFilter = "";
            this.txtHo_Ten.Location = new System.Drawing.Point(127, 42);
            this.txtHo_Ten.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtHo_Ten.Name = "txtHo_Ten";
            this.txtHo_Ten.Size = new System.Drawing.Size(479, 20);
            this.txtHo_Ten.TabIndex = 1;
            this.txtHo_Ten.UseAutoFilter = false;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(18, 22);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(72, 13);
            this.lblMa_CbNv.TabIndex = 117;
            this.lblMa_CbNv.Tag = "Ma_CbNv";
            this.lblMa_CbNv.Text = "Mã nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.Location = new System.Drawing.Point(127, 19);
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // frmGiaDinh_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 216);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.lbtTen_CbNv);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lblGhi_Chu);
            this.Controls.Add(this.lblNam_Sinh);
            this.Controls.Add(this.lblLoai_QHGD);
            this.Controls.Add(this.txtGhi_Chu);
            this.Controls.Add(this.lblHo_Ten);
            this.Controls.Add(this.txtNam_Sinh);
            this.Controls.Add(this.txtLoai_QHGD);
            this.Controls.Add(this.txtHo_Ten);
            this.Controls.Add(this.lblMa_CbNv);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmGiaDinh_Edit";
            this.Text = "frmGiaDinh_Edit";
            ((System.ComponentModel.ISupportInitialize)(this.txtNam_Sinh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private Epoint.Systems.Controls.lblControl lbtTen_CbNv;
		public Epoint.Systems.Customizes.btgAccept btgAccept;
		private Epoint.Systems.Controls.lblControl lblGhi_Chu;
		private Epoint.Systems.Controls.lblControl lblNam_Sinh;
		private Epoint.Systems.Controls.lblControl lblLoai_QHGD;
		private Epoint.Systems.Controls.txtTextBox txtGhi_Chu;
		private Epoint.Systems.Controls.lblControl lblHo_Ten;
		private Epoint.Systems.Controls.numUpDown txtNam_Sinh;
		private Epoint.Systems.Controls.cboControl txtLoai_QHGD;
		private Epoint.Systems.Controls.txtTextBox txtHo_Ten;
        private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_CbNv;

	}
}