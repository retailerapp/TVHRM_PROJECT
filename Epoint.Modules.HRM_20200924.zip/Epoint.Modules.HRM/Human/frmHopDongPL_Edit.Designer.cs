﻿namespace Epoint.Modules.HRM
{
    partial class frmHopDongPL_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHopDongPL_Edit));
            this.dteNgay_End = new Epoint.Systems.Controls.txtDateTime();
            this.dteNgay_Ky = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_End = new Epoint.Systems.Controls.lblControl();
            this.dteNgay_Begin = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Begin = new Epoint.Systems.Controls.lblControl();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.lblNguoi_Ky = new Epoint.Systems.Controls.lblControl();
            this.lblNgay_Ky = new Epoint.Systems.Controls.lblControl();
            this.lblNoi_Dung = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Pl = new Epoint.Systems.Controls.lblControl();
            this.txtSo_Pl = new Epoint.Systems.Controls.txtTextBox();
            this.txtNguoi_Ky = new Epoint.Systems.Controls.txtTextBox();
            this.txtNoi_Dung = new Epoint.Systems.Controls.txtTextBox();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            this.lblTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtTen_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_Hd = new Epoint.Systems.Controls.txtTextBox();
            this.SuspendLayout();
            // 
            // dteNgay_End
            // 
            this.dteNgay_End.bAllowEmpty = true;
            this.dteNgay_End.bRequire = false;
            this.dteNgay_End.bSelectOnFocus = false;
            this.dteNgay_End.bShowDateTimePicker = true;
            this.dteNgay_End.Culture = new System.Globalization.CultureInfo("fr-FR");
            this.dteNgay_End.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_End.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_End.Location = new System.Drawing.Point(154, 206);
            this.dteNgay_End.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.dteNgay_End.Mask = "00/00/0000";
            this.dteNgay_End.Name = "dteNgay_End";
            this.dteNgay_End.Size = new System.Drawing.Size(74, 20);
            this.dteNgay_End.TabIndex = 8;
            // 
            // dteNgay_Ky
            // 
            this.dteNgay_Ky.bAllowEmpty = true;
            this.dteNgay_Ky.bRequire = false;
            this.dteNgay_Ky.bSelectOnFocus = false;
            this.dteNgay_Ky.bShowDateTimePicker = true;
            this.dteNgay_Ky.Culture = new System.Globalization.CultureInfo("fr-FR");
            this.dteNgay_Ky.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Ky.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Ky.Location = new System.Drawing.Point(154, 160);
            this.dteNgay_Ky.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.dteNgay_Ky.Mask = "00/00/0000";
            this.dteNgay_Ky.Name = "dteNgay_Ky";
            this.dteNgay_Ky.Size = new System.Drawing.Size(74, 20);
            this.dteNgay_Ky.TabIndex = 5;
            // 
            // lblNgay_End
            // 
            this.lblNgay_End.AutoEllipsis = true;
            this.lblNgay_End.AutoSize = true;
            this.lblNgay_End.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_End.Location = new System.Drawing.Point(28, 209);
            this.lblNgay_End.Name = "lblNgay_End";
            this.lblNgay_End.Size = new System.Drawing.Size(74, 13);
            this.lblNgay_End.TabIndex = 136;
            this.lblNgay_End.Tag = "Ngay_End";
            this.lblNgay_End.Text = "Ngày kết thúc";
            this.lblNgay_End.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dteNgay_Begin
            // 
            this.dteNgay_Begin.bAllowEmpty = true;
            this.dteNgay_Begin.bRequire = false;
            this.dteNgay_Begin.bSelectOnFocus = false;
            this.dteNgay_Begin.bShowDateTimePicker = true;
            this.dteNgay_Begin.Culture = new System.Globalization.CultureInfo("fr-FR");
            this.dteNgay_Begin.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Begin.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Begin.Location = new System.Drawing.Point(154, 183);
            this.dteNgay_Begin.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.dteNgay_Begin.Mask = "00/00/0000";
            this.dteNgay_Begin.Name = "dteNgay_Begin";
            this.dteNgay_Begin.Size = new System.Drawing.Size(74, 20);
            this.dteNgay_Begin.TabIndex = 6;
            // 
            // lblNgay_Begin
            // 
            this.lblNgay_Begin.AutoEllipsis = true;
            this.lblNgay_Begin.AutoSize = true;
            this.lblNgay_Begin.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Begin.Location = new System.Drawing.Point(28, 186);
            this.lblNgay_Begin.Name = "lblNgay_Begin";
            this.lblNgay_Begin.Size = new System.Drawing.Size(72, 13);
            this.lblNgay_Begin.TabIndex = 133;
            this.lblNgay_Begin.Tag = "Ngay_Begin";
            this.lblNgay_Begin.Text = "Ngày bắt đầu";
            this.lblNgay_Begin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(492, 249);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(169, 34);
            this.btgAccept.TabIndex = 9;
            // 
            // lblNguoi_Ky
            // 
            this.lblNguoi_Ky.AutoEllipsis = true;
            this.lblNguoi_Ky.AutoSize = true;
            this.lblNguoi_Ky.BackColor = System.Drawing.Color.Transparent;
            this.lblNguoi_Ky.Location = new System.Drawing.Point(28, 140);
            this.lblNguoi_Ky.Name = "lblNguoi_Ky";
            this.lblNguoi_Ky.Size = new System.Drawing.Size(49, 13);
            this.lblNguoi_Ky.TabIndex = 131;
            this.lblNguoi_Ky.Tag = "Nguoi_Ky";
            this.lblNguoi_Ky.Text = "Người ký";
            this.lblNguoi_Ky.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNgay_Ky
            // 
            this.lblNgay_Ky.AutoEllipsis = true;
            this.lblNgay_Ky.AutoSize = true;
            this.lblNgay_Ky.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Ky.Location = new System.Drawing.Point(28, 163);
            this.lblNgay_Ky.Name = "lblNgay_Ky";
            this.lblNgay_Ky.Size = new System.Drawing.Size(46, 13);
            this.lblNgay_Ky.TabIndex = 125;
            this.lblNgay_Ky.Tag = "Ngay_Ky";
            this.lblNgay_Ky.Text = "Ngày ký";
            this.lblNgay_Ky.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNoi_Dung
            // 
            this.lblNoi_Dung.AutoEllipsis = true;
            this.lblNoi_Dung.AutoSize = true;
            this.lblNoi_Dung.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Dung.Location = new System.Drawing.Point(28, 89);
            this.lblNoi_Dung.Name = "lblNoi_Dung";
            this.lblNoi_Dung.Size = new System.Drawing.Size(99, 13);
            this.lblNoi_Dung.TabIndex = 126;
            this.lblNoi_Dung.Tag = "Noi_Dung";
            this.lblNoi_Dung.Text = "Nội dung hợp đồng";
            this.lblNoi_Dung.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Pl
            // 
            this.lblSo_Pl.AutoEllipsis = true;
            this.lblSo_Pl.AutoSize = true;
            this.lblSo_Pl.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Pl.Location = new System.Drawing.Point(28, 20);
            this.lblSo_Pl.Name = "lblSo_Pl";
            this.lblSo_Pl.Size = new System.Drawing.Size(85, 13);
            this.lblSo_Pl.TabIndex = 127;
            this.lblSo_Pl.Tag = "So_Pl";
            this.lblSo_Pl.Text = "Số PL hợp đồng";
            this.lblSo_Pl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSo_Pl
            // 
            this.txtSo_Pl.bEnabled = true;
            this.txtSo_Pl.bIsLookup = false;
            this.txtSo_Pl.bReadOnly = false;
            this.txtSo_Pl.bRequire = false;
            this.txtSo_Pl.KeyFilter = "";
            this.txtSo_Pl.Location = new System.Drawing.Point(154, 17);
            this.txtSo_Pl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Pl.Name = "txtSo_Pl";
            this.txtSo_Pl.Size = new System.Drawing.Size(164, 20);
            this.txtSo_Pl.TabIndex = 0;
            this.txtSo_Pl.UseAutoFilter = false;
            // 
            // txtNguoi_Ky
            // 
            this.txtNguoi_Ky.bEnabled = true;
            this.txtNguoi_Ky.bIsLookup = false;
            this.txtNguoi_Ky.bReadOnly = false;
            this.txtNguoi_Ky.bRequire = false;
            this.txtNguoi_Ky.KeyFilter = "";
            this.txtNguoi_Ky.Location = new System.Drawing.Point(154, 137);
            this.txtNguoi_Ky.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNguoi_Ky.Name = "txtNguoi_Ky";
            this.txtNguoi_Ky.Size = new System.Drawing.Size(507, 20);
            this.txtNguoi_Ky.TabIndex = 4;
            this.txtNguoi_Ky.UseAutoFilter = false;
            // 
            // txtNoi_Dung
            // 
            this.txtNoi_Dung.bEnabled = true;
            this.txtNoi_Dung.bIsLookup = false;
            this.txtNoi_Dung.bReadOnly = false;
            this.txtNoi_Dung.bRequire = false;
            this.txtNoi_Dung.KeyFilter = "";
            this.txtNoi_Dung.Location = new System.Drawing.Point(154, 86);
            this.txtNoi_Dung.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Dung.Multiline = true;
            this.txtNoi_Dung.Name = "txtNoi_Dung";
            this.txtNoi_Dung.Size = new System.Drawing.Size(507, 48);
            this.txtNoi_Dung.TabIndex = 3;
            this.txtNoi_Dung.UseAutoFilter = false;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(30, 43);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(72, 13);
            this.lblMa_CbNv.TabIndex = 122;
            this.lblMa_CbNv.Tag = "Ma_CbNv";
            this.lblMa_CbNv.Text = "Mã nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.CtrlDepend = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_CbNv.ListFilter = new string[0];
            this.txtMa_CbNv.Location = new System.Drawing.Point(154, 40);
            this.txtMa_CbNv.LookupKeyFilter = "";
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(164, 20);
            this.txtMa_CbNv.TabIndex = 1;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // lblTen_CbNv
            // 
            this.lblTen_CbNv.AutoEllipsis = true;
            this.lblTen_CbNv.AutoSize = true;
            this.lblTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblTen_CbNv.Location = new System.Drawing.Point(28, 66);
            this.lblTen_CbNv.Name = "lblTen_CbNv";
            this.lblTen_CbNv.Size = new System.Drawing.Size(76, 13);
            this.lblTen_CbNv.TabIndex = 151;
            this.lblTen_CbNv.Tag = "Ten_CbNv";
            this.lblTen_CbNv.Text = "Tên nhân viên";
            this.lblTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTen_CbNv
            // 
            this.txtTen_CbNv.bEnabled = true;
            this.txtTen_CbNv.bIsLookup = false;
            this.txtTen_CbNv.bReadOnly = false;
            this.txtTen_CbNv.bRequire = false;
            this.txtTen_CbNv.KeyFilter = "";
            this.txtTen_CbNv.Location = new System.Drawing.Point(154, 63);
            this.txtTen_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTen_CbNv.Name = "txtTen_CbNv";
            this.txtTen_CbNv.Size = new System.Drawing.Size(507, 20);
            this.txtTen_CbNv.TabIndex = 2;
            this.txtTen_CbNv.UseAutoFilter = false;
            // 
            // txtSo_Hd
            // 
            this.txtSo_Hd.bEnabled = true;
            this.txtSo_Hd.bIsLookup = false;
            this.txtSo_Hd.bReadOnly = false;
            this.txtSo_Hd.bRequire = false;
            this.txtSo_Hd.KeyFilter = "";
            this.txtSo_Hd.Location = new System.Drawing.Point(345, 17);
            this.txtSo_Hd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Hd.Name = "txtSo_Hd";
            this.txtSo_Hd.Size = new System.Drawing.Size(164, 20);
            this.txtSo_Hd.TabIndex = 0;
            this.txtSo_Hd.UseAutoFilter = false;
            // 
            // frmHopDongPL_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 296);
            this.Controls.Add(this.lblTen_CbNv);
            this.Controls.Add(this.txtTen_CbNv);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.dteNgay_End);
            this.Controls.Add(this.dteNgay_Ky);
            this.Controls.Add(this.lblNgay_End);
            this.Controls.Add(this.dteNgay_Begin);
            this.Controls.Add(this.lblNgay_Begin);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lblNguoi_Ky);
            this.Controls.Add(this.lblNgay_Ky);
            this.Controls.Add(this.lblNoi_Dung);
            this.Controls.Add(this.lblSo_Pl);
            this.Controls.Add(this.txtSo_Hd);
            this.Controls.Add(this.txtSo_Pl);
            this.Controls.Add(this.txtNguoi_Ky);
            this.Controls.Add(this.txtNoi_Dung);
            this.Controls.Add(this.lblMa_CbNv);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmHopDongPL_Edit";
            this.Text = "frmHopDongPL_Edit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Epoint.Systems.Controls.txtDateTime dteNgay_End;
        private Epoint.Systems.Controls.txtDateTime dteNgay_Ky;
		private Epoint.Systems.Controls.lblControl lblNgay_End;
        private Epoint.Systems.Controls.txtDateTime dteNgay_Begin;
		private Epoint.Systems.Controls.lblControl lblNgay_Begin;
		public Epoint.Systems.Customizes.btgAccept btgAccept;
        private Epoint.Systems.Controls.lblControl lblNguoi_Ky;
		private Epoint.Systems.Controls.lblControl lblNgay_Ky;
		private Epoint.Systems.Controls.lblControl lblNoi_Dung;
		private Epoint.Systems.Controls.lblControl lblSo_Pl;
        private Epoint.Systems.Controls.txtTextBox txtSo_Pl;
        private Epoint.Systems.Controls.txtTextBox txtNguoi_Ky;
		private Epoint.Systems.Controls.txtTextBox txtNoi_Dung;
        private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_CbNv;
        private Systems.Controls.lblControl lblTen_CbNv;
        private Systems.Controls.txtTextBox txtTen_CbNv;
        private Systems.Controls.txtTextBox txtSo_Hd;
    }
}