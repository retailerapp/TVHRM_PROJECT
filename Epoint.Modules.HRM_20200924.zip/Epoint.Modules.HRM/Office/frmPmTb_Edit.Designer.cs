namespace Epoint.Modules.HRM
{
	partial class frmPmTb_Edit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.tabEdit.SuspendLayout();
            this.Page2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btgAccept
            // 
            this.btgAccept.Location = new System.Drawing.Point(401, 281);
            this.btgAccept.Size = new System.Drawing.Size(168, 33);
            // 
            // tabEdit
            // 
            this.tabEdit.Size = new System.Drawing.Size(570, 260);
            // 
            // Page1
            // 
            this.Page1.Size = new System.Drawing.Size(562, 234);
            // 
            // Page2
            // 
            this.Page2.Size = new System.Drawing.Size(562, 237);
            // 
            // frmPmTb_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 325);
            this.Name = "frmPmTb_Edit";
            this.Tag = "frmPmTb, ESC";
            this.Text = "frmPmTb";
            this.tabEdit.ResumeLayout(false);
            this.Page2.ResumeLayout(false);
            this.Page2.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

	}
}