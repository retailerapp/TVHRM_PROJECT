﻿namespace Epoint.Modules.HRM
{
    partial class frmPmVPP_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPmVPP_Edit));
            this.lblControl1 = new Epoint.Systems.Controls.lblControl();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtThang = new Epoint.Systems.Controls.txtTextBox();
            this.lblThang = new Epoint.Systems.Controls.lblControl();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.lineControl3 = new Epoint.Systems.Controls.lineControl();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.dgvEdit = new Epoint.Systems.Customizes.dgvVoucher();
            this.lineControl1 = new Epoint.Systems.Controls.lineControl();
            this.lblControl4 = new Epoint.Systems.Controls.lblControl();
            this.lbtTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.lbtTen_Bp = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Bp = new Epoint.Systems.Controls.txtTextBox();
            this.lblMa_Bp = new Epoint.Systems.Controls.lblControl();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // lblControl1
            // 
            this.lblControl1.AutoEllipsis = true;
            this.lblControl1.AutoSize = true;
            this.lblControl1.BackColor = System.Drawing.Color.Transparent;
            this.lblControl1.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblControl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(74)))), ((int)(((byte)(147)))));
            this.lblControl1.Location = new System.Drawing.Point(8, 11);
            this.lblControl1.Name = "lblControl1";
            this.lblControl1.Size = new System.Drawing.Size(116, 14);
            this.lblControl1.TabIndex = 0;
            this.lblControl1.Tag = "Thong_Tin_Chung";
            this.lblControl1.Text = "Thông tin chung:";
            this.lblControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(59, 65);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(56, 13);
            this.lblMa_CbNv.TabIndex = 4;
            this.lblMa_CbNv.Tag = "";
            this.lblMa_CbNv.Text = "Nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtThang
            // 
            this.txtThang.bEnabled = true;
            this.txtThang.bIsLookup = false;
            this.txtThang.bReadOnly = false;
            this.txtThang.bRequire = false;
            this.txtThang.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtThang.KeyFilter = "";
            this.txtThang.Location = new System.Drawing.Point(147, 39);
            this.txtThang.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.txtThang.MaxLength = 20;
            this.txtThang.Name = "txtThang";
            this.txtThang.Size = new System.Drawing.Size(101, 20);
            this.txtThang.TabIndex = 1;
            this.txtThang.UseAutoFilter = false;
            // 
            // lblThang
            // 
            this.lblThang.AutoEllipsis = true;
            this.lblThang.AutoSize = true;
            this.lblThang.BackColor = System.Drawing.Color.Transparent;
            this.lblThang.Location = new System.Drawing.Point(59, 42);
            this.lblThang.Name = "lblThang";
            this.lblThang.Size = new System.Drawing.Size(38, 13);
            this.lblThang.TabIndex = 2;
            this.lblThang.Tag = "";
            this.lblThang.Text = "Tháng";
            this.lblThang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.KeyFilter = "";
            this.txtMa_CbNv.Location = new System.Drawing.Point(147, 62);
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.txtMa_CbNv.MaxLength = 100;
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(101, 20);
            this.txtMa_CbNv.TabIndex = 2;
            this.txtMa_CbNv.UseAutoFilter = false;
            // 
            // lineControl3
            // 
            this.lineControl3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lineControl3.AutoEllipsis = true;
            this.lineControl3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.lineControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineControl3.ForeColor = System.Drawing.Color.Blue;
            this.lineControl3.Location = new System.Drawing.Point(130, 18);
            this.lineControl3.Name = "lineControl3";
            this.lineControl3.Size = new System.Drawing.Size(590, 1);
            this.lineControl3.TabIndex = 1;
            this.lineControl3.Tag = "";
            this.lineControl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.BackColor = System.Drawing.Color.Transparent;
            this.btgAccept.Location = new System.Drawing.Point(581, 519);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(169, 33);
            this.btgAccept.TabIndex = 5;
            // 
            // dgvEdit
            // 
            this.dgvEdit.AllowUserToAddRows = false;
            this.dgvEdit.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.dgvEdit.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEdit.BackgroundColor = System.Drawing.Color.White;
            this.dgvEdit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvEdit.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(235)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEdit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEdit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEdit.EnableHeadersVisualStyles = false;
            this.dgvEdit.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(191)))), ((int)(((byte)(225)))));
            this.dgvEdit.Location = new System.Drawing.Point(31, 137);
            this.dgvEdit.MultiSelect = false;
            this.dgvEdit.Name = "dgvEdit";
            this.dgvEdit.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(235)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEdit.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvEdit.Size = new System.Drawing.Size(719, 370);
            this.dgvEdit.strZone = "";
            this.dgvEdit.TabIndex = 4;
            // 
            // lineControl1
            // 
            this.lineControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lineControl1.AutoEllipsis = true;
            this.lineControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.lineControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineControl1.ForeColor = System.Drawing.Color.Blue;
            this.lineControl1.Location = new System.Drawing.Point(144, 124);
            this.lineControl1.Name = "lineControl1";
            this.lineControl1.Size = new System.Drawing.Size(601, 1);
            this.lineControl1.TabIndex = 253;
            this.lineControl1.Tag = "";
            this.lineControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl4
            // 
            this.lblControl4.AutoEllipsis = true;
            this.lblControl4.AutoSize = true;
            this.lblControl4.BackColor = System.Drawing.Color.Transparent;
            this.lblControl4.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblControl4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(74)))), ((int)(((byte)(147)))));
            this.lblControl4.Location = new System.Drawing.Point(12, 117);
            this.lblControl4.Name = "lblControl4";
            this.lblControl4.Size = new System.Drawing.Size(121, 14);
            this.lblControl4.TabIndex = 14;
            this.lblControl4.Tag = "";
            this.lblControl4.Text = "Văn phòng phẩm:";
            this.lblControl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbtTen_CbNv
            // 
            this.lbtTen_CbNv.AutoEllipsis = true;
            this.lbtTen_CbNv.AutoSize = true;
            this.lbtTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_CbNv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_CbNv.Location = new System.Drawing.Point(254, 65);
            this.lbtTen_CbNv.Name = "lbtTen_CbNv";
            this.lbtTen_CbNv.Size = new System.Drawing.Size(59, 13);
            this.lbtTen_CbNv.TabIndex = 254;
            this.lbtTen_CbNv.Text = "Ten_CbNv";
            this.lbtTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbtTen_Bp
            // 
            this.lbtTen_Bp.AutoEllipsis = true;
            this.lbtTen_Bp.AutoSize = true;
            this.lbtTen_Bp.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_Bp.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_Bp.Location = new System.Drawing.Point(254, 88);
            this.lbtTen_Bp.Name = "lbtTen_Bp";
            this.lbtTen_Bp.Size = new System.Drawing.Size(45, 13);
            this.lbtTen_Bp.TabIndex = 257;
            this.lbtTen_Bp.Text = "Ten_Bp";
            this.lbtTen_Bp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Bp
            // 
            this.txtMa_Bp.bEnabled = true;
            this.txtMa_Bp.bIsLookup = false;
            this.txtMa_Bp.bReadOnly = false;
            this.txtMa_Bp.bRequire = false;
            this.txtMa_Bp.KeyFilter = "";
            this.txtMa_Bp.Location = new System.Drawing.Point(147, 85);
            this.txtMa_Bp.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.txtMa_Bp.MaxLength = 100;
            this.txtMa_Bp.Name = "txtMa_Bp";
            this.txtMa_Bp.Size = new System.Drawing.Size(101, 20);
            this.txtMa_Bp.TabIndex = 3;
            this.txtMa_Bp.UseAutoFilter = false;
            // 
            // lblMa_Bp
            // 
            this.lblMa_Bp.AutoEllipsis = true;
            this.lblMa_Bp.AutoSize = true;
            this.lblMa_Bp.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_Bp.Location = new System.Drawing.Point(59, 88);
            this.lblMa_Bp.Name = "lblMa_Bp";
            this.lblMa_Bp.Size = new System.Drawing.Size(47, 13);
            this.lblMa_Bp.TabIndex = 256;
            this.lblMa_Bp.Tag = "";
            this.lblMa_Bp.Text = "Bộ phận";
            this.lblMa_Bp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmPmVPP_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.lbtTen_Bp);
            this.Controls.Add(this.txtMa_Bp);
            this.Controls.Add(this.lblMa_Bp);
            this.Controls.Add(this.lbtTen_CbNv);
            this.Controls.Add(this.lineControl1);
            this.Controls.Add(this.lblControl4);
            this.Controls.Add(this.dgvEdit);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lineControl3);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.txtThang);
            this.Controls.Add(this.lblThang);
            this.Controls.Add(this.lblControl1);
            this.Controls.Add(this.lblMa_CbNv);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPmVPP_Edit";
            this.Tag = "frmPmVPP_Edit,ESC";
            this.Text = "frmPmVPP_Edit";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private Epoint.Systems.Controls.lblControl lblControl1;
        private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Epoint.Systems.Controls.txtTextBox txtThang;
        private Epoint.Systems.Controls.lblControl lblThang;
		private Epoint.Systems.Controls.txtTextBox txtMa_CbNv;
		private Epoint.Systems.Controls.lineControl lineControl3;
        public Epoint.Systems.Customizes.btgAccept btgAccept;
		private Epoint.Systems.Customizes.dgvVoucher dgvEdit;
		private Epoint.Systems.Controls.lineControl lineControl1;
        private Epoint.Systems.Controls.lblControl lblControl4;
        private Epoint.Systems.Controls.lblControl lbtTen_CbNv;
        private Epoint.Systems.Controls.lblControl lbtTen_Bp;
        private Epoint.Systems.Controls.txtTextBox txtMa_Bp;
        private Epoint.Systems.Controls.lblControl lblMa_Bp;
    }
}