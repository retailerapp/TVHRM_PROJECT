﻿namespace Epoint.Modules.Salary
{
	partial class frmBangLuong_Posted
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBangLuong_Posted));
            this.txtDien_Giai = new Epoint.Systems.Controls.txtTextBox();
            this.lblControl1 = new Epoint.Systems.Controls.lblControl();
            this.lblControl2 = new Epoint.Systems.Controls.lblControl();
            this.txtSo_Ct = new Epoint.Systems.Controls.txtTextBox();
            this.lblControl3 = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Ct = new Epoint.Systems.Controls.txtTextBox();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.lblControl4 = new Epoint.Systems.Controls.lblControl();
            this.numThang = new Epoint.Systems.Controls.numControl();
            this.SuspendLayout();
            // 
            // txtDien_Giai
            // 
            this.txtDien_Giai.bEnabled = true;
            this.txtDien_Giai.bIsLookup = false;
            this.txtDien_Giai.bReadOnly = false;
            this.txtDien_Giai.bRequire = false;
            this.txtDien_Giai.KeyFilter = "";
            this.txtDien_Giai.Location = new System.Drawing.Point(111, 86);
            this.txtDien_Giai.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDien_Giai.Name = "txtDien_Giai";
            this.txtDien_Giai.Size = new System.Drawing.Size(421, 20);
            this.txtDien_Giai.TabIndex = 3;
            this.txtDien_Giai.UseAutoFilter = false;
            // 
            // lblControl1
            // 
            this.lblControl1.AutoEllipsis = true;
            this.lblControl1.AutoSize = true;
            this.lblControl1.BackColor = System.Drawing.Color.Transparent;
            this.lblControl1.Location = new System.Drawing.Point(19, 89);
            this.lblControl1.Name = "lblControl1";
            this.lblControl1.Size = new System.Drawing.Size(48, 13);
            this.lblControl1.TabIndex = 2;
            this.lblControl1.Tag = "Dien_Giai";
            this.lblControl1.Text = "Diễn giải";
            this.lblControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl2
            // 
            this.lblControl2.AutoEllipsis = true;
            this.lblControl2.AutoSize = true;
            this.lblControl2.BackColor = System.Drawing.Color.Transparent;
            this.lblControl2.Location = new System.Drawing.Point(19, 66);
            this.lblControl2.Name = "lblControl2";
            this.lblControl2.Size = new System.Drawing.Size(65, 13);
            this.lblControl2.TabIndex = 1;
            this.lblControl2.Tag = "So_Ct";
            this.lblControl2.Text = "Số chứng từ";
            this.lblControl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSo_Ct
            // 
            this.txtSo_Ct.bEnabled = true;
            this.txtSo_Ct.bIsLookup = false;
            this.txtSo_Ct.bReadOnly = false;
            this.txtSo_Ct.bRequire = false;
            this.txtSo_Ct.KeyFilter = "";
            this.txtSo_Ct.Location = new System.Drawing.Point(111, 63);
            this.txtSo_Ct.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Ct.Name = "txtSo_Ct";
            this.txtSo_Ct.Size = new System.Drawing.Size(110, 20);
            this.txtSo_Ct.TabIndex = 2;
            this.txtSo_Ct.UseAutoFilter = false;
            // 
            // lblControl3
            // 
            this.lblControl3.AutoEllipsis = true;
            this.lblControl3.AutoSize = true;
            this.lblControl3.BackColor = System.Drawing.Color.Transparent;
            this.lblControl3.Location = new System.Drawing.Point(19, 43);
            this.lblControl3.Name = "lblControl3";
            this.lblControl3.Size = new System.Drawing.Size(67, 13);
            this.lblControl3.TabIndex = 0;
            this.lblControl3.Tag = "Ma_Ct";
            this.lblControl3.Text = "Mã chứng từ";
            this.lblControl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Ct
            // 
            this.txtMa_Ct.bEnabled = true;
            this.txtMa_Ct.bIsLookup = false;
            this.txtMa_Ct.bReadOnly = false;
            this.txtMa_Ct.bRequire = false;
            this.txtMa_Ct.KeyFilter = "";
            this.txtMa_Ct.Location = new System.Drawing.Point(111, 40);
            this.txtMa_Ct.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Ct.Name = "txtMa_Ct";
            this.txtMa_Ct.Size = new System.Drawing.Size(31, 20);
            this.txtMa_Ct.TabIndex = 1;
            this.txtMa_Ct.UseAutoFilter = false;
            // 
            // btgAccept
            // 
            this.btgAccept.Location = new System.Drawing.Point(360, 123);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(168, 33);
            this.btgAccept.TabIndex = 4;
            // 
            // lblControl4
            // 
            this.lblControl4.AutoEllipsis = true;
            this.lblControl4.AutoSize = true;
            this.lblControl4.BackColor = System.Drawing.Color.Transparent;
            this.lblControl4.Location = new System.Drawing.Point(19, 20);
            this.lblControl4.Name = "lblControl4";
            this.lblControl4.Size = new System.Drawing.Size(38, 13);
            this.lblControl4.TabIndex = 0;
            this.lblControl4.Tag = "Thang";
            this.lblControl4.Text = "Tháng";
            this.lblControl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numThang
            // 
            this.numThang.bEnabled = true;
            this.numThang.bFormat = true;
            this.numThang.bIsLookup = false;
            this.numThang.bReadOnly = false;
            this.numThang.bRequire = false;
            this.numThang.KeyFilter = "";
            this.numThang.Location = new System.Drawing.Point(111, 17);
            this.numThang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.numThang.Name = "numThang";
            this.numThang.Scale = 0;
            this.numThang.Size = new System.Drawing.Size(31, 20);
            this.numThang.TabIndex = 0;
            this.numThang.Text = "0";
            this.numThang.UseAutoFilter = false;
            this.numThang.Value = 0D;
            // 
            // frmBangLuong_Posted
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 171);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.numThang);
            this.Controls.Add(this.lblControl4);
            this.Controls.Add(this.txtMa_Ct);
            this.Controls.Add(this.lblControl3);
            this.Controls.Add(this.txtSo_Ct);
            this.Controls.Add(this.lblControl2);
            this.Controls.Add(this.txtDien_Giai);
            this.Controls.Add(this.lblControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmBangLuong_Posted";
            this.Tag = "frmBangLuong_Posted";
            this.Text = "frmBangLuong_Posted";
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private Epoint.Systems.Controls.txtTextBox txtDien_Giai;
		private Epoint.Systems.Controls.lblControl lblControl1;
		private Epoint.Systems.Controls.lblControl lblControl2;
		private Epoint.Systems.Controls.txtTextBox txtSo_Ct;
		private Epoint.Systems.Controls.lblControl lblControl3;
		private Epoint.Systems.Controls.txtTextBox txtMa_Ct;
		private Epoint.Systems.Customizes.btgAccept btgAccept;
		private Epoint.Systems.Controls.lblControl lblControl4;
		private Epoint.Systems.Controls.numControl numThang;
	}
}