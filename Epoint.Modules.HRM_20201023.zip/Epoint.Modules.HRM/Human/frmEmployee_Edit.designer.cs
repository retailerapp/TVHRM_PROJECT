﻿namespace Epoint.Modules.HRM
{
	partial class frmEmployee_Edit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEmployee_Edit));
            this.lbtTen_Bp = new Epoint.Systems.Controls.lblControl();
            this.picHinh = new System.Windows.Forms.PictureBox();
            this.lblHand_Phone = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Phone = new Epoint.Systems.Controls.lblControl();
            this.lblControl2 = new Epoint.Systems.Controls.lblControl();
            this.lblEmail = new Epoint.Systems.Controls.lblControl();
            this.lblDia_Chi = new Epoint.Systems.Controls.lblControl();
            this.lblControl14 = new Epoint.Systems.Controls.lblControl();
            this.lblControl1 = new Epoint.Systems.Controls.lblControl();
            this.txtHand_Phone = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_Phone = new Epoint.Systems.Controls.txtTextBox();
            this.txtTen_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.txtEmail = new Epoint.Systems.Controls.txtTextBox();
            this.txtDia_Chi = new Epoint.Systems.Controls.txtTextBox();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.txtBi_Danh = new Epoint.Systems.Controls.txtTextBox();
            this.lblControl19 = new Epoint.Systems.Controls.lblControl();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboTrang_Thai = new Epoint.Systems.Controls.cboControl();
            this.lblControl3 = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Nghi_Viec = new Epoint.Systems.Controls.lblControl();
            this.lblTrinh_Do = new Epoint.Systems.Controls.lblControl();
            this.txtSo_Nghi_Viec = new Epoint.Systems.Controls.txtTextBox();
            this.txtTrinh_Do = new Epoint.Systems.Controls.txtTextBox();
            this.lblNoi_Cap = new Epoint.Systems.Controls.lblControl();
            this.txtNoi_Cap = new Epoint.Systems.Controls.txtTextBox();
            this.cboTinh_Trang_HN = new Epoint.Systems.Controls.cboControl();
            this.cboGioi_Tinh = new Epoint.Systems.Controls.cboControl();
            this.txtNgay_End = new Epoint.Systems.Controls.txtDateTime();
            this.txtNgay_Cap = new Epoint.Systems.Controls.txtDateTime();
            this.lblControl10 = new Epoint.Systems.Controls.lblControl();
            this.lblNgay_Cap = new Epoint.Systems.Controls.lblControl();
            this.dteNgay_Sinh = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblTinh_Trang_HN = new Epoint.Systems.Controls.lblControl();
            this.lblNgan_Hang = new Epoint.Systems.Controls.lblControl();
            this.lblMa_So_Thue = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Tk = new Epoint.Systems.Controls.lblControl();
            this.lblQuoc_Tich = new Epoint.Systems.Controls.lblControl();
            this.lblTon_Giao = new Epoint.Systems.Controls.lblControl();
            this.lblDan_Toc = new Epoint.Systems.Controls.lblControl();
            this.lblNguyen_Quan = new Epoint.Systems.Controls.lblControl();
            this.lblGioi_Tinh = new Epoint.Systems.Controls.lblControl();
            this.lblNoi_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblSo_CMND = new Epoint.Systems.Controls.lblControl();
            this.txtNgan_Hang = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_Tk = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_So_Thue = new Epoint.Systems.Controls.txtTextBox();
            this.txtQuoc_Tich = new Epoint.Systems.Controls.txtTextBox();
            this.txtTon_Giao = new Epoint.Systems.Controls.txtTextBox();
            this.txtDan_Toc = new Epoint.Systems.Controls.txtTextBox();
            this.txtNguyen_Quan = new Epoint.Systems.Controls.txtTextBox();
            this.txtNoi_Sinh = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_CMND = new Epoint.Systems.Controls.txtTextBox();
            this.lblGhi_Chu = new Epoint.Systems.Controls.lblControl();
            this.txtGhi_Chu = new Epoint.Systems.Controls.txtTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkSend_Mail = new Epoint.Systems.Controls.chkControl();
            this.lblDia_Chi_TT = new Epoint.Systems.Controls.lblControl();
            this.txtDia_Chi_TT = new Epoint.Systems.Controls.txtTextBox();
            this.lblWebsite = new Epoint.Systems.Controls.lblControl();
            this.lblControl8 = new Epoint.Systems.Controls.lblControl();
            this.lblControl7 = new Epoint.Systems.Controls.lblControl();
            this.txtWebsite = new Epoint.Systems.Controls.txtTextBox();
            this.txtChamCong_ID = new Epoint.Systems.Controls.txtTextBox();
            this.txtZalo_ID = new Epoint.Systems.Controls.txtTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            this.txtMa_Bp = new Epoint.Systems.Controls.txtTextLookup();
            this.txtMa_ViTri = new Epoint.Systems.Controls.txtTextLookup();
            this.lbtTen_ViTri = new Epoint.Systems.Controls.lblControl();
            this.lblMa_ViTri = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Data = new Epoint.Systems.Controls.txtTextBox();
            this.btXoa_Anh = new Epoint.Systems.Controls.btControl();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkIs_Bang_Cap = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Hanh_Kiem = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Huan_Luyen = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Ho_Khau = new Epoint.Systems.Controls.chkControl();
            this.chkIs_SYLL = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Don_XinViec = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Hinh_Anh = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Suc_Khoe = new Epoint.Systems.Controls.chkControl();
            this.lblMa_Kv = new Epoint.Systems.Controls.lblControl();
            this.lbtTen_Kv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Kv = new Epoint.Systems.Controls.txtTextLookup();
            this.lblControl4 = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Cbnv_Leader = new Epoint.Systems.Controls.txtTextLookup();
            this.lblControl5 = new Epoint.Systems.Controls.lblControl();
            this.txtDia_Ban = new Epoint.Systems.Controls.txtTextLookup();
            this.dteNgay_Bd = new Epoint.Systems.Controls.txtDateTime();
            this.lblControl6 = new Epoint.Systems.Controls.lblControl();
            this.lblControl9 = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Loai1 = new Epoint.Systems.Controls.txtTextLookup();
            this.lblControl11 = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Cbnv_MERP = new Epoint.Systems.Controls.txtTextLookup();
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbtTen_Bp
            // 
            this.lbtTen_Bp.AutoEllipsis = true;
            this.lbtTen_Bp.AutoSize = true;
            this.lbtTen_Bp.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_Bp.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_Bp.Location = new System.Drawing.Point(235, 59);
            this.lbtTen_Bp.Name = "lbtTen_Bp";
            this.lbtTen_Bp.Size = new System.Drawing.Size(71, 13);
            this.lbtTen_Bp.TabIndex = 6;
            this.lbtTen_Bp.Text = "Tên bộ phận ";
            this.lbtTen_Bp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picHinh
            // 
            this.picHinh.BackColor = System.Drawing.Color.Transparent;
            this.picHinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picHinh.Location = new System.Drawing.Point(545, 4);
            this.picHinh.Name = "picHinh";
            this.picHinh.Size = new System.Drawing.Size(118, 100);
            this.picHinh.TabIndex = 146;
            this.picHinh.TabStop = false;
            // 
            // lblHand_Phone
            // 
            this.lblHand_Phone.AutoEllipsis = true;
            this.lblHand_Phone.AutoSize = true;
            this.lblHand_Phone.BackColor = System.Drawing.Color.Transparent;
            this.lblHand_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHand_Phone.Location = new System.Drawing.Point(299, 70);
            this.lblHand_Phone.Name = "lblHand_Phone";
            this.lblHand_Phone.Size = new System.Drawing.Size(45, 13);
            this.lblHand_Phone.TabIndex = 131;
            this.lblHand_Phone.Text = "Di động";
            this.lblHand_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Phone
            // 
            this.lblSo_Phone.AutoEllipsis = true;
            this.lblSo_Phone.AutoSize = true;
            this.lblSo_Phone.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Phone.Location = new System.Drawing.Point(5, 68);
            this.lblSo_Phone.Name = "lblSo_Phone";
            this.lblSo_Phone.Size = new System.Drawing.Size(55, 13);
            this.lblSo_Phone.TabIndex = 129;
            this.lblSo_Phone.Text = "Điện thoại";
            this.lblSo_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl2
            // 
            this.lblControl2.AutoEllipsis = true;
            this.lblControl2.AutoSize = true;
            this.lblControl2.BackColor = System.Drawing.Color.Transparent;
            this.lblControl2.Location = new System.Drawing.Point(21, 35);
            this.lblControl2.Name = "lblControl2";
            this.lblControl2.Size = new System.Drawing.Size(76, 13);
            this.lblControl2.TabIndex = 139;
            this.lblControl2.Tag = "Ten_CbNv";
            this.lblControl2.Text = "Tên nhân viên";
            this.lblControl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoEllipsis = true;
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(5, 92);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 122;
            this.lblEmail.Text = "Email";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDia_Chi
            // 
            this.lblDia_Chi.AutoEllipsis = true;
            this.lblDia_Chi.AutoSize = true;
            this.lblDia_Chi.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDia_Chi.Location = new System.Drawing.Point(5, 45);
            this.lblDia_Chi.Name = "lblDia_Chi";
            this.lblDia_Chi.Size = new System.Drawing.Size(75, 13);
            this.lblDia_Chi.TabIndex = 120;
            this.lblDia_Chi.Tag = "Dia_Chi_TAM_TRU";
            this.lblDia_Chi.Text = "Địa chỉ tạm trú";
            this.lblDia_Chi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl14
            // 
            this.lblControl14.AutoEllipsis = true;
            this.lblControl14.AutoSize = true;
            this.lblControl14.BackColor = System.Drawing.Color.Transparent;
            this.lblControl14.Location = new System.Drawing.Point(21, 57);
            this.lblControl14.Name = "lblControl14";
            this.lblControl14.Size = new System.Drawing.Size(64, 13);
            this.lblControl14.TabIndex = 126;
            this.lblControl14.Tag = "Ma_Bp";
            this.lblControl14.Text = "Mã bộ phận";
            this.lblControl14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl1
            // 
            this.lblControl1.AutoEllipsis = true;
            this.lblControl1.AutoSize = true;
            this.lblControl1.BackColor = System.Drawing.Color.Transparent;
            this.lblControl1.Location = new System.Drawing.Point(21, 11);
            this.lblControl1.Name = "lblControl1";
            this.lblControl1.Size = new System.Drawing.Size(72, 13);
            this.lblControl1.TabIndex = 123;
            this.lblControl1.Tag = "Ma_CbNv";
            this.lblControl1.Text = "Mã nhân viên";
            this.lblControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtHand_Phone
            // 
            this.txtHand_Phone.bEnabled = true;
            this.txtHand_Phone.bIsLookup = false;
            this.txtHand_Phone.bReadOnly = false;
            this.txtHand_Phone.bRequire = false;
            this.txtHand_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHand_Phone.KeyFilter = "";
            this.txtHand_Phone.Location = new System.Drawing.Point(365, 65);
            this.txtHand_Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtHand_Phone.Name = "txtHand_Phone";
            this.txtHand_Phone.Size = new System.Drawing.Size(286, 20);
            this.txtHand_Phone.TabIndex = 3;
            this.txtHand_Phone.UseAutoFilter = false;
            // 
            // txtSo_Phone
            // 
            this.txtSo_Phone.bEnabled = true;
            this.txtSo_Phone.bIsLookup = false;
            this.txtSo_Phone.bReadOnly = false;
            this.txtSo_Phone.bRequire = false;
            this.txtSo_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Phone.KeyFilter = "";
            this.txtSo_Phone.Location = new System.Drawing.Point(104, 65);
            this.txtSo_Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Phone.Name = "txtSo_Phone";
            this.txtSo_Phone.Size = new System.Drawing.Size(185, 20);
            this.txtSo_Phone.TabIndex = 2;
            this.txtSo_Phone.UseAutoFilter = false;
            // 
            // txtTen_CbNv
            // 
            this.txtTen_CbNv.bEnabled = true;
            this.txtTen_CbNv.bIsLookup = false;
            this.txtTen_CbNv.bReadOnly = false;
            this.txtTen_CbNv.bRequire = false;
            this.txtTen_CbNv.KeyFilter = "";
            this.txtTen_CbNv.Location = new System.Drawing.Point(113, 31);
            this.txtTen_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTen_CbNv.Name = "txtTen_CbNv";
            this.txtTen_CbNv.Size = new System.Drawing.Size(251, 20);
            this.txtTen_CbNv.TabIndex = 2;
            this.txtTen_CbNv.UseAutoFilter = false;
            // 
            // txtEmail
            // 
            this.txtEmail.bEnabled = true;
            this.txtEmail.bIsLookup = false;
            this.txtEmail.bReadOnly = false;
            this.txtEmail.bRequire = false;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.KeyFilter = "";
            this.txtEmail.Location = new System.Drawing.Point(104, 88);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(185, 20);
            this.txtEmail.TabIndex = 4;
            this.txtEmail.UseAutoFilter = false;
            // 
            // txtDia_Chi
            // 
            this.txtDia_Chi.bEnabled = true;
            this.txtDia_Chi.bIsLookup = false;
            this.txtDia_Chi.bReadOnly = false;
            this.txtDia_Chi.bRequire = false;
            this.txtDia_Chi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDia_Chi.KeyFilter = "";
            this.txtDia_Chi.Location = new System.Drawing.Point(104, 42);
            this.txtDia_Chi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi.Name = "txtDia_Chi";
            this.txtDia_Chi.Size = new System.Drawing.Size(547, 20);
            this.txtDia_Chi.TabIndex = 1;
            this.txtDia_Chi.UseAutoFilter = false;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(495, 710);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(169, 34);
            this.btgAccept.TabIndex = 10;
            // 
            // txtBi_Danh
            // 
            this.txtBi_Danh.bEnabled = true;
            this.txtBi_Danh.bIsLookup = false;
            this.txtBi_Danh.bReadOnly = false;
            this.txtBi_Danh.bRequire = false;
            this.txtBi_Danh.KeyFilter = "";
            this.txtBi_Danh.Location = new System.Drawing.Point(291, 8);
            this.txtBi_Danh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtBi_Danh.Name = "txtBi_Danh";
            this.txtBi_Danh.Size = new System.Drawing.Size(249, 20);
            this.txtBi_Danh.TabIndex = 1;
            this.txtBi_Danh.UseAutoFilter = false;
            // 
            // lblControl19
            // 
            this.lblControl19.AutoEllipsis = true;
            this.lblControl19.AutoSize = true;
            this.lblControl19.BackColor = System.Drawing.Color.Transparent;
            this.lblControl19.Location = new System.Drawing.Point(241, 12);
            this.lblControl19.Name = "lblControl19";
            this.lblControl19.Size = new System.Drawing.Size(45, 13);
            this.lblControl19.TabIndex = 121;
            this.lblControl19.Text = "Bí danh";
            this.lblControl19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboTrang_Thai);
            this.groupBox1.Controls.Add(this.lblControl3);
            this.groupBox1.Controls.Add(this.lblSo_Nghi_Viec);
            this.groupBox1.Controls.Add(this.lblTrinh_Do);
            this.groupBox1.Controls.Add(this.txtSo_Nghi_Viec);
            this.groupBox1.Controls.Add(this.txtTrinh_Do);
            this.groupBox1.Controls.Add(this.lblNoi_Cap);
            this.groupBox1.Controls.Add(this.txtNoi_Cap);
            this.groupBox1.Controls.Add(this.cboTinh_Trang_HN);
            this.groupBox1.Controls.Add(this.cboGioi_Tinh);
            this.groupBox1.Controls.Add(this.txtNgay_End);
            this.groupBox1.Controls.Add(this.txtNgay_Cap);
            this.groupBox1.Controls.Add(this.lblControl10);
            this.groupBox1.Controls.Add(this.lblNgay_Cap);
            this.groupBox1.Controls.Add(this.dteNgay_Sinh);
            this.groupBox1.Controls.Add(this.lblNgay_Sinh);
            this.groupBox1.Controls.Add(this.lblTinh_Trang_HN);
            this.groupBox1.Controls.Add(this.lblNgan_Hang);
            this.groupBox1.Controls.Add(this.lblMa_So_Thue);
            this.groupBox1.Controls.Add(this.lblSo_Tk);
            this.groupBox1.Controls.Add(this.lblQuoc_Tich);
            this.groupBox1.Controls.Add(this.lblTon_Giao);
            this.groupBox1.Controls.Add(this.lblDan_Toc);
            this.groupBox1.Controls.Add(this.lblNguyen_Quan);
            this.groupBox1.Controls.Add(this.lblGioi_Tinh);
            this.groupBox1.Controls.Add(this.lblNoi_Sinh);
            this.groupBox1.Controls.Add(this.lblSo_CMND);
            this.groupBox1.Controls.Add(this.txtNgan_Hang);
            this.groupBox1.Controls.Add(this.txtSo_Tk);
            this.groupBox1.Controls.Add(this.txtMa_So_Thue);
            this.groupBox1.Controls.Add(this.txtQuoc_Tich);
            this.groupBox1.Controls.Add(this.txtTon_Giao);
            this.groupBox1.Controls.Add(this.txtDan_Toc);
            this.groupBox1.Controls.Add(this.txtNguyen_Quan);
            this.groupBox1.Controls.Add(this.txtNoi_Sinh);
            this.groupBox1.Controls.Add(this.txtSo_CMND);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(14, 164);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(667, 234);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin cá nhân";
            // 
            // cboTrang_Thai
            // 
            this.cboTrang_Thai.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTrang_Thai.FormattingEnabled = true;
            this.cboTrang_Thai.InitValue = null;
            this.cboTrang_Thai.Items.AddRange(new object[] {
            "Đang Làm",
            "Nghỉ Sinh",
            "Nghỉ tạm thời",
            "Đã nghỉ việc"});
            this.cboTrang_Thai.Location = new System.Drawing.Point(425, 13);
            this.cboTrang_Thai.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboTrang_Thai.Name = "cboTrang_Thai";
            this.cboTrang_Thai.Size = new System.Drawing.Size(226, 21);
            this.cboTrang_Thai.strValueList = null;
            this.cboTrang_Thai.TabIndex = 9;
            this.cboTrang_Thai.UpperCase = false;
            this.cboTrang_Thai.UseAutoComplete = false;
            this.cboTrang_Thai.UseBindingValue = false;
            // 
            // lblControl3
            // 
            this.lblControl3.AutoEllipsis = true;
            this.lblControl3.AutoSize = true;
            this.lblControl3.BackColor = System.Drawing.Color.Transparent;
            this.lblControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl3.Location = new System.Drawing.Point(346, 16);
            this.lblControl3.Name = "lblControl3";
            this.lblControl3.Size = new System.Drawing.Size(55, 13);
            this.lblControl3.TabIndex = 282;
            this.lblControl3.Tag = "Trang_Thai";
            this.lblControl3.Text = "Trạng thái";
            this.lblControl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Nghi_Viec
            // 
            this.lblSo_Nghi_Viec.AutoEllipsis = true;
            this.lblSo_Nghi_Viec.AutoSize = true;
            this.lblSo_Nghi_Viec.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Nghi_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Nghi_Viec.Location = new System.Drawing.Point(346, 209);
            this.lblSo_Nghi_Viec.Name = "lblSo_Nghi_Viec";
            this.lblSo_Nghi_Viec.Size = new System.Drawing.Size(66, 13);
            this.lblSo_Nghi_Viec.TabIndex = 186;
            this.lblSo_Nghi_Viec.Tag = "";
            this.lblSo_Nghi_Viec.Text = "Số nghỉ việc";
            this.lblSo_Nghi_Viec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTrinh_Do
            // 
            this.lblTrinh_Do.AutoEllipsis = true;
            this.lblTrinh_Do.AutoSize = true;
            this.lblTrinh_Do.BackColor = System.Drawing.Color.Transparent;
            this.lblTrinh_Do.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrinh_Do.Location = new System.Drawing.Point(346, 184);
            this.lblTrinh_Do.Name = "lblTrinh_Do";
            this.lblTrinh_Do.Size = new System.Drawing.Size(47, 13);
            this.lblTrinh_Do.TabIndex = 186;
            this.lblTrinh_Do.Tag = "";
            this.lblTrinh_Do.Text = "Trình độ";
            this.lblTrinh_Do.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSo_Nghi_Viec
            // 
            this.txtSo_Nghi_Viec.AccessibleName = "6";
            this.txtSo_Nghi_Viec.bEnabled = true;
            this.txtSo_Nghi_Viec.bIsLookup = false;
            this.txtSo_Nghi_Viec.bReadOnly = false;
            this.txtSo_Nghi_Viec.bRequire = false;
            this.txtSo_Nghi_Viec.Enabled = false;
            this.txtSo_Nghi_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Nghi_Viec.KeyFilter = "";
            this.txtSo_Nghi_Viec.Location = new System.Drawing.Point(425, 205);
            this.txtSo_Nghi_Viec.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Nghi_Viec.Name = "txtSo_Nghi_Viec";
            this.txtSo_Nghi_Viec.Size = new System.Drawing.Size(226, 20);
            this.txtSo_Nghi_Viec.TabIndex = 17;
            this.txtSo_Nghi_Viec.UseAutoFilter = false;
            // 
            // txtTrinh_Do
            // 
            this.txtTrinh_Do.AccessibleName = "6";
            this.txtTrinh_Do.bEnabled = true;
            this.txtTrinh_Do.bIsLookup = false;
            this.txtTrinh_Do.bReadOnly = false;
            this.txtTrinh_Do.bRequire = false;
            this.txtTrinh_Do.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrinh_Do.KeyFilter = "";
            this.txtTrinh_Do.Location = new System.Drawing.Point(425, 180);
            this.txtTrinh_Do.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTrinh_Do.Name = "txtTrinh_Do";
            this.txtTrinh_Do.Size = new System.Drawing.Size(226, 20);
            this.txtTrinh_Do.TabIndex = 16;
            this.txtTrinh_Do.UseAutoFilter = false;
            // 
            // lblNoi_Cap
            // 
            this.lblNoi_Cap.AutoEllipsis = true;
            this.lblNoi_Cap.AutoSize = true;
            this.lblNoi_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoi_Cap.Location = new System.Drawing.Point(14, 114);
            this.lblNoi_Cap.Name = "lblNoi_Cap";
            this.lblNoi_Cap.Size = new System.Drawing.Size(44, 13);
            this.lblNoi_Cap.TabIndex = 171;
            this.lblNoi_Cap.Tag = "Noi_Cap";
            this.lblNoi_Cap.Text = "Nơi cấp";
            this.lblNoi_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNoi_Cap
            // 
            this.txtNoi_Cap.bEnabled = true;
            this.txtNoi_Cap.bIsLookup = false;
            this.txtNoi_Cap.bReadOnly = false;
            this.txtNoi_Cap.bRequire = false;
            this.txtNoi_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoi_Cap.KeyFilter = "";
            this.txtNoi_Cap.Location = new System.Drawing.Point(104, 111);
            this.txtNoi_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Cap.Name = "txtNoi_Cap";
            this.txtNoi_Cap.Size = new System.Drawing.Size(211, 20);
            this.txtNoi_Cap.TabIndex = 4;
            this.txtNoi_Cap.UseAutoFilter = false;
            // 
            // cboTinh_Trang_HN
            // 
            this.cboTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTinh_Trang_HN.FormattingEnabled = true;
            this.cboTinh_Trang_HN.InitValue = null;
            this.cboTinh_Trang_HN.Items.AddRange(new object[] {
            "Đã kết hôn",
            "Độc thân",
            "Ly Hôn"});
            this.cboTinh_Trang_HN.Location = new System.Drawing.Point(425, 41);
            this.cboTinh_Trang_HN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboTinh_Trang_HN.Name = "cboTinh_Trang_HN";
            this.cboTinh_Trang_HN.Size = new System.Drawing.Size(226, 21);
            this.cboTinh_Trang_HN.strValueList = null;
            this.cboTinh_Trang_HN.TabIndex = 10;
            this.cboTinh_Trang_HN.UpperCase = false;
            this.cboTinh_Trang_HN.UseAutoComplete = false;
            this.cboTinh_Trang_HN.UseBindingValue = false;
            // 
            // cboGioi_Tinh
            // 
            this.cboGioi_Tinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboGioi_Tinh.FormattingEnabled = true;
            this.cboGioi_Tinh.InitValue = null;
            this.cboGioi_Tinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.cboGioi_Tinh.Location = new System.Drawing.Point(104, 181);
            this.cboGioi_Tinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboGioi_Tinh.Name = "cboGioi_Tinh";
            this.cboGioi_Tinh.Size = new System.Drawing.Size(89, 21);
            this.cboGioi_Tinh.strValueList = null;
            this.cboGioi_Tinh.TabIndex = 7;
            this.cboGioi_Tinh.UpperCase = false;
            this.cboGioi_Tinh.UseAutoComplete = false;
            this.cboGioi_Tinh.UseBindingValue = false;
            // 
            // txtNgay_End
            // 
            this.txtNgay_End.bAllowEmpty = true;
            this.txtNgay_End.bRequire = false;
            this.txtNgay_End.bSelectOnFocus = false;
            this.txtNgay_End.bShowDateTimePicker = true;
            this.txtNgay_End.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_End.Enabled = false;
            this.txtNgay_End.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_End.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_End.Location = new System.Drawing.Point(105, 210);
            this.txtNgay_End.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_End.Mask = "00/00/0000";
            this.txtNgay_End.Name = "txtNgay_End";
            this.txtNgay_End.Size = new System.Drawing.Size(89, 20);
            this.txtNgay_End.TabIndex = 8;
            // 
            // txtNgay_Cap
            // 
            this.txtNgay_Cap.bAllowEmpty = true;
            this.txtNgay_Cap.bRequire = false;
            this.txtNgay_Cap.bSelectOnFocus = false;
            this.txtNgay_Cap.bShowDateTimePicker = true;
            this.txtNgay_Cap.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Cap.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Cap.Location = new System.Drawing.Point(104, 88);
            this.txtNgay_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Cap.Mask = "00/00/0000";
            this.txtNgay_Cap.Name = "txtNgay_Cap";
            this.txtNgay_Cap.Size = new System.Drawing.Size(89, 20);
            this.txtNgay_Cap.TabIndex = 3;
            // 
            // lblControl10
            // 
            this.lblControl10.AutoEllipsis = true;
            this.lblControl10.AutoSize = true;
            this.lblControl10.BackColor = System.Drawing.Color.Transparent;
            this.lblControl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl10.Location = new System.Drawing.Point(15, 212);
            this.lblControl10.Name = "lblControl10";
            this.lblControl10.Size = new System.Drawing.Size(78, 13);
            this.lblControl10.TabIndex = 161;
            this.lblControl10.Tag = "";
            this.lblControl10.Text = "Ngày nghỉ việc";
            this.lblControl10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNgay_Cap
            // 
            this.lblNgay_Cap.AutoEllipsis = true;
            this.lblNgay_Cap.AutoSize = true;
            this.lblNgay_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay_Cap.Location = new System.Drawing.Point(14, 90);
            this.lblNgay_Cap.Name = "lblNgay_Cap";
            this.lblNgay_Cap.Size = new System.Drawing.Size(53, 13);
            this.lblNgay_Cap.TabIndex = 161;
            this.lblNgay_Cap.Tag = "Ngay_Cap";
            this.lblNgay_Cap.Text = "Ngày cấp";
            this.lblNgay_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dteNgay_Sinh
            // 
            this.dteNgay_Sinh.bAllowEmpty = true;
            this.dteNgay_Sinh.bRequire = false;
            this.dteNgay_Sinh.bSelectOnFocus = false;
            this.dteNgay_Sinh.bShowDateTimePicker = true;
            this.dteNgay_Sinh.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dteNgay_Sinh.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Sinh.Location = new System.Drawing.Point(104, 19);
            this.dteNgay_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.dteNgay_Sinh.Mask = "00/00/0000";
            this.dteNgay_Sinh.Name = "dteNgay_Sinh";
            this.dteNgay_Sinh.Size = new System.Drawing.Size(89, 20);
            this.dteNgay_Sinh.TabIndex = 0;
            // 
            // lblNgay_Sinh
            // 
            this.lblNgay_Sinh.AutoEllipsis = true;
            this.lblNgay_Sinh.AutoSize = true;
            this.lblNgay_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay_Sinh.Location = new System.Drawing.Point(14, 21);
            this.lblNgay_Sinh.Name = "lblNgay_Sinh";
            this.lblNgay_Sinh.Size = new System.Drawing.Size(54, 13);
            this.lblNgay_Sinh.TabIndex = 161;
            this.lblNgay_Sinh.Tag = "Ngay_Sinh";
            this.lblNgay_Sinh.Text = "Ngày sinh";
            this.lblNgay_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTinh_Trang_HN
            // 
            this.lblTinh_Trang_HN.AutoEllipsis = true;
            this.lblTinh_Trang_HN.AutoSize = true;
            this.lblTinh_Trang_HN.BackColor = System.Drawing.Color.Transparent;
            this.lblTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinh_Trang_HN.Location = new System.Drawing.Point(346, 46);
            this.lblTinh_Trang_HN.Name = "lblTinh_Trang_HN";
            this.lblTinh_Trang_HN.Size = new System.Drawing.Size(54, 13);
            this.lblTinh_Trang_HN.TabIndex = 158;
            this.lblTinh_Trang_HN.Tag = "Tinh_Trang_HN";
            this.lblTinh_Trang_HN.Text = "Hôn nhân";
            this.lblTinh_Trang_HN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNgan_Hang
            // 
            this.lblNgan_Hang.AutoEllipsis = true;
            this.lblNgan_Hang.AutoSize = true;
            this.lblNgan_Hang.BackColor = System.Drawing.Color.Transparent;
            this.lblNgan_Hang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgan_Hang.Location = new System.Drawing.Point(346, 136);
            this.lblNgan_Hang.Name = "lblNgan_Hang";
            this.lblNgan_Hang.Size = new System.Drawing.Size(60, 13);
            this.lblNgan_Hang.TabIndex = 156;
            this.lblNgan_Hang.Tag = "Ngan_Hang";
            this.lblNgan_Hang.Text = "Ngân hàng";
            this.lblNgan_Hang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_So_Thue
            // 
            this.lblMa_So_Thue.AutoEllipsis = true;
            this.lblMa_So_Thue.AutoSize = true;
            this.lblMa_So_Thue.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_So_Thue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa_So_Thue.Location = new System.Drawing.Point(346, 113);
            this.lblMa_So_Thue.Name = "lblMa_So_Thue";
            this.lblMa_So_Thue.Size = new System.Drawing.Size(60, 13);
            this.lblMa_So_Thue.TabIndex = 156;
            this.lblMa_So_Thue.Tag = "Ma_So_Thue";
            this.lblMa_So_Thue.Text = "Mã số thuế";
            this.lblMa_So_Thue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Tk
            // 
            this.lblSo_Tk.AutoEllipsis = true;
            this.lblSo_Tk.AutoSize = true;
            this.lblSo_Tk.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Tk.Location = new System.Drawing.Point(346, 160);
            this.lblSo_Tk.Name = "lblSo_Tk";
            this.lblSo_Tk.Size = new System.Drawing.Size(67, 13);
            this.lblSo_Tk.TabIndex = 157;
            this.lblSo_Tk.Tag = "So_Tk";
            this.lblSo_Tk.Text = "Số tài khoản";
            this.lblSo_Tk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblQuoc_Tich
            // 
            this.lblQuoc_Tich.AutoEllipsis = true;
            this.lblQuoc_Tich.AutoSize = true;
            this.lblQuoc_Tich.BackColor = System.Drawing.Color.Transparent;
            this.lblQuoc_Tich.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoc_Tich.Location = new System.Drawing.Point(346, 91);
            this.lblQuoc_Tich.Name = "lblQuoc_Tich";
            this.lblQuoc_Tich.Size = new System.Drawing.Size(53, 13);
            this.lblQuoc_Tich.TabIndex = 157;
            this.lblQuoc_Tich.Tag = "Quoc_Tich";
            this.lblQuoc_Tich.Text = "Quốc tịch";
            this.lblQuoc_Tich.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTon_Giao
            // 
            this.lblTon_Giao.AutoEllipsis = true;
            this.lblTon_Giao.AutoSize = true;
            this.lblTon_Giao.BackColor = System.Drawing.Color.Transparent;
            this.lblTon_Giao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTon_Giao.Location = new System.Drawing.Point(346, 70);
            this.lblTon_Giao.Name = "lblTon_Giao";
            this.lblTon_Giao.Size = new System.Drawing.Size(49, 13);
            this.lblTon_Giao.TabIndex = 160;
            this.lblTon_Giao.Tag = "Ton_Giao";
            this.lblTon_Giao.Text = "Tôn giáo";
            this.lblTon_Giao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDan_Toc
            // 
            this.lblDan_Toc.AutoEllipsis = true;
            this.lblDan_Toc.AutoSize = true;
            this.lblDan_Toc.BackColor = System.Drawing.Color.Transparent;
            this.lblDan_Toc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDan_Toc.Location = new System.Drawing.Point(14, 160);
            this.lblDan_Toc.Name = "lblDan_Toc";
            this.lblDan_Toc.Size = new System.Drawing.Size(45, 13);
            this.lblDan_Toc.TabIndex = 159;
            this.lblDan_Toc.Tag = "Dan_Toc";
            this.lblDan_Toc.Text = "Dân tộc";
            this.lblDan_Toc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNguyen_Quan
            // 
            this.lblNguyen_Quan.AutoEllipsis = true;
            this.lblNguyen_Quan.AutoSize = true;
            this.lblNguyen_Quan.BackColor = System.Drawing.Color.Transparent;
            this.lblNguyen_Quan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNguyen_Quan.Location = new System.Drawing.Point(14, 137);
            this.lblNguyen_Quan.Name = "lblNguyen_Quan";
            this.lblNguyen_Quan.Size = new System.Drawing.Size(71, 13);
            this.lblNguyen_Quan.TabIndex = 155;
            this.lblNguyen_Quan.Tag = "Nguyen_Quan";
            this.lblNguyen_Quan.Text = "Nguyên quán";
            this.lblNguyen_Quan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblGioi_Tinh
            // 
            this.lblGioi_Tinh.AutoEllipsis = true;
            this.lblGioi_Tinh.AutoSize = true;
            this.lblGioi_Tinh.BackColor = System.Drawing.Color.Transparent;
            this.lblGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioi_Tinh.Location = new System.Drawing.Point(14, 184);
            this.lblGioi_Tinh.Name = "lblGioi_Tinh";
            this.lblGioi_Tinh.Size = new System.Drawing.Size(47, 13);
            this.lblGioi_Tinh.TabIndex = 165;
            this.lblGioi_Tinh.Tag = "Gioi_Tinh";
            this.lblGioi_Tinh.Text = "Giới tính";
            this.lblGioi_Tinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNoi_Sinh
            // 
            this.lblNoi_Sinh.AutoEllipsis = true;
            this.lblNoi_Sinh.AutoSize = true;
            this.lblNoi_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoi_Sinh.Location = new System.Drawing.Point(14, 44);
            this.lblNoi_Sinh.Name = "lblNoi_Sinh";
            this.lblNoi_Sinh.Size = new System.Drawing.Size(45, 13);
            this.lblNoi_Sinh.TabIndex = 162;
            this.lblNoi_Sinh.Tag = "Noi_Sinh";
            this.lblNoi_Sinh.Text = "Nơi sinh";
            this.lblNoi_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_CMND
            // 
            this.lblSo_CMND.AutoEllipsis = true;
            this.lblSo_CMND.AutoSize = true;
            this.lblSo_CMND.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_CMND.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_CMND.Location = new System.Drawing.Point(14, 68);
            this.lblSo_CMND.Name = "lblSo_CMND";
            this.lblSo_CMND.Size = new System.Drawing.Size(55, 13);
            this.lblSo_CMND.TabIndex = 154;
            this.lblSo_CMND.Tag = "So_CMND";
            this.lblSo_CMND.Text = "Số CMND";
            this.lblSo_CMND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNgan_Hang
            // 
            this.txtNgan_Hang.bEnabled = true;
            this.txtNgan_Hang.bIsLookup = false;
            this.txtNgan_Hang.bReadOnly = false;
            this.txtNgan_Hang.bRequire = false;
            this.txtNgan_Hang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgan_Hang.KeyFilter = "";
            this.txtNgan_Hang.Location = new System.Drawing.Point(425, 134);
            this.txtNgan_Hang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgan_Hang.Name = "txtNgan_Hang";
            this.txtNgan_Hang.Size = new System.Drawing.Size(226, 20);
            this.txtNgan_Hang.TabIndex = 14;
            this.txtNgan_Hang.UseAutoFilter = false;
            // 
            // txtSo_Tk
            // 
            this.txtSo_Tk.AccessibleName = "6";
            this.txtSo_Tk.bEnabled = true;
            this.txtSo_Tk.bIsLookup = false;
            this.txtSo_Tk.bReadOnly = false;
            this.txtSo_Tk.bRequire = false;
            this.txtSo_Tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Tk.KeyFilter = "";
            this.txtSo_Tk.Location = new System.Drawing.Point(425, 157);
            this.txtSo_Tk.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Tk.Name = "txtSo_Tk";
            this.txtSo_Tk.Size = new System.Drawing.Size(226, 20);
            this.txtSo_Tk.TabIndex = 15;
            this.txtSo_Tk.UseAutoFilter = false;
            // 
            // txtMa_So_Thue
            // 
            this.txtMa_So_Thue.bEnabled = true;
            this.txtMa_So_Thue.bIsLookup = false;
            this.txtMa_So_Thue.bReadOnly = false;
            this.txtMa_So_Thue.bRequire = false;
            this.txtMa_So_Thue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMa_So_Thue.KeyFilter = "";
            this.txtMa_So_Thue.Location = new System.Drawing.Point(425, 111);
            this.txtMa_So_Thue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_So_Thue.Name = "txtMa_So_Thue";
            this.txtMa_So_Thue.Size = new System.Drawing.Size(226, 20);
            this.txtMa_So_Thue.TabIndex = 13;
            this.txtMa_So_Thue.UseAutoFilter = false;
            // 
            // txtQuoc_Tich
            // 
            this.txtQuoc_Tich.AccessibleName = "6";
            this.txtQuoc_Tich.bEnabled = true;
            this.txtQuoc_Tich.bIsLookup = false;
            this.txtQuoc_Tich.bReadOnly = false;
            this.txtQuoc_Tich.bRequire = false;
            this.txtQuoc_Tich.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuoc_Tich.KeyFilter = "";
            this.txtQuoc_Tich.Location = new System.Drawing.Point(425, 88);
            this.txtQuoc_Tich.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtQuoc_Tich.Name = "txtQuoc_Tich";
            this.txtQuoc_Tich.Size = new System.Drawing.Size(226, 20);
            this.txtQuoc_Tich.TabIndex = 12;
            this.txtQuoc_Tich.UseAutoFilter = false;
            // 
            // txtTon_Giao
            // 
            this.txtTon_Giao.bEnabled = true;
            this.txtTon_Giao.bIsLookup = false;
            this.txtTon_Giao.bReadOnly = false;
            this.txtTon_Giao.bRequire = false;
            this.txtTon_Giao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTon_Giao.KeyFilter = "";
            this.txtTon_Giao.Location = new System.Drawing.Point(425, 65);
            this.txtTon_Giao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTon_Giao.Name = "txtTon_Giao";
            this.txtTon_Giao.Size = new System.Drawing.Size(226, 20);
            this.txtTon_Giao.TabIndex = 11;
            this.txtTon_Giao.UseAutoFilter = false;
            // 
            // txtDan_Toc
            // 
            this.txtDan_Toc.bEnabled = true;
            this.txtDan_Toc.bIsLookup = false;
            this.txtDan_Toc.bReadOnly = false;
            this.txtDan_Toc.bRequire = false;
            this.txtDan_Toc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDan_Toc.KeyFilter = "";
            this.txtDan_Toc.Location = new System.Drawing.Point(104, 157);
            this.txtDan_Toc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDan_Toc.Name = "txtDan_Toc";
            this.txtDan_Toc.Size = new System.Drawing.Size(211, 20);
            this.txtDan_Toc.TabIndex = 6;
            this.txtDan_Toc.UseAutoFilter = false;
            // 
            // txtNguyen_Quan
            // 
            this.txtNguyen_Quan.bEnabled = true;
            this.txtNguyen_Quan.bIsLookup = false;
            this.txtNguyen_Quan.bReadOnly = false;
            this.txtNguyen_Quan.bRequire = false;
            this.txtNguyen_Quan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNguyen_Quan.KeyFilter = "";
            this.txtNguyen_Quan.Location = new System.Drawing.Point(104, 134);
            this.txtNguyen_Quan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNguyen_Quan.Name = "txtNguyen_Quan";
            this.txtNguyen_Quan.Size = new System.Drawing.Size(211, 20);
            this.txtNguyen_Quan.TabIndex = 5;
            this.txtNguyen_Quan.UseAutoFilter = false;
            // 
            // txtNoi_Sinh
            // 
            this.txtNoi_Sinh.bEnabled = true;
            this.txtNoi_Sinh.bIsLookup = false;
            this.txtNoi_Sinh.bReadOnly = false;
            this.txtNoi_Sinh.bRequire = false;
            this.txtNoi_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoi_Sinh.KeyFilter = "";
            this.txtNoi_Sinh.Location = new System.Drawing.Point(104, 42);
            this.txtNoi_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Sinh.Name = "txtNoi_Sinh";
            this.txtNoi_Sinh.Size = new System.Drawing.Size(211, 20);
            this.txtNoi_Sinh.TabIndex = 1;
            this.txtNoi_Sinh.UseAutoFilter = false;
            // 
            // txtSo_CMND
            // 
            this.txtSo_CMND.bEnabled = true;
            this.txtSo_CMND.bIsLookup = false;
            this.txtSo_CMND.bReadOnly = false;
            this.txtSo_CMND.bRequire = false;
            this.txtSo_CMND.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_CMND.KeyFilter = "";
            this.txtSo_CMND.Location = new System.Drawing.Point(104, 65);
            this.txtSo_CMND.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_CMND.Name = "txtSo_CMND";
            this.txtSo_CMND.Size = new System.Drawing.Size(211, 20);
            this.txtSo_CMND.TabIndex = 2;
            this.txtSo_CMND.UseAutoFilter = false;
            // 
            // lblGhi_Chu
            // 
            this.lblGhi_Chu.AutoEllipsis = true;
            this.lblGhi_Chu.AutoSize = true;
            this.lblGhi_Chu.BackColor = System.Drawing.Color.Transparent;
            this.lblGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGhi_Chu.Location = new System.Drawing.Point(5, 114);
            this.lblGhi_Chu.Name = "lblGhi_Chu";
            this.lblGhi_Chu.Size = new System.Drawing.Size(44, 13);
            this.lblGhi_Chu.TabIndex = 183;
            this.lblGhi_Chu.Tag = "Ghi_Chu";
            this.lblGhi_Chu.Text = "Ghi chú";
            this.lblGhi_Chu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGhi_Chu
            // 
            this.txtGhi_Chu.AccessibleName = "6";
            this.txtGhi_Chu.bEnabled = true;
            this.txtGhi_Chu.bIsLookup = false;
            this.txtGhi_Chu.bReadOnly = false;
            this.txtGhi_Chu.bRequire = false;
            this.txtGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhi_Chu.KeyFilter = "";
            this.txtGhi_Chu.Location = new System.Drawing.Point(104, 111);
            this.txtGhi_Chu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtGhi_Chu.Multiline = true;
            this.txtGhi_Chu.Name = "txtGhi_Chu";
            this.txtGhi_Chu.Size = new System.Drawing.Size(547, 21);
            this.txtGhi_Chu.TabIndex = 6;
            this.txtGhi_Chu.UseAutoFilter = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkSend_Mail);
            this.groupBox2.Controls.Add(this.lblGhi_Chu);
            this.groupBox2.Controls.Add(this.lblDia_Chi_TT);
            this.groupBox2.Controls.Add(this.txtGhi_Chu);
            this.groupBox2.Controls.Add(this.txtDia_Chi_TT);
            this.groupBox2.Controls.Add(this.lblHand_Phone);
            this.groupBox2.Controls.Add(this.lblSo_Phone);
            this.groupBox2.Controls.Add(this.lblWebsite);
            this.groupBox2.Controls.Add(this.lblControl8);
            this.groupBox2.Controls.Add(this.lblControl7);
            this.groupBox2.Controls.Add(this.lblEmail);
            this.groupBox2.Controls.Add(this.lblDia_Chi);
            this.groupBox2.Controls.Add(this.txtHand_Phone);
            this.groupBox2.Controls.Add(this.txtSo_Phone);
            this.groupBox2.Controls.Add(this.txtWebsite);
            this.groupBox2.Controls.Add(this.txtChamCong_ID);
            this.groupBox2.Controls.Add(this.txtZalo_ID);
            this.groupBox2.Controls.Add(this.txtEmail);
            this.groupBox2.Controls.Add(this.txtDia_Chi);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 498);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(667, 172);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin liên lạc";
            // 
            // chkSend_Mail
            // 
            this.chkSend_Mail.AutoSize = true;
            this.chkSend_Mail.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkSend_Mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSend_Mail.Location = new System.Drawing.Point(298, 91);
            this.chkSend_Mail.Name = "chkSend_Mail";
            this.chkSend_Mail.Size = new System.Drawing.Size(70, 17);
            this.chkSend_Mail.TabIndex = 5;
            this.chkSend_Mail.Tag = "Send_Mail";
            this.chkSend_Mail.Text = "Gửi Email";
            this.chkSend_Mail.UseVisualStyleBackColor = true;
            // 
            // lblDia_Chi_TT
            // 
            this.lblDia_Chi_TT.AutoEllipsis = true;
            this.lblDia_Chi_TT.AutoSize = true;
            this.lblDia_Chi_TT.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi_TT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDia_Chi_TT.Location = new System.Drawing.Point(5, 22);
            this.lblDia_Chi_TT.Name = "lblDia_Chi_TT";
            this.lblDia_Chi_TT.Size = new System.Drawing.Size(91, 13);
            this.lblDia_Chi_TT.TabIndex = 133;
            this.lblDia_Chi_TT.Tag = "Dia_Chi_TT";
            this.lblDia_Chi_TT.Text = "Địa chỉ thường trú";
            this.lblDia_Chi_TT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDia_Chi_TT
            // 
            this.txtDia_Chi_TT.bEnabled = true;
            this.txtDia_Chi_TT.bIsLookup = false;
            this.txtDia_Chi_TT.bReadOnly = false;
            this.txtDia_Chi_TT.bRequire = false;
            this.txtDia_Chi_TT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDia_Chi_TT.KeyFilter = "";
            this.txtDia_Chi_TT.Location = new System.Drawing.Point(104, 19);
            this.txtDia_Chi_TT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi_TT.Name = "txtDia_Chi_TT";
            this.txtDia_Chi_TT.Size = new System.Drawing.Size(547, 20);
            this.txtDia_Chi_TT.TabIndex = 0;
            this.txtDia_Chi_TT.UseAutoFilter = false;
            // 
            // lblWebsite
            // 
            this.lblWebsite.AutoEllipsis = true;
            this.lblWebsite.AutoSize = true;
            this.lblWebsite.BackColor = System.Drawing.Color.Transparent;
            this.lblWebsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWebsite.Location = new System.Drawing.Point(390, 91);
            this.lblWebsite.Name = "lblWebsite";
            this.lblWebsite.Size = new System.Drawing.Size(46, 13);
            this.lblWebsite.TabIndex = 0;
            this.lblWebsite.Tag = "Website";
            this.lblWebsite.Text = "Website";
            this.lblWebsite.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl8
            // 
            this.lblControl8.AutoEllipsis = true;
            this.lblControl8.AutoSize = true;
            this.lblControl8.BackColor = System.Drawing.Color.Transparent;
            this.lblControl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl8.Location = new System.Drawing.Point(345, 139);
            this.lblControl8.Name = "lblControl8";
            this.lblControl8.Size = new System.Drawing.Size(79, 13);
            this.lblControl8.TabIndex = 122;
            this.lblControl8.Text = "Mã Chấm công";
            this.lblControl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl7
            // 
            this.lblControl7.AutoEllipsis = true;
            this.lblControl7.AutoSize = true;
            this.lblControl7.BackColor = System.Drawing.Color.Transparent;
            this.lblControl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl7.Location = new System.Drawing.Point(5, 138);
            this.lblControl7.Name = "lblControl7";
            this.lblControl7.Size = new System.Drawing.Size(39, 13);
            this.lblControl7.TabIndex = 122;
            this.lblControl7.Text = "ZaloID";
            this.lblControl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtWebsite
            // 
            this.txtWebsite.bEnabled = true;
            this.txtWebsite.bIsLookup = false;
            this.txtWebsite.bReadOnly = false;
            this.txtWebsite.bRequire = false;
            this.txtWebsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWebsite.KeyFilter = "";
            this.txtWebsite.Location = new System.Drawing.Point(446, 88);
            this.txtWebsite.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtWebsite.Name = "txtWebsite";
            this.txtWebsite.Size = new System.Drawing.Size(205, 20);
            this.txtWebsite.TabIndex = 5;
            this.txtWebsite.UseAutoFilter = false;
            // 
            // txtChamCong_ID
            // 
            this.txtChamCong_ID.bEnabled = true;
            this.txtChamCong_ID.bIsLookup = false;
            this.txtChamCong_ID.bReadOnly = false;
            this.txtChamCong_ID.bRequire = false;
            this.txtChamCong_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChamCong_ID.KeyFilter = "";
            this.txtChamCong_ID.Location = new System.Drawing.Point(444, 135);
            this.txtChamCong_ID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtChamCong_ID.Name = "txtChamCong_ID";
            this.txtChamCong_ID.Size = new System.Drawing.Size(207, 20);
            this.txtChamCong_ID.TabIndex = 8;
            this.txtChamCong_ID.UseAutoFilter = false;
            // 
            // txtZalo_ID
            // 
            this.txtZalo_ID.bEnabled = true;
            this.txtZalo_ID.bIsLookup = false;
            this.txtZalo_ID.bReadOnly = false;
            this.txtZalo_ID.bRequire = false;
            this.txtZalo_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZalo_ID.KeyFilter = "";
            this.txtZalo_ID.Location = new System.Drawing.Point(104, 134);
            this.txtZalo_ID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtZalo_ID.Name = "txtZalo_ID";
            this.txtZalo_ID.Size = new System.Drawing.Size(185, 20);
            this.txtZalo_ID.TabIndex = 7;
            this.txtZalo_ID.UseAutoFilter = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(541, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 42);
            this.label1.TabIndex = 152;
            this.label1.Text = "Double click to insert picture";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.CtrlDepend = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_CbNv.ListFilter = new string[0];
            this.txtMa_CbNv.Location = new System.Drawing.Point(113, 8);
            this.txtMa_CbNv.LookupKeyFilter = "";
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // txtMa_Bp
            // 
            this.txtMa_Bp.bEnabled = true;
            this.txtMa_Bp.bIsLookup = false;
            this.txtMa_Bp.bReadOnly = false;
            this.txtMa_Bp.bRequire = false;
            this.txtMa_Bp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Bp.ColumnsView = null;
            this.txtMa_Bp.CtrlDepend = null;
            this.txtMa_Bp.KeyFilter = "Ma_Bp";
            this.txtMa_Bp.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Bp.ListFilter = new string[0];
            this.txtMa_Bp.Location = new System.Drawing.Point(113, 54);
            this.txtMa_Bp.LookupKeyFilter = "";
            this.txtMa_Bp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Bp.Name = "txtMa_Bp";
            this.txtMa_Bp.Size = new System.Drawing.Size(120, 20);
            this.txtMa_Bp.TabIndex = 3;
            this.txtMa_Bp.UseAutoFilter = true;
            // 
            // txtMa_ViTri
            // 
            this.txtMa_ViTri.bEnabled = true;
            this.txtMa_ViTri.bIsLookup = false;
            this.txtMa_ViTri.bReadOnly = false;
            this.txtMa_ViTri.bRequire = false;
            this.txtMa_ViTri.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_ViTri.ColumnsView = null;
            this.txtMa_ViTri.CtrlDepend = null;
            this.txtMa_ViTri.KeyFilter = "Ma_ViTri";
            this.txtMa_ViTri.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_ViTri.ListFilter = new string[0];
            this.txtMa_ViTri.Location = new System.Drawing.Point(113, 77);
            this.txtMa_ViTri.LookupKeyFilter = "";
            this.txtMa_ViTri.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_ViTri.Name = "txtMa_ViTri";
            this.txtMa_ViTri.Size = new System.Drawing.Size(120, 20);
            this.txtMa_ViTri.TabIndex = 5;
            this.txtMa_ViTri.UseAutoFilter = true;
            // 
            // lbtTen_ViTri
            // 
            this.lbtTen_ViTri.AutoEllipsis = true;
            this.lbtTen_ViTri.AutoSize = true;
            this.lbtTen_ViTri.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_ViTri.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_ViTri.Location = new System.Drawing.Point(237, 81);
            this.lbtTen_ViTri.Name = "lbtTen_ViTri";
            this.lbtTen_ViTri.Size = new System.Drawing.Size(50, 13);
            this.lbtTen_ViTri.TabIndex = 157;
            this.lbtTen_ViTri.Text = "Tên vị trí";
            this.lbtTen_ViTri.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_ViTri
            // 
            this.lblMa_ViTri.AutoEllipsis = true;
            this.lblMa_ViTri.AutoSize = true;
            this.lblMa_ViTri.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_ViTri.Location = new System.Drawing.Point(21, 80);
            this.lblMa_ViTri.Name = "lblMa_ViTri";
            this.lblMa_ViTri.Size = new System.Drawing.Size(46, 13);
            this.lblMa_ViTri.TabIndex = 158;
            this.lblMa_ViTri.Tag = "Ma_ViTri";
            this.lblMa_ViTri.Text = "Mã vị trí";
            this.lblMa_ViTri.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Data
            // 
            this.txtMa_Data.bEnabled = true;
            this.txtMa_Data.bIsLookup = false;
            this.txtMa_Data.bReadOnly = false;
            this.txtMa_Data.bRequire = false;
            this.txtMa_Data.KeyFilter = "";
            this.txtMa_Data.Location = new System.Drawing.Point(13, 681);
            this.txtMa_Data.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Data.Name = "txtMa_Data";
            this.txtMa_Data.ReadOnly = true;
            this.txtMa_Data.Size = new System.Drawing.Size(68, 20);
            this.txtMa_Data.TabIndex = 159;
            this.txtMa_Data.UseAutoFilter = false;
            // 
            // btXoa_Anh
            // 
            this.btXoa_Anh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btXoa_Anh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa_Anh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btXoa_Anh.Image = ((System.Drawing.Image)(resources.GetObject("btXoa_Anh.Image")));
            this.btXoa_Anh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btXoa_Anh.Location = new System.Drawing.Point(661, 81);
            this.btXoa_Anh.Name = "btXoa_Anh";
            this.btXoa_Anh.Size = new System.Drawing.Size(24, 24);
            this.btXoa_Anh.TabIndex = 161;
            this.btXoa_Anh.TabStop = false;
            this.btXoa_Anh.Tag = "";
            this.btXoa_Anh.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chkIs_Bang_Cap);
            this.groupBox3.Controls.Add(this.chkIs_Hanh_Kiem);
            this.groupBox3.Controls.Add(this.chkIs_Huan_Luyen);
            this.groupBox3.Controls.Add(this.chkIs_Ho_Khau);
            this.groupBox3.Controls.Add(this.chkIs_SYLL);
            this.groupBox3.Controls.Add(this.chkIs_Don_XinViec);
            this.groupBox3.Controls.Add(this.chkIs_Hinh_Anh);
            this.groupBox3.Controls.Add(this.chkIs_Suc_Khoe);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(13, 404);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(666, 84);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Hồ sơ";
            // 
            // chkIs_Bang_Cap
            // 
            this.chkIs_Bang_Cap.AutoSize = true;
            this.chkIs_Bang_Cap.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Bang_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Bang_Cap.Location = new System.Drawing.Point(499, 18);
            this.chkIs_Bang_Cap.Name = "chkIs_Bang_Cap";
            this.chkIs_Bang_Cap.Size = new System.Drawing.Size(72, 17);
            this.chkIs_Bang_Cap.TabIndex = 6;
            this.chkIs_Bang_Cap.Tag = "Is_Bang_Cap";
            this.chkIs_Bang_Cap.Text = "Bằng cấp";
            this.chkIs_Bang_Cap.UseVisualStyleBackColor = true;
            // 
            // chkIs_Hanh_Kiem
            // 
            this.chkIs_Hanh_Kiem.AutoSize = true;
            this.chkIs_Hanh_Kiem.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Hanh_Kiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Hanh_Kiem.Location = new System.Drawing.Point(312, 64);
            this.chkIs_Hanh_Kiem.Name = "chkIs_Hanh_Kiem";
            this.chkIs_Hanh_Kiem.Size = new System.Drawing.Size(136, 17);
            this.chkIs_Hanh_Kiem.TabIndex = 5;
            this.chkIs_Hanh_Kiem.Tag = "Is_Hanh_Kiem";
            this.chkIs_Hanh_Kiem.Text = "Chứng nhận hạnh kiểm";
            this.chkIs_Hanh_Kiem.UseVisualStyleBackColor = true;
            // 
            // chkIs_Huan_Luyen
            // 
            this.chkIs_Huan_Luyen.AutoSize = true;
            this.chkIs_Huan_Luyen.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Huan_Luyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Huan_Luyen.Location = new System.Drawing.Point(499, 41);
            this.chkIs_Huan_Luyen.Name = "chkIs_Huan_Luyen";
            this.chkIs_Huan_Luyen.Size = new System.Drawing.Size(119, 17);
            this.chkIs_Huan_Luyen.TabIndex = 7;
            this.chkIs_Huan_Luyen.Tag = "Is_Huan_Luyen";
            this.chkIs_Huan_Luyen.Text = "Huấn luyện an toàn";
            this.chkIs_Huan_Luyen.UseVisualStyleBackColor = true;
            // 
            // chkIs_Ho_Khau
            // 
            this.chkIs_Ho_Khau.AutoSize = true;
            this.chkIs_Ho_Khau.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Ho_Khau.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Ho_Khau.Location = new System.Drawing.Point(312, 41);
            this.chkIs_Ho_Khau.Name = "chkIs_Ho_Khau";
            this.chkIs_Ho_Khau.Size = new System.Drawing.Size(67, 17);
            this.chkIs_Ho_Khau.TabIndex = 4;
            this.chkIs_Ho_Khau.Tag = "Is_Ho_Khau";
            this.chkIs_Ho_Khau.Text = "Hộ khẩu";
            this.chkIs_Ho_Khau.UseVisualStyleBackColor = true;
            // 
            // chkIs_SYLL
            // 
            this.chkIs_SYLL.AutoSize = true;
            this.chkIs_SYLL.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_SYLL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_SYLL.Location = new System.Drawing.Point(312, 18);
            this.chkIs_SYLL.Name = "chkIs_SYLL";
            this.chkIs_SYLL.Size = new System.Drawing.Size(88, 17);
            this.chkIs_SYLL.TabIndex = 3;
            this.chkIs_SYLL.Tag = "Is_SYLL";
            this.chkIs_SYLL.Text = "Sơ yếu lý lịch";
            this.chkIs_SYLL.UseVisualStyleBackColor = true;
            // 
            // chkIs_Don_XinViec
            // 
            this.chkIs_Don_XinViec.AutoSize = true;
            this.chkIs_Don_XinViec.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Don_XinViec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Don_XinViec.Location = new System.Drawing.Point(103, 64);
            this.chkIs_Don_XinViec.Name = "chkIs_Don_XinViec";
            this.chkIs_Don_XinViec.Size = new System.Drawing.Size(85, 17);
            this.chkIs_Don_XinViec.TabIndex = 2;
            this.chkIs_Don_XinViec.Tag = "Is_Don_XinViec";
            this.chkIs_Don_XinViec.Text = "Đơn xin việc";
            this.chkIs_Don_XinViec.UseVisualStyleBackColor = true;
            // 
            // chkIs_Hinh_Anh
            // 
            this.chkIs_Hinh_Anh.AutoSize = true;
            this.chkIs_Hinh_Anh.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Hinh_Anh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Hinh_Anh.Location = new System.Drawing.Point(103, 41);
            this.chkIs_Hinh_Anh.Name = "chkIs_Hinh_Anh";
            this.chkIs_Hinh_Anh.Size = new System.Drawing.Size(63, 17);
            this.chkIs_Hinh_Anh.TabIndex = 1;
            this.chkIs_Hinh_Anh.Tag = "Is_Hinh_Anh";
            this.chkIs_Hinh_Anh.Text = "Ảnh thẻ";
            this.chkIs_Hinh_Anh.UseVisualStyleBackColor = true;
            // 
            // chkIs_Suc_Khoe
            // 
            this.chkIs_Suc_Khoe.AutoSize = true;
            this.chkIs_Suc_Khoe.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkIs_Suc_Khoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Suc_Khoe.Location = new System.Drawing.Point(103, 18);
            this.chkIs_Suc_Khoe.Name = "chkIs_Suc_Khoe";
            this.chkIs_Suc_Khoe.Size = new System.Drawing.Size(123, 17);
            this.chkIs_Suc_Khoe.TabIndex = 0;
            this.chkIs_Suc_Khoe.Tag = "Is_Suc_Khoe";
            this.chkIs_Suc_Khoe.Text = "Giấy khám sức khỏe";
            this.chkIs_Suc_Khoe.UseVisualStyleBackColor = true;
            // 
            // lblMa_Kv
            // 
            this.lblMa_Kv.AutoEllipsis = true;
            this.lblMa_Kv.AutoSize = true;
            this.lblMa_Kv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_Kv.Location = new System.Drawing.Point(21, 103);
            this.lblMa_Kv.Name = "lblMa_Kv";
            this.lblMa_Kv.Size = new System.Drawing.Size(64, 13);
            this.lblMa_Kv.TabIndex = 158;
            this.lblMa_Kv.Tag = "Ma_Kv";
            this.lblMa_Kv.Text = "Mã khu vực";
            this.lblMa_Kv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbtTen_Kv
            // 
            this.lbtTen_Kv.AutoEllipsis = true;
            this.lbtTen_Kv.AutoSize = true;
            this.lbtTen_Kv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_Kv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_Kv.Location = new System.Drawing.Point(236, 104);
            this.lbtTen_Kv.Name = "lbtTen_Kv";
            this.lbtTen_Kv.Size = new System.Drawing.Size(69, 13);
            this.lbtTen_Kv.TabIndex = 157;
            this.lbtTen_Kv.Text = "Tên Khu vực";
            this.lbtTen_Kv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Kv
            // 
            this.txtMa_Kv.bEnabled = true;
            this.txtMa_Kv.bIsLookup = false;
            this.txtMa_Kv.bReadOnly = false;
            this.txtMa_Kv.bRequire = false;
            this.txtMa_Kv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Kv.ColumnsView = null;
            this.txtMa_Kv.CtrlDepend = null;
            this.txtMa_Kv.KeyFilter = "Ma_Kv";
            this.txtMa_Kv.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Kv.ListFilter = new string[0];
            this.txtMa_Kv.Location = new System.Drawing.Point(113, 100);
            this.txtMa_Kv.LookupKeyFilter = "";
            this.txtMa_Kv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Kv.Name = "txtMa_Kv";
            this.txtMa_Kv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_Kv.TabIndex = 6;
            this.txtMa_Kv.UseAutoFilter = true;
            // 
            // lblControl4
            // 
            this.lblControl4.AutoEllipsis = true;
            this.lblControl4.AutoSize = true;
            this.lblControl4.BackColor = System.Drawing.Color.Transparent;
            this.lblControl4.Location = new System.Drawing.Point(361, 61);
            this.lblControl4.Name = "lblControl4";
            this.lblControl4.Size = new System.Drawing.Size(40, 13);
            this.lblControl4.TabIndex = 126;
            this.lblControl4.Tag = "";
            this.lblControl4.Text = "Leader";
            this.lblControl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Cbnv_Leader
            // 
            this.txtMa_Cbnv_Leader.bEnabled = true;
            this.txtMa_Cbnv_Leader.bIsLookup = false;
            this.txtMa_Cbnv_Leader.bReadOnly = false;
            this.txtMa_Cbnv_Leader.bRequire = false;
            this.txtMa_Cbnv_Leader.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Cbnv_Leader.ColumnsView = null;
            this.txtMa_Cbnv_Leader.CtrlDepend = null;
            this.txtMa_Cbnv_Leader.KeyFilter = "Ma_Cbnv";
            this.txtMa_Cbnv_Leader.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Cbnv_Leader.ListFilter = new string[0];
            this.txtMa_Cbnv_Leader.Location = new System.Drawing.Point(439, 56);
            this.txtMa_Cbnv_Leader.LookupKeyFilter = "";
            this.txtMa_Cbnv_Leader.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Cbnv_Leader.Name = "txtMa_Cbnv_Leader";
            this.txtMa_Cbnv_Leader.Size = new System.Drawing.Size(99, 20);
            this.txtMa_Cbnv_Leader.TabIndex = 7;
            this.txtMa_Cbnv_Leader.UseAutoFilter = true;
            // 
            // lblControl5
            // 
            this.lblControl5.AutoEllipsis = true;
            this.lblControl5.AutoSize = true;
            this.lblControl5.BackColor = System.Drawing.Color.Transparent;
            this.lblControl5.Location = new System.Drawing.Point(359, 80);
            this.lblControl5.Name = "lblControl5";
            this.lblControl5.Size = new System.Drawing.Size(44, 13);
            this.lblControl5.TabIndex = 158;
            this.lblControl5.Tag = "";
            this.lblControl5.Text = "Địa bàn";
            this.lblControl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDia_Ban
            // 
            this.txtDia_Ban.bEnabled = true;
            this.txtDia_Ban.bIsLookup = false;
            this.txtDia_Ban.bReadOnly = false;
            this.txtDia_Ban.bRequire = false;
            this.txtDia_Ban.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDia_Ban.ColumnsView = null;
            this.txtDia_Ban.CtrlDepend = null;
            this.txtDia_Ban.KeyFilter = "Zone_ID";
            this.txtDia_Ban.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtDia_Ban.ListFilter = new string[0];
            this.txtDia_Ban.Location = new System.Drawing.Point(439, 77);
            this.txtDia_Ban.LookupKeyFilter = "";
            this.txtDia_Ban.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Ban.Name = "txtDia_Ban";
            this.txtDia_Ban.Size = new System.Drawing.Size(99, 20);
            this.txtDia_Ban.TabIndex = 8;
            this.txtDia_Ban.UseAutoFilter = true;
            // 
            // dteNgay_Bd
            // 
            this.dteNgay_Bd.bAllowEmpty = true;
            this.dteNgay_Bd.bRequire = false;
            this.dteNgay_Bd.bSelectOnFocus = false;
            this.dteNgay_Bd.bShowDateTimePicker = true;
            this.dteNgay_Bd.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Bd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dteNgay_Bd.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Bd.Location = new System.Drawing.Point(439, 99);
            this.dteNgay_Bd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.dteNgay_Bd.Mask = "00/00/0000";
            this.dteNgay_Bd.Name = "dteNgay_Bd";
            this.dteNgay_Bd.Size = new System.Drawing.Size(99, 20);
            this.dteNgay_Bd.TabIndex = 9;
            // 
            // lblControl6
            // 
            this.lblControl6.AutoEllipsis = true;
            this.lblControl6.AutoSize = true;
            this.lblControl6.BackColor = System.Drawing.Color.Transparent;
            this.lblControl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl6.Location = new System.Drawing.Point(359, 103);
            this.lblControl6.Name = "lblControl6";
            this.lblControl6.Size = new System.Drawing.Size(48, 13);
            this.lblControl6.TabIndex = 161;
            this.lblControl6.Tag = "Ngay_Bd";
            this.lblControl6.Text = "Ngày Bd";
            this.lblControl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl9
            // 
            this.lblControl9.AutoEllipsis = true;
            this.lblControl9.AutoSize = true;
            this.lblControl9.BackColor = System.Drawing.Color.Transparent;
            this.lblControl9.Location = new System.Drawing.Point(362, 37);
            this.lblControl9.Name = "lblControl9";
            this.lblControl9.Size = new System.Drawing.Size(68, 13);
            this.lblControl9.TabIndex = 126;
            this.lblControl9.Tag = "";
            this.lblControl9.Text = "Ngành Hàng";
            this.lblControl9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Loai1
            // 
            this.txtMa_Loai1.bEnabled = true;
            this.txtMa_Loai1.bIsLookup = false;
            this.txtMa_Loai1.bReadOnly = false;
            this.txtMa_Loai1.bRequire = false;
            this.txtMa_Loai1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Loai1.ColumnsView = null;
            this.txtMa_Loai1.CtrlDepend = null;
            this.txtMa_Loai1.KeyFilter = "Ma_Cbnv";
            this.txtMa_Loai1.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Loai1.ListFilter = new string[0];
            this.txtMa_Loai1.Location = new System.Drawing.Point(439, 32);
            this.txtMa_Loai1.LookupKeyFilter = "";
            this.txtMa_Loai1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Loai1.Name = "txtMa_Loai1";
            this.txtMa_Loai1.Size = new System.Drawing.Size(99, 20);
            this.txtMa_Loai1.TabIndex = 4;
            this.txtMa_Loai1.UseAutoFilter = true;
            // 
            // lblControl11
            // 
            this.lblControl11.AutoEllipsis = true;
            this.lblControl11.AutoSize = true;
            this.lblControl11.BackColor = System.Drawing.Color.Transparent;
            this.lblControl11.Location = new System.Drawing.Point(21, 127);
            this.lblControl11.Name = "lblControl11";
            this.lblControl11.Size = new System.Drawing.Size(92, 13);
            this.lblControl11.TabIndex = 158;
            this.lblControl11.Tag = "";
            this.lblControl11.Text = "Mã NVBH(MERP)";
            this.lblControl11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Cbnv_MERP
            // 
            this.txtMa_Cbnv_MERP.bEnabled = true;
            this.txtMa_Cbnv_MERP.bIsLookup = false;
            this.txtMa_Cbnv_MERP.bReadOnly = false;
            this.txtMa_Cbnv_MERP.bRequire = false;
            this.txtMa_Cbnv_MERP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Cbnv_MERP.ColumnsView = null;
            this.txtMa_Cbnv_MERP.CtrlDepend = null;
            this.txtMa_Cbnv_MERP.KeyFilter = "Ma_Kv";
            this.txtMa_Cbnv_MERP.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Cbnv_MERP.ListFilter = new string[0];
            this.txtMa_Cbnv_MERP.Location = new System.Drawing.Point(113, 122);
            this.txtMa_Cbnv_MERP.LookupKeyFilter = "";
            this.txtMa_Cbnv_MERP.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Cbnv_MERP.Name = "txtMa_Cbnv_MERP";
            this.txtMa_Cbnv_MERP.Size = new System.Drawing.Size(120, 20);
            this.txtMa_Cbnv_MERP.TabIndex = 6;
            this.txtMa_Cbnv_MERP.UseAutoFilter = true;
            // 
            // frmEmployee_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 753);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btXoa_Anh);
            this.Controls.Add(this.txtMa_Data);
            this.Controls.Add(this.txtMa_Cbnv_MERP);
            this.Controls.Add(this.txtMa_Kv);
            this.Controls.Add(this.txtDia_Ban);
            this.Controls.Add(this.txtMa_ViTri);
            this.Controls.Add(this.lbtTen_Kv);
            this.Controls.Add(this.lbtTen_ViTri);
            this.Controls.Add(this.lblControl11);
            this.Controls.Add(this.lblMa_Kv);
            this.Controls.Add(this.lblControl5);
            this.Controls.Add(this.dteNgay_Bd);
            this.Controls.Add(this.lblControl6);
            this.Controls.Add(this.lblMa_ViTri);
            this.Controls.Add(this.txtMa_Loai1);
            this.Controls.Add(this.txtMa_Cbnv_Leader);
            this.Controls.Add(this.txtMa_Bp);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lbtTen_Bp);
            this.Controls.Add(this.picHinh);
            this.Controls.Add(this.lblControl2);
            this.Controls.Add(this.lblControl9);
            this.Controls.Add(this.lblControl19);
            this.Controls.Add(this.lblControl4);
            this.Controls.Add(this.lblControl14);
            this.Controls.Add(this.lblControl1);
            this.Controls.Add(this.txtTen_CbNv);
            this.Controls.Add(this.txtBi_Danh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "frmEmployee_Edit";
            this.Text = "frmEmployee";
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private Epoint.Systems.Controls.lblControl lbtTen_Bp;
		private System.Windows.Forms.PictureBox picHinh;
		private Epoint.Systems.Controls.lblControl lblHand_Phone;
		private Epoint.Systems.Controls.lblControl lblSo_Phone;
        private Epoint.Systems.Controls.lblControl lblControl2;
		private Epoint.Systems.Controls.lblControl lblEmail;
		private Epoint.Systems.Controls.lblControl lblDia_Chi;
		private Epoint.Systems.Controls.lblControl lblControl14;
		private Epoint.Systems.Controls.lblControl lblControl1;
		private Epoint.Systems.Controls.txtTextBox txtHand_Phone;
		private Epoint.Systems.Controls.txtTextBox txtSo_Phone;
        private Epoint.Systems.Controls.txtTextBox txtTen_CbNv;
		private Epoint.Systems.Controls.txtTextBox txtEmail;
        private Epoint.Systems.Controls.txtTextBox txtDia_Chi;
		public Epoint.Systems.Customizes.btgAccept btgAccept;
		private Epoint.Systems.Controls.txtTextBox txtBi_Danh;
		private Epoint.Systems.Controls.lblControl lblControl19;
		private System.Windows.Forms.GroupBox groupBox1;
		private Epoint.Systems.Controls.cboControl cboTinh_Trang_HN;
		private Epoint.Systems.Controls.cboControl cboGioi_Tinh;
		private Epoint.Systems.Controls.txtDateTime dteNgay_Sinh;
		private Epoint.Systems.Controls.lblControl lblNgay_Sinh;
		private Epoint.Systems.Controls.lblControl lblTinh_Trang_HN;
		private Epoint.Systems.Controls.lblControl lblMa_So_Thue;
		private Epoint.Systems.Controls.lblControl lblQuoc_Tich;
		private Epoint.Systems.Controls.lblControl lblTon_Giao;
		private Epoint.Systems.Controls.lblControl lblDan_Toc;
		private Epoint.Systems.Controls.lblControl lblNguyen_Quan;
		private Epoint.Systems.Controls.lblControl lblGioi_Tinh;
		private Epoint.Systems.Controls.lblControl lblNoi_Sinh;
		private Epoint.Systems.Controls.lblControl lblSo_CMND;
		private Epoint.Systems.Controls.txtTextBox txtMa_So_Thue;
		private Epoint.Systems.Controls.txtTextBox txtQuoc_Tich;
		private Epoint.Systems.Controls.txtTextBox txtTon_Giao;
		private Epoint.Systems.Controls.txtTextBox txtDan_Toc;
		private Epoint.Systems.Controls.txtTextBox txtNguyen_Quan;
		private Epoint.Systems.Controls.txtTextBox txtNoi_Sinh;
		private Epoint.Systems.Controls.txtTextBox txtSo_CMND;
		private Epoint.Systems.Controls.txtDateTime txtNgay_Cap;
        private Epoint.Systems.Controls.lblControl lblNgay_Cap;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label1;
		private Epoint.Systems.Controls.lblControl lblWebsite;
		private Epoint.Systems.Controls.txtTextBox txtWebsite;
		private Epoint.Systems.Controls.lblControl lblNgan_Hang;
		private Epoint.Systems.Controls.lblControl lblSo_Tk;
		private Epoint.Systems.Controls.txtTextBox txtNgan_Hang;
        private Epoint.Systems.Controls.txtTextBox txtSo_Tk;
        private Systems.Controls.txtTextLookup txtMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_Bp;
        private Systems.Controls.lblControl lblNoi_Cap;
        private Systems.Controls.txtTextBox txtNoi_Cap;
        private Systems.Controls.lblControl lblDia_Chi_TT;
        private Systems.Controls.txtTextBox txtDia_Chi_TT;
        private Systems.Controls.lblControl lblGhi_Chu;
        private Systems.Controls.txtTextBox txtGhi_Chu;
        private Systems.Controls.txtTextLookup txtMa_ViTri;
        private Systems.Controls.lblControl lbtTen_ViTri;
        private Systems.Controls.lblControl lblMa_ViTri;
        private Systems.Controls.txtTextBox txtMa_Data;
        private Systems.Controls.chkControl chkSend_Mail;
        private Systems.Controls.btControl btXoa_Anh;
        private Systems.Controls.lblControl lblTrinh_Do;
        private Systems.Controls.txtTextBox txtTrinh_Do;
        private System.Windows.Forms.GroupBox groupBox3;
        private Systems.Controls.chkControl chkIs_SYLL;
        private Systems.Controls.chkControl chkIs_Don_XinViec;
        private Systems.Controls.chkControl chkIs_Hinh_Anh;
        private Systems.Controls.chkControl chkIs_Suc_Khoe;
        private Systems.Controls.chkControl chkIs_Bang_Cap;
        private Systems.Controls.chkControl chkIs_Hanh_Kiem;
        private Systems.Controls.chkControl chkIs_Huan_Luyen;
        private Systems.Controls.chkControl chkIs_Ho_Khau;
        private Systems.Controls.lblControl lblMa_Kv;
        private Systems.Controls.lblControl lbtTen_Kv;
        private Systems.Controls.txtTextLookup txtMa_Kv;
        private Systems.Controls.cboControl cboTrang_Thai;
        private Systems.Controls.lblControl lblControl3;
        private Systems.Controls.lblControl lblControl4;
        private Systems.Controls.txtTextLookup txtMa_Cbnv_Leader;
        private Systems.Controls.lblControl lblControl5;
        private Systems.Controls.txtTextLookup txtDia_Ban;
        private Systems.Controls.txtDateTime dteNgay_Bd;
        private Systems.Controls.lblControl lblControl6;
        private Systems.Controls.lblControl lblControl8;
        private Systems.Controls.lblControl lblControl7;
        private Systems.Controls.txtTextBox txtChamCong_ID;
        private Systems.Controls.txtTextBox txtZalo_ID;
        private Systems.Controls.lblControl lblControl9;
        private Systems.Controls.txtTextLookup txtMa_Loai1;
        private Systems.Controls.lblControl lblSo_Nghi_Viec;
        private Systems.Controls.txtTextBox txtSo_Nghi_Viec;
        private Systems.Controls.txtDateTime txtNgay_End;
        private Systems.Controls.lblControl lblControl10;
        private Systems.Controls.lblControl lblControl11;
        private Systems.Controls.txtTextLookup txtMa_Cbnv_MERP;
    }
}