﻿namespace Epoint.Modules.HRM
{
    partial class frmLamViec_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLamViec_Edit));
            this.lbtTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.lblGhi_Chu = new Epoint.Systems.Controls.lblControl();
            this.txtGhi_Chu = new Epoint.Systems.Controls.txtTextBox();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            this.txtNgay_Thu_Viec = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Thu_Viec = new Epoint.Systems.Controls.lblControl();
            this.chkIs_Thu_Viec = new Epoint.Systems.Controls.chkControl();
            this.lblSo_Nghi_Viec = new Epoint.Systems.Controls.lblControl();
            this.txtSo_Nghi_Viec = new Epoint.Systems.Controls.txtTextBox();
            this.txtNgay_Begin = new Epoint.Systems.Controls.txtDateTime();
            this.lblControl1 = new Epoint.Systems.Controls.lblControl();
            this.chkIs_Nghi_Viec = new Epoint.Systems.Controls.chkControl();
            this.chkIs_Bat_Dau = new Epoint.Systems.Controls.chkControl();
            this.txtNgay_End = new Epoint.Systems.Controls.txtDateTime();
            this.lblControl2 = new Epoint.Systems.Controls.lblControl();
            this.chkIs_Chuyen_Ma_Kv = new Epoint.Systems.Controls.chkControl();
            this.lblControl3 = new Epoint.Systems.Controls.lblControl();
            this.txtNgay_Chuyen_Ma_Kv = new Epoint.Systems.Controls.txtDateTime();
            this.txtMa_Kv_Den = new Epoint.Systems.Controls.txtTextLookup();
            this.lblControl5 = new Epoint.Systems.Controls.lblControl();
            this.lbtTen_Kv = new Epoint.Systems.Controls.lblControl();
            this.lblControl4 = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Kv = new Epoint.Systems.Controls.txtTextLookup();
            this.chkIs_Changed = new Epoint.Systems.Controls.chkControl();
            this.lblControl7 = new Epoint.Systems.Controls.lblControl();
            this.txtNgay_Changed = new Epoint.Systems.Controls.txtDateTime();
            this.lblControl8 = new Epoint.Systems.Controls.lblControl();
            this.txtValue_Current = new Epoint.Systems.Controls.txtTextLookup();
            this.cboType_Changed = new Epoint.Systems.Controls.cboMultiControl();
            this.txtValue_New = new Epoint.Systems.Controls.txtTextLookup();
            this.lblControl6 = new Epoint.Systems.Controls.lblControl();
            this.SuspendLayout();
            // 
            // lbtTen_CbNv
            // 
            this.lbtTen_CbNv.AutoEllipsis = true;
            this.lbtTen_CbNv.AutoSize = true;
            this.lbtTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_CbNv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_CbNv.Location = new System.Drawing.Point(266, 16);
            this.lbtTen_CbNv.Name = "lbtTen_CbNv";
            this.lbtTen_CbNv.Size = new System.Drawing.Size(59, 13);
            this.lbtTen_CbNv.TabIndex = 128;
            this.lbtTen_CbNv.Text = "Ten_CbNv";
            this.lbtTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(388, 557);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(168, 33);
            this.btgAccept.TabIndex = 13;
            // 
            // lblGhi_Chu
            // 
            this.lblGhi_Chu.AutoEllipsis = true;
            this.lblGhi_Chu.AutoSize = true;
            this.lblGhi_Chu.BackColor = System.Drawing.Color.Transparent;
            this.lblGhi_Chu.Location = new System.Drawing.Point(55, 392);
            this.lblGhi_Chu.Name = "lblGhi_Chu";
            this.lblGhi_Chu.Size = new System.Drawing.Size(44, 13);
            this.lblGhi_Chu.TabIndex = 123;
            this.lblGhi_Chu.Tag = "Ghi_Chu";
            this.lblGhi_Chu.Text = "Ghi chú";
            this.lblGhi_Chu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGhi_Chu
            // 
            this.txtGhi_Chu.bEnabled = true;
            this.txtGhi_Chu.bIsLookup = false;
            this.txtGhi_Chu.bReadOnly = false;
            this.txtGhi_Chu.bRequire = false;
            this.txtGhi_Chu.KeyFilter = "";
            this.txtGhi_Chu.Location = new System.Drawing.Point(146, 388);
            this.txtGhi_Chu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtGhi_Chu.Multiline = true;
            this.txtGhi_Chu.Name = "txtGhi_Chu";
            this.txtGhi_Chu.Size = new System.Drawing.Size(415, 40);
            this.txtGhi_Chu.TabIndex = 12;
            this.txtGhi_Chu.UseAutoFilter = false;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(52, 12);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(72, 13);
            this.lblMa_CbNv.TabIndex = 120;
            this.lblMa_CbNv.Tag = "Ma_CbNv";
            this.lblMa_CbNv.Text = "Mã nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.CtrlDepend = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_CbNv.ListFilter = new string[0];
            this.txtMa_CbNv.Location = new System.Drawing.Point(141, 9);
            this.txtMa_CbNv.LookupKeyFilter = "";
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // txtNgay_Thu_Viec
            // 
            this.txtNgay_Thu_Viec.bAllowEmpty = true;
            this.txtNgay_Thu_Viec.bRequire = false;
            this.txtNgay_Thu_Viec.bSelectOnFocus = false;
            this.txtNgay_Thu_Viec.bShowDateTimePicker = true;
            this.txtNgay_Thu_Viec.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Thu_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Thu_Viec.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Thu_Viec.Location = new System.Drawing.Point(141, 77);
            this.txtNgay_Thu_Viec.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Thu_Viec.Mask = "00/00/0000";
            this.txtNgay_Thu_Viec.Name = "txtNgay_Thu_Viec";
            this.txtNgay_Thu_Viec.Size = new System.Drawing.Size(83, 20);
            this.txtNgay_Thu_Viec.TabIndex = 3;
            // 
            // lblNgay_Thu_Viec
            // 
            this.lblNgay_Thu_Viec.AutoEllipsis = true;
            this.lblNgay_Thu_Viec.AutoSize = true;
            this.lblNgay_Thu_Viec.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Thu_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay_Thu_Viec.Location = new System.Drawing.Point(52, 84);
            this.lblNgay_Thu_Viec.Name = "lblNgay_Thu_Viec";
            this.lblNgay_Thu_Viec.Size = new System.Drawing.Size(73, 13);
            this.lblNgay_Thu_Viec.TabIndex = 195;
            this.lblNgay_Thu_Viec.Tag = "Ngay_Thu_Viec";
            this.lblNgay_Thu_Viec.Text = "Ngày thử việc";
            this.lblNgay_Thu_Viec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkIs_Thu_Viec
            // 
            this.chkIs_Thu_Viec.AutoSize = true;
            this.chkIs_Thu_Viec.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Thu_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Thu_Viec.Location = new System.Drawing.Point(52, 61);
            this.chkIs_Thu_Viec.Name = "chkIs_Thu_Viec";
            this.chkIs_Thu_Viec.Size = new System.Drawing.Size(68, 17);
            this.chkIs_Thu_Viec.TabIndex = 2;
            this.chkIs_Thu_Viec.Tag = "Is_Thu_Viec";
            this.chkIs_Thu_Viec.Text = "Thử việc";
            this.chkIs_Thu_Viec.UseVisualStyleBackColor = true;
            // 
            // lblSo_Nghi_Viec
            // 
            this.lblSo_Nghi_Viec.AutoEllipsis = true;
            this.lblSo_Nghi_Viec.AutoSize = true;
            this.lblSo_Nghi_Viec.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Nghi_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Nghi_Viec.Location = new System.Drawing.Point(55, 363);
            this.lblSo_Nghi_Viec.Name = "lblSo_Nghi_Viec";
            this.lblSo_Nghi_Viec.Size = new System.Drawing.Size(85, 13);
            this.lblSo_Nghi_Viec.TabIndex = 194;
            this.lblSo_Nghi_Viec.Tag = "So_Nghi_Viec";
            this.lblSo_Nghi_Viec.Text = "Số QĐ nghỉ việc";
            this.lblSo_Nghi_Viec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSo_Nghi_Viec
            // 
            this.txtSo_Nghi_Viec.AccessibleName = "6";
            this.txtSo_Nghi_Viec.bEnabled = true;
            this.txtSo_Nghi_Viec.bIsLookup = false;
            this.txtSo_Nghi_Viec.bReadOnly = false;
            this.txtSo_Nghi_Viec.bRequire = false;
            this.txtSo_Nghi_Viec.Enabled = false;
            this.txtSo_Nghi_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Nghi_Viec.KeyFilter = "";
            this.txtSo_Nghi_Viec.Location = new System.Drawing.Point(147, 359);
            this.txtSo_Nghi_Viec.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Nghi_Viec.Name = "txtSo_Nghi_Viec";
            this.txtSo_Nghi_Viec.Size = new System.Drawing.Size(415, 20);
            this.txtSo_Nghi_Viec.TabIndex = 11;
            this.txtSo_Nghi_Viec.UseAutoFilter = false;
            // 
            // txtNgay_Begin
            // 
            this.txtNgay_Begin.bAllowEmpty = true;
            this.txtNgay_Begin.bRequire = false;
            this.txtNgay_Begin.bSelectOnFocus = false;
            this.txtNgay_Begin.bShowDateTimePicker = true;
            this.txtNgay_Begin.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Begin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Begin.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Begin.Location = new System.Drawing.Point(141, 143);
            this.txtNgay_Begin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Begin.Mask = "00/00/0000";
            this.txtNgay_Begin.Name = "txtNgay_Begin";
            this.txtNgay_Begin.Size = new System.Drawing.Size(83, 20);
            this.txtNgay_Begin.TabIndex = 5;
            // 
            // lblControl1
            // 
            this.lblControl1.AutoEllipsis = true;
            this.lblControl1.AutoSize = true;
            this.lblControl1.BackColor = System.Drawing.Color.Transparent;
            this.lblControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl1.Location = new System.Drawing.Point(52, 146);
            this.lblControl1.Name = "lblControl1";
            this.lblControl1.Size = new System.Drawing.Size(72, 13);
            this.lblControl1.TabIndex = 193;
            this.lblControl1.Tag = "Ngay_Vao_Lam";
            this.lblControl1.Text = "Ngày vào làm";
            this.lblControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkIs_Nghi_Viec
            // 
            this.chkIs_Nghi_Viec.AutoSize = true;
            this.chkIs_Nghi_Viec.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Nghi_Viec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Nghi_Viec.Location = new System.Drawing.Point(55, 315);
            this.chkIs_Nghi_Viec.Name = "chkIs_Nghi_Viec";
            this.chkIs_Nghi_Viec.Size = new System.Drawing.Size(71, 17);
            this.chkIs_Nghi_Viec.TabIndex = 9;
            this.chkIs_Nghi_Viec.Tag = "Is_Nghi_Viec";
            this.chkIs_Nghi_Viec.Text = "Nghỉ việc";
            this.chkIs_Nghi_Viec.UseVisualStyleBackColor = true;
            // 
            // chkIs_Bat_Dau
            // 
            this.chkIs_Bat_Dau.AutoSize = true;
            this.chkIs_Bat_Dau.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Bat_Dau.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Bat_Dau.Location = new System.Drawing.Point(52, 123);
            this.chkIs_Bat_Dau.Name = "chkIs_Bat_Dau";
            this.chkIs_Bat_Dau.Size = new System.Drawing.Size(83, 17);
            this.chkIs_Bat_Dau.TabIndex = 4;
            this.chkIs_Bat_Dau.Tag = "Is_Bat_Dau";
            this.chkIs_Bat_Dau.Text = "Bắt đầu làm";
            this.chkIs_Bat_Dau.UseVisualStyleBackColor = true;
            // 
            // txtNgay_End
            // 
            this.txtNgay_End.bAllowEmpty = true;
            this.txtNgay_End.bRequire = false;
            this.txtNgay_End.bSelectOnFocus = false;
            this.txtNgay_End.bShowDateTimePicker = true;
            this.txtNgay_End.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_End.Enabled = false;
            this.txtNgay_End.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_End.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_End.Location = new System.Drawing.Point(147, 335);
            this.txtNgay_End.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_End.Mask = "00/00/0000";
            this.txtNgay_End.Name = "txtNgay_End";
            this.txtNgay_End.Size = new System.Drawing.Size(83, 20);
            this.txtNgay_End.TabIndex = 10;
            // 
            // lblControl2
            // 
            this.lblControl2.AutoEllipsis = true;
            this.lblControl2.AutoSize = true;
            this.lblControl2.BackColor = System.Drawing.Color.Transparent;
            this.lblControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl2.Location = new System.Drawing.Point(55, 338);
            this.lblControl2.Name = "lblControl2";
            this.lblControl2.Size = new System.Drawing.Size(78, 13);
            this.lblControl2.TabIndex = 192;
            this.lblControl2.Tag = "Ngay_End";
            this.lblControl2.Text = "Ngày nghỉ việc";
            this.lblControl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkIs_Chuyen_Ma_Kv
            // 
            this.chkIs_Chuyen_Ma_Kv.AutoSize = true;
            this.chkIs_Chuyen_Ma_Kv.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Chuyen_Ma_Kv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Chuyen_Ma_Kv.Location = new System.Drawing.Point(346, 77);
            this.chkIs_Chuyen_Ma_Kv.Name = "chkIs_Chuyen_Ma_Kv";
            this.chkIs_Chuyen_Ma_Kv.Size = new System.Drawing.Size(102, 17);
            this.chkIs_Chuyen_Ma_Kv.TabIndex = 6;
            this.chkIs_Chuyen_Ma_Kv.Tag = "";
            this.chkIs_Chuyen_Ma_Kv.Text = "Chuyển Địa bàn";
            this.chkIs_Chuyen_Ma_Kv.UseVisualStyleBackColor = true;
            this.chkIs_Chuyen_Ma_Kv.Visible = false;
            // 
            // lblControl3
            // 
            this.lblControl3.AutoEllipsis = true;
            this.lblControl3.AutoSize = true;
            this.lblControl3.BackColor = System.Drawing.Color.Transparent;
            this.lblControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl3.Location = new System.Drawing.Point(346, 100);
            this.lblControl3.Name = "lblControl3";
            this.lblControl3.Size = new System.Drawing.Size(70, 13);
            this.lblControl3.TabIndex = 193;
            this.lblControl3.Tag = "Ngay_Vao_Lam";
            this.lblControl3.Text = "Ngày chuyển";
            this.lblControl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblControl3.Visible = false;
            // 
            // txtNgay_Chuyen_Ma_Kv
            // 
            this.txtNgay_Chuyen_Ma_Kv.bAllowEmpty = true;
            this.txtNgay_Chuyen_Ma_Kv.bRequire = false;
            this.txtNgay_Chuyen_Ma_Kv.bSelectOnFocus = false;
            this.txtNgay_Chuyen_Ma_Kv.bShowDateTimePicker = true;
            this.txtNgay_Chuyen_Ma_Kv.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Chuyen_Ma_Kv.Enabled = false;
            this.txtNgay_Chuyen_Ma_Kv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Chuyen_Ma_Kv.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Chuyen_Ma_Kv.Location = new System.Drawing.Point(436, 97);
            this.txtNgay_Chuyen_Ma_Kv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Chuyen_Ma_Kv.Mask = "00/00/0000";
            this.txtNgay_Chuyen_Ma_Kv.Name = "txtNgay_Chuyen_Ma_Kv";
            this.txtNgay_Chuyen_Ma_Kv.Size = new System.Drawing.Size(83, 20);
            this.txtNgay_Chuyen_Ma_Kv.TabIndex = 7;
            this.txtNgay_Chuyen_Ma_Kv.Visible = false;
            // 
            // txtMa_Kv_Den
            // 
            this.txtMa_Kv_Den.bEnabled = true;
            this.txtMa_Kv_Den.bIsLookup = false;
            this.txtMa_Kv_Den.bReadOnly = false;
            this.txtMa_Kv_Den.bRequire = false;
            this.txtMa_Kv_Den.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Kv_Den.ColumnsView = null;
            this.txtMa_Kv_Den.CtrlDepend = null;
            this.txtMa_Kv_Den.Enabled = false;
            this.txtMa_Kv_Den.KeyFilter = "Ma_Kv";
            this.txtMa_Kv_Den.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Kv_Den.ListFilter = new string[0];
            this.txtMa_Kv_Den.Location = new System.Drawing.Point(435, 120);
            this.txtMa_Kv_Den.LookupKeyFilter = "";
            this.txtMa_Kv_Den.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Kv_Den.Name = "txtMa_Kv_Den";
            this.txtMa_Kv_Den.Size = new System.Drawing.Size(84, 20);
            this.txtMa_Kv_Den.TabIndex = 8;
            this.txtMa_Kv_Den.UseAutoFilter = true;
            this.txtMa_Kv_Den.Visible = false;
            // 
            // lblControl5
            // 
            this.lblControl5.AutoEllipsis = true;
            this.lblControl5.AutoSize = true;
            this.lblControl5.BackColor = System.Drawing.Color.Transparent;
            this.lblControl5.Location = new System.Drawing.Point(346, 123);
            this.lblControl5.Name = "lblControl5";
            this.lblControl5.Size = new System.Drawing.Size(44, 13);
            this.lblControl5.TabIndex = 197;
            this.lblControl5.Tag = "";
            this.lblControl5.Text = "Địa bàn";
            this.lblControl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblControl5.Visible = false;
            // 
            // lbtTen_Kv
            // 
            this.lbtTen_Kv.AutoEllipsis = true;
            this.lbtTen_Kv.AutoSize = true;
            this.lbtTen_Kv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_Kv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_Kv.Location = new System.Drawing.Point(543, 127);
            this.lbtTen_Kv.Name = "lbtTen_Kv";
            this.lbtTen_Kv.Size = new System.Drawing.Size(59, 13);
            this.lbtTen_Kv.TabIndex = 128;
            this.lbtTen_Kv.Text = "Ten_CbNv";
            this.lbtTen_Kv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbtTen_Kv.Visible = false;
            // 
            // lblControl4
            // 
            this.lblControl4.AutoEllipsis = true;
            this.lblControl4.AutoSize = true;
            this.lblControl4.BackColor = System.Drawing.Color.Transparent;
            this.lblControl4.Location = new System.Drawing.Point(338, 46);
            this.lblControl4.Name = "lblControl4";
            this.lblControl4.Size = new System.Drawing.Size(65, 13);
            this.lblControl4.TabIndex = 197;
            this.lblControl4.Tag = "";
            this.lblControl4.Text = "Mã Khu vực";
            this.lblControl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblControl4.Visible = false;
            // 
            // txtMa_Kv
            // 
            this.txtMa_Kv.bEnabled = true;
            this.txtMa_Kv.bIsLookup = false;
            this.txtMa_Kv.bReadOnly = false;
            this.txtMa_Kv.bRequire = false;
            this.txtMa_Kv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Kv.ColumnsView = null;
            this.txtMa_Kv.CtrlDepend = null;
            this.txtMa_Kv.KeyFilter = "Ma_Kv";
            this.txtMa_Kv.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtMa_Kv.ListFilter = new string[0];
            this.txtMa_Kv.Location = new System.Drawing.Point(426, 43);
            this.txtMa_Kv.LookupKeyFilter = "";
            this.txtMa_Kv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Kv.Name = "txtMa_Kv";
            this.txtMa_Kv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_Kv.TabIndex = 1;
            this.txtMa_Kv.UseAutoFilter = true;
            this.txtMa_Kv.Visible = false;
            // 
            // chkIs_Changed
            // 
            this.chkIs_Changed.AutoSize = true;
            this.chkIs_Changed.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Changed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Changed.Location = new System.Drawing.Point(55, 184);
            this.chkIs_Changed.Name = "chkIs_Changed";
            this.chkIs_Changed.Size = new System.Drawing.Size(112, 17);
            this.chkIs_Changed.TabIndex = 6;
            this.chkIs_Changed.Tag = "";
            this.chkIs_Changed.Text = "Thay đổi thông tin";
            this.chkIs_Changed.UseVisualStyleBackColor = true;
            // 
            // lblControl7
            // 
            this.lblControl7.AutoEllipsis = true;
            this.lblControl7.AutoSize = true;
            this.lblControl7.BackColor = System.Drawing.Color.Transparent;
            this.lblControl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl7.Location = new System.Drawing.Point(56, 214);
            this.lblControl7.Name = "lblControl7";
            this.lblControl7.Size = new System.Drawing.Size(35, 13);
            this.lblControl7.TabIndex = 193;
            this.lblControl7.Tag = "Ngay_Vao_Lam";
            this.lblControl7.Text = "Ngày ";
            this.lblControl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNgay_Changed
            // 
            this.txtNgay_Changed.bAllowEmpty = true;
            this.txtNgay_Changed.bRequire = false;
            this.txtNgay_Changed.bSelectOnFocus = false;
            this.txtNgay_Changed.bShowDateTimePicker = true;
            this.txtNgay_Changed.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Changed.Enabled = false;
            this.txtNgay_Changed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Changed.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Changed.Location = new System.Drawing.Point(145, 207);
            this.txtNgay_Changed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Changed.Mask = "00/00/0000";
            this.txtNgay_Changed.Name = "txtNgay_Changed";
            this.txtNgay_Changed.Size = new System.Drawing.Size(83, 20);
            this.txtNgay_Changed.TabIndex = 7;
            // 
            // lblControl8
            // 
            this.lblControl8.AutoEllipsis = true;
            this.lblControl8.AutoSize = true;
            this.lblControl8.BackColor = System.Drawing.Color.Transparent;
            this.lblControl8.Location = new System.Drawing.Point(56, 255);
            this.lblControl8.Name = "lblControl8";
            this.lblControl8.Size = new System.Drawing.Size(20, 13);
            this.lblControl8.TabIndex = 197;
            this.lblControl8.Tag = "";
            this.lblControl8.Text = "Từ";
            this.lblControl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtValue_Current
            // 
            this.txtValue_Current.bEnabled = true;
            this.txtValue_Current.bIsLookup = false;
            this.txtValue_Current.bReadOnly = false;
            this.txtValue_Current.bRequire = false;
            this.txtValue_Current.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtValue_Current.ColumnsView = null;
            this.txtValue_Current.CtrlDepend = null;
            this.txtValue_Current.Enabled = false;
            this.txtValue_Current.KeyFilter = "Ma_Kv";
            this.txtValue_Current.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtValue_Current.ListFilter = new string[0];
            this.txtValue_Current.Location = new System.Drawing.Point(144, 252);
            this.txtValue_Current.LookupKeyFilter = "";
            this.txtValue_Current.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtValue_Current.Name = "txtValue_Current";
            this.txtValue_Current.Size = new System.Drawing.Size(120, 20);
            this.txtValue_Current.TabIndex = 8;
            this.txtValue_Current.UseAutoFilter = true;
            // 
            // cboType_Changed
            // 
            this.cboType_Changed.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboType_Changed.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cboType_Changed.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.cboType_Changed.Enabled = false;
            this.cboType_Changed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboType_Changed.InitValue = null;
            this.cboType_Changed.Location = new System.Drawing.Point(144, 229);
            this.cboType_Changed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboType_Changed.MaxLength = 20;
            this.cboType_Changed.Name = "cboType_Changed";
            this.cboType_Changed.Size = new System.Drawing.Size(120, 21);
            this.cboType_Changed.strValueList = null;
            this.cboType_Changed.TabIndex = 198;
            this.cboType_Changed.UpperCase = false;
            this.cboType_Changed.UseAutoComplete = false;
            this.cboType_Changed.UseBindingValue = false;
            // 
            // txtValue_New
            // 
            this.txtValue_New.bEnabled = true;
            this.txtValue_New.bIsLookup = false;
            this.txtValue_New.bReadOnly = false;
            this.txtValue_New.bRequire = false;
            this.txtValue_New.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtValue_New.ColumnsView = null;
            this.txtValue_New.CtrlDepend = null;
            this.txtValue_New.Enabled = false;
            this.txtValue_New.KeyFilter = "Ma_Kv";
            this.txtValue_New.ListControlFilter = new System.Windows.Forms.Control[0];
            this.txtValue_New.ListFilter = new string[0];
            this.txtValue_New.Location = new System.Drawing.Point(331, 252);
            this.txtValue_New.LookupKeyFilter = "";
            this.txtValue_New.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtValue_New.Name = "txtValue_New";
            this.txtValue_New.Size = new System.Drawing.Size(120, 20);
            this.txtValue_New.TabIndex = 8;
            this.txtValue_New.UseAutoFilter = true;
            // 
            // lblControl6
            // 
            this.lblControl6.AutoEllipsis = true;
            this.lblControl6.AutoSize = true;
            this.lblControl6.BackColor = System.Drawing.Color.Transparent;
            this.lblControl6.Location = new System.Drawing.Point(56, 234);
            this.lblControl6.Name = "lblControl6";
            this.lblControl6.Size = new System.Drawing.Size(27, 13);
            this.lblControl6.TabIndex = 197;
            this.lblControl6.Tag = "";
            this.lblControl6.Text = "Loại";
            this.lblControl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmLamViec_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 603);
            this.Controls.Add(this.cboType_Changed);
            this.Controls.Add(this.txtMa_Kv);
            this.Controls.Add(this.txtValue_New);
            this.Controls.Add(this.txtValue_Current);
            this.Controls.Add(this.txtMa_Kv_Den);
            this.Controls.Add(this.lblControl4);
            this.Controls.Add(this.lblControl6);
            this.Controls.Add(this.lblControl8);
            this.Controls.Add(this.lblControl5);
            this.Controls.Add(this.txtNgay_Thu_Viec);
            this.Controls.Add(this.lblNgay_Thu_Viec);
            this.Controls.Add(this.chkIs_Thu_Viec);
            this.Controls.Add(this.lblSo_Nghi_Viec);
            this.Controls.Add(this.txtSo_Nghi_Viec);
            this.Controls.Add(this.txtNgay_Changed);
            this.Controls.Add(this.txtNgay_Chuyen_Ma_Kv);
            this.Controls.Add(this.txtNgay_Begin);
            this.Controls.Add(this.lblControl7);
            this.Controls.Add(this.lblControl3);
            this.Controls.Add(this.lblControl1);
            this.Controls.Add(this.chkIs_Nghi_Viec);
            this.Controls.Add(this.chkIs_Changed);
            this.Controls.Add(this.chkIs_Chuyen_Ma_Kv);
            this.Controls.Add(this.chkIs_Bat_Dau);
            this.Controls.Add(this.txtNgay_End);
            this.Controls.Add(this.lblControl2);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.lbtTen_Kv);
            this.Controls.Add(this.lbtTen_CbNv);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lblGhi_Chu);
            this.Controls.Add(this.txtGhi_Chu);
            this.Controls.Add(this.lblMa_CbNv);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmLamViec_Edit";
            this.Text = "frmLamViec_Edit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Epoint.Systems.Controls.lblControl lbtTen_CbNv;
		public Epoint.Systems.Customizes.btgAccept btgAccept;
        private Epoint.Systems.Controls.lblControl lblGhi_Chu;
        private Epoint.Systems.Controls.txtTextBox txtGhi_Chu;
        private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_CbNv;
        private Systems.Controls.txtDateTime txtNgay_Thu_Viec;
        private Systems.Controls.lblControl lblNgay_Thu_Viec;
        private Systems.Controls.chkControl chkIs_Thu_Viec;
        private Systems.Controls.lblControl lblSo_Nghi_Viec;
        private Systems.Controls.txtTextBox txtSo_Nghi_Viec;
        private Systems.Controls.txtDateTime txtNgay_Begin;
        private Systems.Controls.lblControl lblControl1;
        private Systems.Controls.chkControl chkIs_Nghi_Viec;
        private Systems.Controls.chkControl chkIs_Bat_Dau;
        private Systems.Controls.txtDateTime txtNgay_End;
        private Systems.Controls.lblControl lblControl2;
        private Systems.Controls.chkControl chkIs_Chuyen_Ma_Kv;
        private Systems.Controls.lblControl lblControl3;
        private Systems.Controls.txtDateTime txtNgay_Chuyen_Ma_Kv;
        private Systems.Controls.txtTextLookup txtMa_Kv_Den;
        private Systems.Controls.lblControl lblControl5;
        private Systems.Controls.lblControl lbtTen_Kv;
        private Systems.Controls.lblControl lblControl4;
        private Systems.Controls.txtTextLookup txtMa_Kv;
        private Systems.Controls.chkControl chkIs_Changed;
        private Systems.Controls.lblControl lblControl7;
        private Systems.Controls.txtDateTime txtNgay_Changed;
        private Systems.Controls.lblControl lblControl8;
        private Systems.Controls.txtTextLookup txtValue_Current;
        private Systems.Controls.cboMultiControl cboType_Changed;
        private Systems.Controls.txtTextLookup txtValue_New;
        private Systems.Controls.lblControl lblControl6;
    }
}