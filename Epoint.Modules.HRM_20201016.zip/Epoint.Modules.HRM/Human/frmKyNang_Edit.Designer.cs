﻿namespace Epoint.Modules.HRM
{
    partial class frmKyNang_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKyNang_Edit));
            this.lbtTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            this.lblKy_Nang = new Epoint.Systems.Controls.lblControl();
            this.txtKy_Nang = new Epoint.Systems.Controls.txtTextBox();
            this.lblCap_Do = new Epoint.Systems.Controls.lblControl();
            this.txtCap_Do = new Epoint.Systems.Controls.txtTextBox();
            this.SuspendLayout();
            // 
            // lbtTen_CbNv
            // 
            this.lbtTen_CbNv.AutoEllipsis = true;
            this.lbtTen_CbNv.AutoSize = true;
            this.lbtTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_CbNv.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_CbNv.Location = new System.Drawing.Point(276, 38);
            this.lbtTen_CbNv.Name = "lbtTen_CbNv";
            this.lbtTen_CbNv.Size = new System.Drawing.Size(59, 13);
            this.lbtTen_CbNv.TabIndex = 128;
            this.lbtTen_CbNv.Text = "Ten_CbNv";
            this.lbtTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(394, 116);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(168, 33);
            this.btgAccept.TabIndex = 3;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(24, 38);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(72, 13);
            this.lblMa_CbNv.TabIndex = 120;
            this.lblMa_CbNv.Tag = "Ma_CbNv";
            this.lblMa_CbNv.Text = "Mã nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.Location = new System.Drawing.Point(149, 35);
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // lblKy_Nang
            // 
            this.lblKy_Nang.AutoEllipsis = true;
            this.lblKy_Nang.AutoSize = true;
            this.lblKy_Nang.BackColor = System.Drawing.Color.Transparent;
            this.lblKy_Nang.Location = new System.Drawing.Point(24, 61);
            this.lblKy_Nang.Name = "lblKy_Nang";
            this.lblKy_Nang.Size = new System.Drawing.Size(46, 13);
            this.lblKy_Nang.TabIndex = 130;
            this.lblKy_Nang.Tag = "Ky_Nang";
            this.lblKy_Nang.Text = "Kỹ năng";
            this.lblKy_Nang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtKy_Nang
            // 
            this.txtKy_Nang.bEnabled = true;
            this.txtKy_Nang.bIsLookup = false;
            this.txtKy_Nang.bReadOnly = false;
            this.txtKy_Nang.bRequire = false;
            this.txtKy_Nang.KeyFilter = "";
            this.txtKy_Nang.Location = new System.Drawing.Point(149, 58);
            this.txtKy_Nang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtKy_Nang.Name = "txtKy_Nang";
            this.txtKy_Nang.Size = new System.Drawing.Size(415, 20);
            this.txtKy_Nang.TabIndex = 1;
            this.txtKy_Nang.UseAutoFilter = false;
            // 
            // lblCap_Do
            // 
            this.lblCap_Do.AutoEllipsis = true;
            this.lblCap_Do.AutoSize = true;
            this.lblCap_Do.BackColor = System.Drawing.Color.Transparent;
            this.lblCap_Do.Location = new System.Drawing.Point(24, 84);
            this.lblCap_Do.Name = "lblCap_Do";
            this.lblCap_Do.Size = new System.Drawing.Size(89, 13);
            this.lblCap_Do.TabIndex = 132;
            this.lblCap_Do.Tag = "Cap_Do";
            this.lblCap_Do.Text = "Cấp độ đạt được";
            this.lblCap_Do.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCap_Do
            // 
            this.txtCap_Do.bEnabled = true;
            this.txtCap_Do.bIsLookup = false;
            this.txtCap_Do.bReadOnly = false;
            this.txtCap_Do.bRequire = false;
            this.txtCap_Do.KeyFilter = "";
            this.txtCap_Do.Location = new System.Drawing.Point(149, 81);
            this.txtCap_Do.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtCap_Do.Name = "txtCap_Do";
            this.txtCap_Do.Size = new System.Drawing.Size(415, 20);
            this.txtCap_Do.TabIndex = 2;
            this.txtCap_Do.UseAutoFilter = false;
            // 
            // frmKyNang_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 164);
            this.Controls.Add(this.lblCap_Do);
            this.Controls.Add(this.txtCap_Do);
            this.Controls.Add(this.lblKy_Nang);
            this.Controls.Add(this.txtKy_Nang);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.lbtTen_CbNv);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lblMa_CbNv);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmKyNang_Edit";
            this.Text = "frmKyNang_Edit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Epoint.Systems.Controls.lblControl lbtTen_CbNv;
        public Epoint.Systems.Customizes.btgAccept btgAccept;
        private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_CbNv;
        private Systems.Controls.lblControl lblKy_Nang;
        private Systems.Controls.txtTextBox txtKy_Nang;
        private Systems.Controls.lblControl lblCap_Do;
        private Systems.Controls.txtTextBox txtCap_Do;

	}
}