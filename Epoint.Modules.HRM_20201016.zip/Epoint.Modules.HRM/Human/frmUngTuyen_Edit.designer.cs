﻿namespace Epoint.Modules.HRM
{
	partial class frmUngTuyen_Edit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUngTuyen_Edit));
            this.lbtTen_Bp = new Epoint.Systems.Controls.lblControl();
            this.picHinh = new System.Windows.Forms.PictureBox();
            this.lblHand_Phone = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Phone = new Epoint.Systems.Controls.lblControl();
            this.lblControl2 = new Epoint.Systems.Controls.lblControl();
            this.lblEmail = new Epoint.Systems.Controls.lblControl();
            this.lblDia_Chi = new Epoint.Systems.Controls.lblControl();
            this.lblControl14 = new Epoint.Systems.Controls.lblControl();
            this.lblControl1 = new Epoint.Systems.Controls.lblControl();
            this.txtHand_Phone = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_Phone = new Epoint.Systems.Controls.txtTextBox();
            this.txtTen_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.txtEmail = new Epoint.Systems.Controls.txtTextBox();
            this.txtDia_Chi = new Epoint.Systems.Controls.txtTextBox();
            this.btgAccept = new Epoint.Systems.Customizes.btgAccept();
            this.txtBi_Danh = new Epoint.Systems.Controls.txtTextBox();
            this.lblControl19 = new Epoint.Systems.Controls.lblControl();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkIs_Ung_Tuyen = new Epoint.Systems.Controls.chkControl();
            this.lblGhi_Chu = new Epoint.Systems.Controls.lblControl();
            this.txtGhi_Chu = new Epoint.Systems.Controls.txtTextBox();
            this.lblNoi_Cap = new Epoint.Systems.Controls.lblControl();
            this.txtNoi_Cap = new Epoint.Systems.Controls.txtTextBox();
            this.cboTinh_Trang_HN = new Epoint.Systems.Controls.cboControl();
            this.cboGioi_Tinh = new Epoint.Systems.Controls.cboControl();
            this.txtNgay_Cap = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Cap = new Epoint.Systems.Controls.lblControl();
            this.dteNgay_Sinh = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblTinh_Trang_HN = new Epoint.Systems.Controls.lblControl();
            this.lblNgan_Hang = new Epoint.Systems.Controls.lblControl();
            this.lblMa_So_Thue = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Tk = new Epoint.Systems.Controls.lblControl();
            this.lblQuoc_Tich = new Epoint.Systems.Controls.lblControl();
            this.lblTon_Giao = new Epoint.Systems.Controls.lblControl();
            this.lblDan_Toc = new Epoint.Systems.Controls.lblControl();
            this.lblNguyen_Quan = new Epoint.Systems.Controls.lblControl();
            this.lblGioi_Tinh = new Epoint.Systems.Controls.lblControl();
            this.lblNoi_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblSo_CMND = new Epoint.Systems.Controls.lblControl();
            this.txtNgan_Hang = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_Tk = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_So_Thue = new Epoint.Systems.Controls.txtTextBox();
            this.txtQuoc_Tich = new Epoint.Systems.Controls.txtTextBox();
            this.txtTon_Giao = new Epoint.Systems.Controls.txtTextBox();
            this.txtDan_Toc = new Epoint.Systems.Controls.txtTextBox();
            this.txtNguyen_Quan = new Epoint.Systems.Controls.txtTextBox();
            this.txtNoi_Sinh = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_CMND = new Epoint.Systems.Controls.txtTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblDia_Chi_TT = new Epoint.Systems.Controls.lblControl();
            this.txtDia_Chi_TT = new Epoint.Systems.Controls.txtTextBox();
            this.lblWebsite = new Epoint.Systems.Controls.lblControl();
            this.txtWebsite = new Epoint.Systems.Controls.txtTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextLookup();
            this.txtMa_Bp = new Epoint.Systems.Controls.txtTextLookup();
            this.txtMa_ViTri = new Epoint.Systems.Controls.txtTextLookup();
            this.lbtTen_ViTri = new Epoint.Systems.Controls.lblControl();
            this.lblMa_ViTri = new Epoint.Systems.Controls.lblControl();
            this.txtMa_Data = new Epoint.Systems.Controls.txtTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbtTen_Bp
            // 
            this.lbtTen_Bp.AutoEllipsis = true;
            this.lbtTen_Bp.AutoSize = true;
            this.lbtTen_Bp.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_Bp.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_Bp.Location = new System.Drawing.Point(241, 70);
            this.lbtTen_Bp.Name = "lbtTen_Bp";
            this.lbtTen_Bp.Size = new System.Drawing.Size(71, 13);
            this.lbtTen_Bp.TabIndex = 6;
            this.lbtTen_Bp.Text = "Tên bộ phận ";
            this.lbtTen_Bp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picHinh
            // 
            this.picHinh.BackColor = System.Drawing.Color.Transparent;
            this.picHinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picHinh.Location = new System.Drawing.Point(556, 12);
            this.picHinh.Name = "picHinh";
            this.picHinh.Size = new System.Drawing.Size(85, 104);
            this.picHinh.TabIndex = 146;
            this.picHinh.TabStop = false;
            // 
            // lblHand_Phone
            // 
            this.lblHand_Phone.AutoEllipsis = true;
            this.lblHand_Phone.AutoSize = true;
            this.lblHand_Phone.BackColor = System.Drawing.Color.Transparent;
            this.lblHand_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHand_Phone.Location = new System.Drawing.Point(305, 75);
            this.lblHand_Phone.Name = "lblHand_Phone";
            this.lblHand_Phone.Size = new System.Drawing.Size(45, 13);
            this.lblHand_Phone.TabIndex = 131;
            this.lblHand_Phone.Text = "Di động";
            this.lblHand_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Phone
            // 
            this.lblSo_Phone.AutoEllipsis = true;
            this.lblSo_Phone.AutoSize = true;
            this.lblSo_Phone.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Phone.Location = new System.Drawing.Point(11, 73);
            this.lblSo_Phone.Name = "lblSo_Phone";
            this.lblSo_Phone.Size = new System.Drawing.Size(55, 13);
            this.lblSo_Phone.TabIndex = 129;
            this.lblSo_Phone.Text = "Điện thoại";
            this.lblSo_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl2
            // 
            this.lblControl2.AutoEllipsis = true;
            this.lblControl2.AutoSize = true;
            this.lblControl2.BackColor = System.Drawing.Color.Transparent;
            this.lblControl2.Location = new System.Drawing.Point(23, 46);
            this.lblControl2.Name = "lblControl2";
            this.lblControl2.Size = new System.Drawing.Size(76, 13);
            this.lblControl2.TabIndex = 139;
            this.lblControl2.Tag = "Ten_CbNv";
            this.lblControl2.Text = "Tên nhân viên";
            this.lblControl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoEllipsis = true;
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(11, 97);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 122;
            this.lblEmail.Text = "Email";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDia_Chi
            // 
            this.lblDia_Chi.AutoEllipsis = true;
            this.lblDia_Chi.AutoSize = true;
            this.lblDia_Chi.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDia_Chi.Location = new System.Drawing.Point(11, 50);
            this.lblDia_Chi.Name = "lblDia_Chi";
            this.lblDia_Chi.Size = new System.Drawing.Size(75, 13);
            this.lblDia_Chi.TabIndex = 120;
            this.lblDia_Chi.Tag = "Dia_Chi_TAM_TRU";
            this.lblDia_Chi.Text = "Địa chỉ tạm trú";
            this.lblDia_Chi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl14
            // 
            this.lblControl14.AutoEllipsis = true;
            this.lblControl14.AutoSize = true;
            this.lblControl14.BackColor = System.Drawing.Color.Transparent;
            this.lblControl14.Location = new System.Drawing.Point(22, 68);
            this.lblControl14.Name = "lblControl14";
            this.lblControl14.Size = new System.Drawing.Size(64, 13);
            this.lblControl14.TabIndex = 126;
            this.lblControl14.Tag = "Ma_Bp";
            this.lblControl14.Text = "Mã bộ phận";
            this.lblControl14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl1
            // 
            this.lblControl1.AutoEllipsis = true;
            this.lblControl1.AutoSize = true;
            this.lblControl1.BackColor = System.Drawing.Color.Transparent;
            this.lblControl1.Location = new System.Drawing.Point(23, 22);
            this.lblControl1.Name = "lblControl1";
            this.lblControl1.Size = new System.Drawing.Size(72, 13);
            this.lblControl1.TabIndex = 123;
            this.lblControl1.Tag = "Ma_CbNv";
            this.lblControl1.Text = "Mã nhân viên";
            this.lblControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtHand_Phone
            // 
            this.txtHand_Phone.bEnabled = true;
            this.txtHand_Phone.bIsLookup = false;
            this.txtHand_Phone.bReadOnly = false;
            this.txtHand_Phone.bRequire = false;
            this.txtHand_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHand_Phone.KeyFilter = "";
            this.txtHand_Phone.Location = new System.Drawing.Point(365, 71);
            this.txtHand_Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtHand_Phone.Name = "txtHand_Phone";
            this.txtHand_Phone.Size = new System.Drawing.Size(286, 20);
            this.txtHand_Phone.TabIndex = 3;
            this.txtHand_Phone.UseAutoFilter = false;
            // 
            // txtSo_Phone
            // 
            this.txtSo_Phone.bEnabled = true;
            this.txtSo_Phone.bIsLookup = false;
            this.txtSo_Phone.bReadOnly = false;
            this.txtSo_Phone.bRequire = false;
            this.txtSo_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Phone.KeyFilter = "";
            this.txtSo_Phone.Location = new System.Drawing.Point(104, 70);
            this.txtSo_Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Phone.Name = "txtSo_Phone";
            this.txtSo_Phone.Size = new System.Drawing.Size(185, 20);
            this.txtSo_Phone.TabIndex = 2;
            this.txtSo_Phone.UseAutoFilter = false;
            // 
            // txtTen_CbNv
            // 
            this.txtTen_CbNv.bEnabled = true;
            this.txtTen_CbNv.bIsLookup = false;
            this.txtTen_CbNv.bReadOnly = false;
            this.txtTen_CbNv.bRequire = false;
            this.txtTen_CbNv.KeyFilter = "";
            this.txtTen_CbNv.Location = new System.Drawing.Point(113, 42);
            this.txtTen_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTen_CbNv.Name = "txtTen_CbNv";
            this.txtTen_CbNv.Size = new System.Drawing.Size(398, 20);
            this.txtTen_CbNv.TabIndex = 2;
            this.txtTen_CbNv.UseAutoFilter = false;
            // 
            // txtEmail
            // 
            this.txtEmail.bEnabled = true;
            this.txtEmail.bIsLookup = false;
            this.txtEmail.bReadOnly = false;
            this.txtEmail.bRequire = false;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.KeyFilter = "";
            this.txtEmail.Location = new System.Drawing.Point(104, 93);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(185, 20);
            this.txtEmail.TabIndex = 4;
            this.txtEmail.UseAutoFilter = false;
            // 
            // txtDia_Chi
            // 
            this.txtDia_Chi.bEnabled = true;
            this.txtDia_Chi.bIsLookup = false;
            this.txtDia_Chi.bReadOnly = false;
            this.txtDia_Chi.bRequire = false;
            this.txtDia_Chi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDia_Chi.KeyFilter = "";
            this.txtDia_Chi.Location = new System.Drawing.Point(104, 47);
            this.txtDia_Chi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi.Name = "txtDia_Chi";
            this.txtDia_Chi.Size = new System.Drawing.Size(547, 20);
            this.txtDia_Chi.TabIndex = 1;
            this.txtDia_Chi.UseAutoFilter = false;
            // 
            // btgAccept
            // 
            this.btgAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btgAccept.Location = new System.Drawing.Point(494, 572);
            this.btgAccept.Margin = new System.Windows.Forms.Padding(2);
            this.btgAccept.Name = "btgAccept";
            this.btgAccept.Size = new System.Drawing.Size(169, 34);
            this.btgAccept.TabIndex = 9;
            // 
            // txtBi_Danh
            // 
            this.txtBi_Danh.bEnabled = true;
            this.txtBi_Danh.bIsLookup = false;
            this.txtBi_Danh.bReadOnly = false;
            this.txtBi_Danh.bRequire = false;
            this.txtBi_Danh.KeyFilter = "";
            this.txtBi_Danh.Location = new System.Drawing.Point(291, 19);
            this.txtBi_Danh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtBi_Danh.Name = "txtBi_Danh";
            this.txtBi_Danh.Size = new System.Drawing.Size(220, 20);
            this.txtBi_Danh.TabIndex = 1;
            this.txtBi_Danh.UseAutoFilter = false;
            // 
            // lblControl19
            // 
            this.lblControl19.AutoEllipsis = true;
            this.lblControl19.AutoSize = true;
            this.lblControl19.BackColor = System.Drawing.Color.Transparent;
            this.lblControl19.Location = new System.Drawing.Point(241, 23);
            this.lblControl19.Name = "lblControl19";
            this.lblControl19.Size = new System.Drawing.Size(45, 13);
            this.lblControl19.TabIndex = 121;
            this.lblControl19.Text = "Bí danh";
            this.lblControl19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkIs_Ung_Tuyen);
            this.groupBox1.Controls.Add(this.lblGhi_Chu);
            this.groupBox1.Controls.Add(this.txtGhi_Chu);
            this.groupBox1.Controls.Add(this.lblNoi_Cap);
            this.groupBox1.Controls.Add(this.txtNoi_Cap);
            this.groupBox1.Controls.Add(this.cboTinh_Trang_HN);
            this.groupBox1.Controls.Add(this.cboGioi_Tinh);
            this.groupBox1.Controls.Add(this.txtNgay_Cap);
            this.groupBox1.Controls.Add(this.lblNgay_Cap);
            this.groupBox1.Controls.Add(this.dteNgay_Sinh);
            this.groupBox1.Controls.Add(this.lblNgay_Sinh);
            this.groupBox1.Controls.Add(this.lblTinh_Trang_HN);
            this.groupBox1.Controls.Add(this.lblNgan_Hang);
            this.groupBox1.Controls.Add(this.lblMa_So_Thue);
            this.groupBox1.Controls.Add(this.lblSo_Tk);
            this.groupBox1.Controls.Add(this.lblQuoc_Tich);
            this.groupBox1.Controls.Add(this.lblTon_Giao);
            this.groupBox1.Controls.Add(this.lblDan_Toc);
            this.groupBox1.Controls.Add(this.lblNguyen_Quan);
            this.groupBox1.Controls.Add(this.lblGioi_Tinh);
            this.groupBox1.Controls.Add(this.lblNoi_Sinh);
            this.groupBox1.Controls.Add(this.lblSo_CMND);
            this.groupBox1.Controls.Add(this.txtNgan_Hang);
            this.groupBox1.Controls.Add(this.txtSo_Tk);
            this.groupBox1.Controls.Add(this.txtMa_So_Thue);
            this.groupBox1.Controls.Add(this.txtQuoc_Tich);
            this.groupBox1.Controls.Add(this.txtTon_Giao);
            this.groupBox1.Controls.Add(this.txtDan_Toc);
            this.groupBox1.Controls.Add(this.txtNguyen_Quan);
            this.groupBox1.Controls.Add(this.txtNoi_Sinh);
            this.groupBox1.Controls.Add(this.txtSo_CMND);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 127);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(667, 296);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin cá nhân";
            // 
            // chkIs_Ung_Tuyen
            // 
            this.chkIs_Ung_Tuyen.AutoSize = true;
            this.chkIs_Ung_Tuyen.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIs_Ung_Tuyen.Checked = true;
            this.chkIs_Ung_Tuyen.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIs_Ung_Tuyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIs_Ung_Tuyen.Location = new System.Drawing.Point(576, 194);
            this.chkIs_Ung_Tuyen.Name = "chkIs_Ung_Tuyen";
            this.chkIs_Ung_Tuyen.Size = new System.Drawing.Size(75, 17);
            this.chkIs_Ung_Tuyen.TabIndex = 184;
            this.chkIs_Ung_Tuyen.Tag = "Is_Ung_Tuyen";
            this.chkIs_Ung_Tuyen.Text = "Ứng tuyển";
            this.chkIs_Ung_Tuyen.UseVisualStyleBackColor = true;
            // 
            // lblGhi_Chu
            // 
            this.lblGhi_Chu.AutoEllipsis = true;
            this.lblGhi_Chu.AutoSize = true;
            this.lblGhi_Chu.BackColor = System.Drawing.Color.Transparent;
            this.lblGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGhi_Chu.Location = new System.Drawing.Point(15, 226);
            this.lblGhi_Chu.Name = "lblGhi_Chu";
            this.lblGhi_Chu.Size = new System.Drawing.Size(44, 13);
            this.lblGhi_Chu.TabIndex = 183;
            this.lblGhi_Chu.Tag = "Ghi_Chu";
            this.lblGhi_Chu.Text = "Ghi chú";
            this.lblGhi_Chu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGhi_Chu
            // 
            this.txtGhi_Chu.AccessibleName = "6";
            this.txtGhi_Chu.bEnabled = true;
            this.txtGhi_Chu.bIsLookup = false;
            this.txtGhi_Chu.bReadOnly = false;
            this.txtGhi_Chu.bRequire = false;
            this.txtGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhi_Chu.KeyFilter = "";
            this.txtGhi_Chu.Location = new System.Drawing.Point(102, 223);
            this.txtGhi_Chu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtGhi_Chu.Multiline = true;
            this.txtGhi_Chu.Name = "txtGhi_Chu";
            this.txtGhi_Chu.Size = new System.Drawing.Size(549, 59);
            this.txtGhi_Chu.TabIndex = 20;
            this.txtGhi_Chu.UseAutoFilter = false;
            // 
            // lblNoi_Cap
            // 
            this.lblNoi_Cap.AutoEllipsis = true;
            this.lblNoi_Cap.AutoSize = true;
            this.lblNoi_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoi_Cap.Location = new System.Drawing.Point(14, 123);
            this.lblNoi_Cap.Name = "lblNoi_Cap";
            this.lblNoi_Cap.Size = new System.Drawing.Size(44, 13);
            this.lblNoi_Cap.TabIndex = 171;
            this.lblNoi_Cap.Tag = "Noi_Cap";
            this.lblNoi_Cap.Text = "Nơi cấp";
            this.lblNoi_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNoi_Cap
            // 
            this.txtNoi_Cap.bEnabled = true;
            this.txtNoi_Cap.bIsLookup = false;
            this.txtNoi_Cap.bReadOnly = false;
            this.txtNoi_Cap.bRequire = false;
            this.txtNoi_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoi_Cap.KeyFilter = "";
            this.txtNoi_Cap.Location = new System.Drawing.Point(104, 120);
            this.txtNoi_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Cap.Name = "txtNoi_Cap";
            this.txtNoi_Cap.Size = new System.Drawing.Size(183, 20);
            this.txtNoi_Cap.TabIndex = 4;
            this.txtNoi_Cap.UseAutoFilter = false;
            // 
            // cboTinh_Trang_HN
            // 
            this.cboTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTinh_Trang_HN.FormattingEnabled = true;
            this.cboTinh_Trang_HN.InitValue = null;
            this.cboTinh_Trang_HN.Items.AddRange(new object[] {
            "Đã kết hôn",
            "Độc thân"});
            this.cboTinh_Trang_HN.Location = new System.Drawing.Point(425, 50);
            this.cboTinh_Trang_HN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboTinh_Trang_HN.Name = "cboTinh_Trang_HN";
            this.cboTinh_Trang_HN.Size = new System.Drawing.Size(226, 21);
            this.cboTinh_Trang_HN.strValueList = null;
            this.cboTinh_Trang_HN.TabIndex = 8;
            this.cboTinh_Trang_HN.UseAutoComplete = false;
            this.cboTinh_Trang_HN.UseBindingValue = false;
            // 
            // cboGioi_Tinh
            // 
            this.cboGioi_Tinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboGioi_Tinh.FormattingEnabled = true;
            this.cboGioi_Tinh.InitValue = null;
            this.cboGioi_Tinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.cboGioi_Tinh.Location = new System.Drawing.Point(104, 190);
            this.cboGioi_Tinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboGioi_Tinh.Name = "cboGioi_Tinh";
            this.cboGioi_Tinh.Size = new System.Drawing.Size(89, 21);
            this.cboGioi_Tinh.strValueList = null;
            this.cboGioi_Tinh.TabIndex = 7;
            this.cboGioi_Tinh.UseAutoComplete = false;
            this.cboGioi_Tinh.UseBindingValue = false;
            // 
            // txtNgay_Cap
            // 
            this.txtNgay_Cap.bAllowEmpty = true;
            this.txtNgay_Cap.bRequire = false;
            this.txtNgay_Cap.bSelectOnFocus = false;
            this.txtNgay_Cap.bShowDateTimePicker = true;
            this.txtNgay_Cap.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_Cap.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Cap.Location = new System.Drawing.Point(104, 97);
            this.txtNgay_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Cap.Mask = "00/00/0000";
            this.txtNgay_Cap.Name = "txtNgay_Cap";
            this.txtNgay_Cap.Size = new System.Drawing.Size(89, 20);
            this.txtNgay_Cap.TabIndex = 3;
            // 
            // lblNgay_Cap
            // 
            this.lblNgay_Cap.AutoEllipsis = true;
            this.lblNgay_Cap.AutoSize = true;
            this.lblNgay_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Cap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay_Cap.Location = new System.Drawing.Point(14, 99);
            this.lblNgay_Cap.Name = "lblNgay_Cap";
            this.lblNgay_Cap.Size = new System.Drawing.Size(53, 13);
            this.lblNgay_Cap.TabIndex = 161;
            this.lblNgay_Cap.Tag = "Ngay_Cap";
            this.lblNgay_Cap.Text = "Ngày cấp";
            this.lblNgay_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dteNgay_Sinh
            // 
            this.dteNgay_Sinh.bAllowEmpty = true;
            this.dteNgay_Sinh.bRequire = false;
            this.dteNgay_Sinh.bSelectOnFocus = false;
            this.dteNgay_Sinh.bShowDateTimePicker = true;
            this.dteNgay_Sinh.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dteNgay_Sinh.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Sinh.Location = new System.Drawing.Point(104, 28);
            this.dteNgay_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.dteNgay_Sinh.Mask = "00/00/0000";
            this.dteNgay_Sinh.Name = "dteNgay_Sinh";
            this.dteNgay_Sinh.Size = new System.Drawing.Size(89, 20);
            this.dteNgay_Sinh.TabIndex = 0;
            // 
            // lblNgay_Sinh
            // 
            this.lblNgay_Sinh.AutoEllipsis = true;
            this.lblNgay_Sinh.AutoSize = true;
            this.lblNgay_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay_Sinh.Location = new System.Drawing.Point(14, 30);
            this.lblNgay_Sinh.Name = "lblNgay_Sinh";
            this.lblNgay_Sinh.Size = new System.Drawing.Size(54, 13);
            this.lblNgay_Sinh.TabIndex = 161;
            this.lblNgay_Sinh.Tag = "Ngay_Sinh";
            this.lblNgay_Sinh.Text = "Ngày sinh";
            this.lblNgay_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTinh_Trang_HN
            // 
            this.lblTinh_Trang_HN.AutoEllipsis = true;
            this.lblTinh_Trang_HN.AutoSize = true;
            this.lblTinh_Trang_HN.BackColor = System.Drawing.Color.Transparent;
            this.lblTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinh_Trang_HN.Location = new System.Drawing.Point(338, 55);
            this.lblTinh_Trang_HN.Name = "lblTinh_Trang_HN";
            this.lblTinh_Trang_HN.Size = new System.Drawing.Size(54, 13);
            this.lblTinh_Trang_HN.TabIndex = 158;
            this.lblTinh_Trang_HN.Tag = "Tinh_Trang_HN";
            this.lblTinh_Trang_HN.Text = "Hôn nhân";
            this.lblTinh_Trang_HN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNgan_Hang
            // 
            this.lblNgan_Hang.AutoEllipsis = true;
            this.lblNgan_Hang.AutoSize = true;
            this.lblNgan_Hang.BackColor = System.Drawing.Color.Transparent;
            this.lblNgan_Hang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgan_Hang.Location = new System.Drawing.Point(338, 145);
            this.lblNgan_Hang.Name = "lblNgan_Hang";
            this.lblNgan_Hang.Size = new System.Drawing.Size(60, 13);
            this.lblNgan_Hang.TabIndex = 156;
            this.lblNgan_Hang.Tag = "Ngan_Hang";
            this.lblNgan_Hang.Text = "Ngân hàng";
            this.lblNgan_Hang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_So_Thue
            // 
            this.lblMa_So_Thue.AutoEllipsis = true;
            this.lblMa_So_Thue.AutoSize = true;
            this.lblMa_So_Thue.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_So_Thue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa_So_Thue.Location = new System.Drawing.Point(338, 122);
            this.lblMa_So_Thue.Name = "lblMa_So_Thue";
            this.lblMa_So_Thue.Size = new System.Drawing.Size(60, 13);
            this.lblMa_So_Thue.TabIndex = 156;
            this.lblMa_So_Thue.Tag = "Ma_So_Thue";
            this.lblMa_So_Thue.Text = "Mã số thuế";
            this.lblMa_So_Thue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Tk
            // 
            this.lblSo_Tk.AutoEllipsis = true;
            this.lblSo_Tk.AutoSize = true;
            this.lblSo_Tk.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_Tk.Location = new System.Drawing.Point(338, 169);
            this.lblSo_Tk.Name = "lblSo_Tk";
            this.lblSo_Tk.Size = new System.Drawing.Size(67, 13);
            this.lblSo_Tk.TabIndex = 157;
            this.lblSo_Tk.Tag = "So_Tk";
            this.lblSo_Tk.Text = "Số tài khoản";
            this.lblSo_Tk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblQuoc_Tich
            // 
            this.lblQuoc_Tich.AutoEllipsis = true;
            this.lblQuoc_Tich.AutoSize = true;
            this.lblQuoc_Tich.BackColor = System.Drawing.Color.Transparent;
            this.lblQuoc_Tich.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoc_Tich.Location = new System.Drawing.Point(338, 100);
            this.lblQuoc_Tich.Name = "lblQuoc_Tich";
            this.lblQuoc_Tich.Size = new System.Drawing.Size(53, 13);
            this.lblQuoc_Tich.TabIndex = 157;
            this.lblQuoc_Tich.Tag = "Quoc_Tich";
            this.lblQuoc_Tich.Text = "Quốc tịch";
            this.lblQuoc_Tich.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTon_Giao
            // 
            this.lblTon_Giao.AutoEllipsis = true;
            this.lblTon_Giao.AutoSize = true;
            this.lblTon_Giao.BackColor = System.Drawing.Color.Transparent;
            this.lblTon_Giao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTon_Giao.Location = new System.Drawing.Point(338, 79);
            this.lblTon_Giao.Name = "lblTon_Giao";
            this.lblTon_Giao.Size = new System.Drawing.Size(49, 13);
            this.lblTon_Giao.TabIndex = 160;
            this.lblTon_Giao.Tag = "Ton_Giao";
            this.lblTon_Giao.Text = "Tôn giáo";
            this.lblTon_Giao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDan_Toc
            // 
            this.lblDan_Toc.AutoEllipsis = true;
            this.lblDan_Toc.AutoSize = true;
            this.lblDan_Toc.BackColor = System.Drawing.Color.Transparent;
            this.lblDan_Toc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDan_Toc.Location = new System.Drawing.Point(14, 169);
            this.lblDan_Toc.Name = "lblDan_Toc";
            this.lblDan_Toc.Size = new System.Drawing.Size(45, 13);
            this.lblDan_Toc.TabIndex = 159;
            this.lblDan_Toc.Tag = "Dan_Toc";
            this.lblDan_Toc.Text = "Dân tộc";
            this.lblDan_Toc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNguyen_Quan
            // 
            this.lblNguyen_Quan.AutoEllipsis = true;
            this.lblNguyen_Quan.AutoSize = true;
            this.lblNguyen_Quan.BackColor = System.Drawing.Color.Transparent;
            this.lblNguyen_Quan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNguyen_Quan.Location = new System.Drawing.Point(14, 146);
            this.lblNguyen_Quan.Name = "lblNguyen_Quan";
            this.lblNguyen_Quan.Size = new System.Drawing.Size(71, 13);
            this.lblNguyen_Quan.TabIndex = 155;
            this.lblNguyen_Quan.Tag = "Nguyen_Quan";
            this.lblNguyen_Quan.Text = "Nguyên quán";
            this.lblNguyen_Quan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblGioi_Tinh
            // 
            this.lblGioi_Tinh.AutoEllipsis = true;
            this.lblGioi_Tinh.AutoSize = true;
            this.lblGioi_Tinh.BackColor = System.Drawing.Color.Transparent;
            this.lblGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioi_Tinh.Location = new System.Drawing.Point(14, 193);
            this.lblGioi_Tinh.Name = "lblGioi_Tinh";
            this.lblGioi_Tinh.Size = new System.Drawing.Size(47, 13);
            this.lblGioi_Tinh.TabIndex = 165;
            this.lblGioi_Tinh.Tag = "Gioi_Tinh";
            this.lblGioi_Tinh.Text = "Giới tính";
            this.lblGioi_Tinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNoi_Sinh
            // 
            this.lblNoi_Sinh.AutoEllipsis = true;
            this.lblNoi_Sinh.AutoSize = true;
            this.lblNoi_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoi_Sinh.Location = new System.Drawing.Point(14, 53);
            this.lblNoi_Sinh.Name = "lblNoi_Sinh";
            this.lblNoi_Sinh.Size = new System.Drawing.Size(45, 13);
            this.lblNoi_Sinh.TabIndex = 162;
            this.lblNoi_Sinh.Tag = "Noi_Sinh";
            this.lblNoi_Sinh.Text = "Nơi sinh";
            this.lblNoi_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_CMND
            // 
            this.lblSo_CMND.AutoEllipsis = true;
            this.lblSo_CMND.AutoSize = true;
            this.lblSo_CMND.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_CMND.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSo_CMND.Location = new System.Drawing.Point(14, 77);
            this.lblSo_CMND.Name = "lblSo_CMND";
            this.lblSo_CMND.Size = new System.Drawing.Size(55, 13);
            this.lblSo_CMND.TabIndex = 154;
            this.lblSo_CMND.Tag = "So_CMND";
            this.lblSo_CMND.Text = "Số CMND";
            this.lblSo_CMND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNgan_Hang
            // 
            this.txtNgan_Hang.bEnabled = true;
            this.txtNgan_Hang.bIsLookup = false;
            this.txtNgan_Hang.bReadOnly = false;
            this.txtNgan_Hang.bRequire = false;
            this.txtNgan_Hang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgan_Hang.KeyFilter = "";
            this.txtNgan_Hang.Location = new System.Drawing.Point(425, 143);
            this.txtNgan_Hang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgan_Hang.Name = "txtNgan_Hang";
            this.txtNgan_Hang.Size = new System.Drawing.Size(226, 20);
            this.txtNgan_Hang.TabIndex = 12;
            this.txtNgan_Hang.UseAutoFilter = false;
            // 
            // txtSo_Tk
            // 
            this.txtSo_Tk.AccessibleName = "6";
            this.txtSo_Tk.bEnabled = true;
            this.txtSo_Tk.bIsLookup = false;
            this.txtSo_Tk.bReadOnly = false;
            this.txtSo_Tk.bRequire = false;
            this.txtSo_Tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_Tk.KeyFilter = "";
            this.txtSo_Tk.Location = new System.Drawing.Point(425, 166);
            this.txtSo_Tk.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Tk.Name = "txtSo_Tk";
            this.txtSo_Tk.Size = new System.Drawing.Size(226, 20);
            this.txtSo_Tk.TabIndex = 13;
            this.txtSo_Tk.UseAutoFilter = false;
            // 
            // txtMa_So_Thue
            // 
            this.txtMa_So_Thue.bEnabled = true;
            this.txtMa_So_Thue.bIsLookup = false;
            this.txtMa_So_Thue.bReadOnly = false;
            this.txtMa_So_Thue.bRequire = false;
            this.txtMa_So_Thue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMa_So_Thue.KeyFilter = "";
            this.txtMa_So_Thue.Location = new System.Drawing.Point(425, 120);
            this.txtMa_So_Thue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_So_Thue.Name = "txtMa_So_Thue";
            this.txtMa_So_Thue.Size = new System.Drawing.Size(226, 20);
            this.txtMa_So_Thue.TabIndex = 11;
            this.txtMa_So_Thue.UseAutoFilter = false;
            // 
            // txtQuoc_Tich
            // 
            this.txtQuoc_Tich.AccessibleName = "6";
            this.txtQuoc_Tich.bEnabled = true;
            this.txtQuoc_Tich.bIsLookup = false;
            this.txtQuoc_Tich.bReadOnly = false;
            this.txtQuoc_Tich.bRequire = false;
            this.txtQuoc_Tich.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuoc_Tich.KeyFilter = "";
            this.txtQuoc_Tich.Location = new System.Drawing.Point(425, 97);
            this.txtQuoc_Tich.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtQuoc_Tich.Name = "txtQuoc_Tich";
            this.txtQuoc_Tich.Size = new System.Drawing.Size(226, 20);
            this.txtQuoc_Tich.TabIndex = 10;
            this.txtQuoc_Tich.UseAutoFilter = false;
            // 
            // txtTon_Giao
            // 
            this.txtTon_Giao.bEnabled = true;
            this.txtTon_Giao.bIsLookup = false;
            this.txtTon_Giao.bReadOnly = false;
            this.txtTon_Giao.bRequire = false;
            this.txtTon_Giao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTon_Giao.KeyFilter = "";
            this.txtTon_Giao.Location = new System.Drawing.Point(425, 74);
            this.txtTon_Giao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTon_Giao.Name = "txtTon_Giao";
            this.txtTon_Giao.Size = new System.Drawing.Size(226, 20);
            this.txtTon_Giao.TabIndex = 9;
            this.txtTon_Giao.UseAutoFilter = false;
            // 
            // txtDan_Toc
            // 
            this.txtDan_Toc.bEnabled = true;
            this.txtDan_Toc.bIsLookup = false;
            this.txtDan_Toc.bReadOnly = false;
            this.txtDan_Toc.bRequire = false;
            this.txtDan_Toc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDan_Toc.KeyFilter = "";
            this.txtDan_Toc.Location = new System.Drawing.Point(104, 166);
            this.txtDan_Toc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDan_Toc.Name = "txtDan_Toc";
            this.txtDan_Toc.Size = new System.Drawing.Size(183, 20);
            this.txtDan_Toc.TabIndex = 6;
            this.txtDan_Toc.UseAutoFilter = false;
            // 
            // txtNguyen_Quan
            // 
            this.txtNguyen_Quan.bEnabled = true;
            this.txtNguyen_Quan.bIsLookup = false;
            this.txtNguyen_Quan.bReadOnly = false;
            this.txtNguyen_Quan.bRequire = false;
            this.txtNguyen_Quan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNguyen_Quan.KeyFilter = "";
            this.txtNguyen_Quan.Location = new System.Drawing.Point(104, 143);
            this.txtNguyen_Quan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNguyen_Quan.Name = "txtNguyen_Quan";
            this.txtNguyen_Quan.Size = new System.Drawing.Size(183, 20);
            this.txtNguyen_Quan.TabIndex = 5;
            this.txtNguyen_Quan.UseAutoFilter = false;
            // 
            // txtNoi_Sinh
            // 
            this.txtNoi_Sinh.bEnabled = true;
            this.txtNoi_Sinh.bIsLookup = false;
            this.txtNoi_Sinh.bReadOnly = false;
            this.txtNoi_Sinh.bRequire = false;
            this.txtNoi_Sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoi_Sinh.KeyFilter = "";
            this.txtNoi_Sinh.Location = new System.Drawing.Point(104, 51);
            this.txtNoi_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Sinh.Name = "txtNoi_Sinh";
            this.txtNoi_Sinh.Size = new System.Drawing.Size(183, 20);
            this.txtNoi_Sinh.TabIndex = 1;
            this.txtNoi_Sinh.UseAutoFilter = false;
            // 
            // txtSo_CMND
            // 
            this.txtSo_CMND.bEnabled = true;
            this.txtSo_CMND.bIsLookup = false;
            this.txtSo_CMND.bReadOnly = false;
            this.txtSo_CMND.bRequire = false;
            this.txtSo_CMND.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSo_CMND.KeyFilter = "";
            this.txtSo_CMND.Location = new System.Drawing.Point(104, 74);
            this.txtSo_CMND.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_CMND.Name = "txtSo_CMND";
            this.txtSo_CMND.Size = new System.Drawing.Size(183, 20);
            this.txtSo_CMND.TabIndex = 2;
            this.txtSo_CMND.UseAutoFilter = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblDia_Chi_TT);
            this.groupBox2.Controls.Add(this.txtDia_Chi_TT);
            this.groupBox2.Controls.Add(this.lblHand_Phone);
            this.groupBox2.Controls.Add(this.lblSo_Phone);
            this.groupBox2.Controls.Add(this.lblWebsite);
            this.groupBox2.Controls.Add(this.lblEmail);
            this.groupBox2.Controls.Add(this.lblDia_Chi);
            this.groupBox2.Controls.Add(this.txtHand_Phone);
            this.groupBox2.Controls.Add(this.txtSo_Phone);
            this.groupBox2.Controls.Add(this.txtWebsite);
            this.groupBox2.Controls.Add(this.txtEmail);
            this.groupBox2.Controls.Add(this.txtDia_Chi);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 436);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(667, 124);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin liên lạc";
            // 
            // lblDia_Chi_TT
            // 
            this.lblDia_Chi_TT.AutoEllipsis = true;
            this.lblDia_Chi_TT.AutoSize = true;
            this.lblDia_Chi_TT.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi_TT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDia_Chi_TT.Location = new System.Drawing.Point(11, 27);
            this.lblDia_Chi_TT.Name = "lblDia_Chi_TT";
            this.lblDia_Chi_TT.Size = new System.Drawing.Size(91, 13);
            this.lblDia_Chi_TT.TabIndex = 133;
            this.lblDia_Chi_TT.Tag = "Dia_Chi_TT";
            this.lblDia_Chi_TT.Text = "Địa chỉ thường trú";
            this.lblDia_Chi_TT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDia_Chi_TT
            // 
            this.txtDia_Chi_TT.bEnabled = true;
            this.txtDia_Chi_TT.bIsLookup = false;
            this.txtDia_Chi_TT.bReadOnly = false;
            this.txtDia_Chi_TT.bRequire = false;
            this.txtDia_Chi_TT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDia_Chi_TT.KeyFilter = "";
            this.txtDia_Chi_TT.Location = new System.Drawing.Point(104, 24);
            this.txtDia_Chi_TT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi_TT.Name = "txtDia_Chi_TT";
            this.txtDia_Chi_TT.Size = new System.Drawing.Size(547, 20);
            this.txtDia_Chi_TT.TabIndex = 0;
            this.txtDia_Chi_TT.UseAutoFilter = false;
            // 
            // lblWebsite
            // 
            this.lblWebsite.AutoEllipsis = true;
            this.lblWebsite.AutoSize = true;
            this.lblWebsite.BackColor = System.Drawing.Color.Transparent;
            this.lblWebsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWebsite.Location = new System.Drawing.Point(304, 97);
            this.lblWebsite.Name = "lblWebsite";
            this.lblWebsite.Size = new System.Drawing.Size(46, 13);
            this.lblWebsite.TabIndex = 0;
            this.lblWebsite.Tag = "Website";
            this.lblWebsite.Text = "Website";
            this.lblWebsite.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtWebsite
            // 
            this.txtWebsite.bEnabled = true;
            this.txtWebsite.bIsLookup = false;
            this.txtWebsite.bReadOnly = false;
            this.txtWebsite.bRequire = false;
            this.txtWebsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWebsite.KeyFilter = "";
            this.txtWebsite.Location = new System.Drawing.Point(365, 94);
            this.txtWebsite.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtWebsite.Name = "txtWebsite";
            this.txtWebsite.Size = new System.Drawing.Size(286, 20);
            this.txtWebsite.TabIndex = 5;
            this.txtWebsite.UseAutoFilter = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(541, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 42);
            this.label1.TabIndex = 152;
            this.label1.Text = "Double click to insert picture";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_CbNv.ColumnsView = null;
            this.txtMa_CbNv.KeyFilter = "Ma_CbNv";
            this.txtMa_CbNv.Location = new System.Drawing.Point(113, 19);
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = true;
            // 
            // txtMa_Bp
            // 
            this.txtMa_Bp.bEnabled = true;
            this.txtMa_Bp.bIsLookup = false;
            this.txtMa_Bp.bReadOnly = false;
            this.txtMa_Bp.bRequire = false;
            this.txtMa_Bp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_Bp.ColumnsView = null;
            this.txtMa_Bp.KeyFilter = "Ma_Bp";
            this.txtMa_Bp.Location = new System.Drawing.Point(113, 65);
            this.txtMa_Bp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Bp.Name = "txtMa_Bp";
            this.txtMa_Bp.Size = new System.Drawing.Size(120, 20);
            this.txtMa_Bp.TabIndex = 4;
            this.txtMa_Bp.UseAutoFilter = true;
            // 
            // txtMa_ViTri
            // 
            this.txtMa_ViTri.bEnabled = true;
            this.txtMa_ViTri.bIsLookup = false;
            this.txtMa_ViTri.bReadOnly = false;
            this.txtMa_ViTri.bRequire = false;
            this.txtMa_ViTri.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMa_ViTri.ColumnsView = null;
            this.txtMa_ViTri.KeyFilter = "Ma_ViTri";
            this.txtMa_ViTri.Location = new System.Drawing.Point(113, 88);
            this.txtMa_ViTri.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_ViTri.Name = "txtMa_ViTri";
            this.txtMa_ViTri.Size = new System.Drawing.Size(120, 20);
            this.txtMa_ViTri.TabIndex = 5;
            this.txtMa_ViTri.UseAutoFilter = true;
            // 
            // lbtTen_ViTri
            // 
            this.lbtTen_ViTri.AutoEllipsis = true;
            this.lbtTen_ViTri.AutoSize = true;
            this.lbtTen_ViTri.BackColor = System.Drawing.Color.Transparent;
            this.lbtTen_ViTri.ForeColor = System.Drawing.Color.Blue;
            this.lbtTen_ViTri.Location = new System.Drawing.Point(241, 93);
            this.lbtTen_ViTri.Name = "lbtTen_ViTri";
            this.lbtTen_ViTri.Size = new System.Drawing.Size(50, 13);
            this.lbtTen_ViTri.TabIndex = 154;
            this.lbtTen_ViTri.Text = "Tên vị trí";
            this.lbtTen_ViTri.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_ViTri
            // 
            this.lblMa_ViTri.AutoEllipsis = true;
            this.lblMa_ViTri.AutoSize = true;
            this.lblMa_ViTri.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_ViTri.Location = new System.Drawing.Point(22, 91);
            this.lblMa_ViTri.Name = "lblMa_ViTri";
            this.lblMa_ViTri.Size = new System.Drawing.Size(46, 13);
            this.lblMa_ViTri.TabIndex = 155;
            this.lblMa_ViTri.Tag = "Ma_ViTri";
            this.lblMa_ViTri.Text = "Mã vị trí";
            this.lblMa_ViTri.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_Data
            // 
            this.txtMa_Data.bEnabled = true;
            this.txtMa_Data.bIsLookup = false;
            this.txtMa_Data.bReadOnly = false;
            this.txtMa_Data.bRequire = false;
            this.txtMa_Data.KeyFilter = "";
            this.txtMa_Data.Location = new System.Drawing.Point(13, 585);
            this.txtMa_Data.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Data.Name = "txtMa_Data";
            this.txtMa_Data.ReadOnly = true;
            this.txtMa_Data.Size = new System.Drawing.Size(68, 20);
            this.txtMa_Data.TabIndex = 156;
            this.txtMa_Data.UseAutoFilter = false;
            // 
            // frmUngTuyen_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 615);
            this.Controls.Add(this.txtMa_Data);
            this.Controls.Add(this.txtMa_ViTri);
            this.Controls.Add(this.lbtTen_ViTri);
            this.Controls.Add(this.lblMa_ViTri);
            this.Controls.Add(this.txtMa_Bp);
            this.Controls.Add(this.txtMa_CbNv);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btgAccept);
            this.Controls.Add(this.lbtTen_Bp);
            this.Controls.Add(this.picHinh);
            this.Controls.Add(this.lblControl2);
            this.Controls.Add(this.lblControl19);
            this.Controls.Add(this.lblControl14);
            this.Controls.Add(this.lblControl1);
            this.Controls.Add(this.txtTen_CbNv);
            this.Controls.Add(this.txtBi_Danh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmUngTuyen_Edit";
            this.Text = "frmEmployee";
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private Epoint.Systems.Controls.lblControl lbtTen_Bp;
		private System.Windows.Forms.PictureBox picHinh;
		private Epoint.Systems.Controls.lblControl lblHand_Phone;
		private Epoint.Systems.Controls.lblControl lblSo_Phone;
        private Epoint.Systems.Controls.lblControl lblControl2;
		private Epoint.Systems.Controls.lblControl lblEmail;
		private Epoint.Systems.Controls.lblControl lblDia_Chi;
		private Epoint.Systems.Controls.lblControl lblControl14;
		private Epoint.Systems.Controls.lblControl lblControl1;
		private Epoint.Systems.Controls.txtTextBox txtHand_Phone;
		private Epoint.Systems.Controls.txtTextBox txtSo_Phone;
        private Epoint.Systems.Controls.txtTextBox txtTen_CbNv;
		private Epoint.Systems.Controls.txtTextBox txtEmail;
        private Epoint.Systems.Controls.txtTextBox txtDia_Chi;
		public Epoint.Systems.Customizes.btgAccept btgAccept;
		private Epoint.Systems.Controls.txtTextBox txtBi_Danh;
		private Epoint.Systems.Controls.lblControl lblControl19;
		private System.Windows.Forms.GroupBox groupBox1;
		private Epoint.Systems.Controls.cboControl cboTinh_Trang_HN;
		private Epoint.Systems.Controls.cboControl cboGioi_Tinh;
		private Epoint.Systems.Controls.txtDateTime dteNgay_Sinh;
		private Epoint.Systems.Controls.lblControl lblNgay_Sinh;
		private Epoint.Systems.Controls.lblControl lblTinh_Trang_HN;
		private Epoint.Systems.Controls.lblControl lblMa_So_Thue;
		private Epoint.Systems.Controls.lblControl lblQuoc_Tich;
		private Epoint.Systems.Controls.lblControl lblTon_Giao;
		private Epoint.Systems.Controls.lblControl lblDan_Toc;
		private Epoint.Systems.Controls.lblControl lblNguyen_Quan;
		private Epoint.Systems.Controls.lblControl lblGioi_Tinh;
		private Epoint.Systems.Controls.lblControl lblNoi_Sinh;
		private Epoint.Systems.Controls.lblControl lblSo_CMND;
		private Epoint.Systems.Controls.txtTextBox txtMa_So_Thue;
		private Epoint.Systems.Controls.txtTextBox txtQuoc_Tich;
		private Epoint.Systems.Controls.txtTextBox txtTon_Giao;
		private Epoint.Systems.Controls.txtTextBox txtDan_Toc;
		private Epoint.Systems.Controls.txtTextBox txtNguyen_Quan;
		private Epoint.Systems.Controls.txtTextBox txtNoi_Sinh;
		private Epoint.Systems.Controls.txtTextBox txtSo_CMND;
		private Epoint.Systems.Controls.txtDateTime txtNgay_Cap;
        private Epoint.Systems.Controls.lblControl lblNgay_Cap;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label1;
		private Epoint.Systems.Controls.lblControl lblWebsite;
		private Epoint.Systems.Controls.txtTextBox txtWebsite;
		private Epoint.Systems.Controls.lblControl lblNgan_Hang;
		private Epoint.Systems.Controls.lblControl lblSo_Tk;
		private Epoint.Systems.Controls.txtTextBox txtNgan_Hang;
        private Epoint.Systems.Controls.txtTextBox txtSo_Tk;
        private Systems.Controls.txtTextLookup txtMa_CbNv;
        private Systems.Controls.txtTextLookup txtMa_Bp;
        private Systems.Controls.lblControl lblNoi_Cap;
        private Systems.Controls.txtTextBox txtNoi_Cap;
        private Systems.Controls.lblControl lblDia_Chi_TT;
        private Systems.Controls.txtTextBox txtDia_Chi_TT;
        private Systems.Controls.lblControl lblGhi_Chu;
        private Systems.Controls.txtTextBox txtGhi_Chu;
        private Systems.Controls.chkControl chkIs_Ung_Tuyen;
        private Systems.Controls.txtTextLookup txtMa_ViTri;
        private Systems.Controls.lblControl lbtTen_ViTri;
        private Systems.Controls.lblControl lblMa_ViTri;
        private Systems.Controls.txtTextBox txtMa_Data;



	}
}