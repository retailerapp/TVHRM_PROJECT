﻿namespace Epoint.Modules.HRM
{
    partial class frmEmployee_CongTrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpTTNV = new System.Windows.Forms.TabPage();
            this.lblGhi_Chu = new Epoint.Systems.Controls.lblControl();
            this.txtGhi_Chu = new Epoint.Systems.Controls.txtTextBox();
            this.lblDia_Chi_TT = new Epoint.Systems.Controls.lblControl();
            this.txtDia_Chi_TT = new Epoint.Systems.Controls.txtTextBox();
            this.lblControl11 = new Epoint.Systems.Controls.lblControl();
            this.lblControl17 = new Epoint.Systems.Controls.lblControl();
            this.lblDia_Chi = new Epoint.Systems.Controls.lblControl();
            this.txtSo_Phone = new Epoint.Systems.Controls.txtTextBox();
            this.txtEmail = new Epoint.Systems.Controls.txtTextBox();
            this.txtDia_Chi = new Epoint.Systems.Controls.txtTextBox();
            this.lblMa_ViTri = new Epoint.Systems.Controls.lblControl();
            this.txtMa_ViTri = new Epoint.Systems.Controls.txtTextBox();
            this.cboTinh_Trang_HN = new Epoint.Systems.Controls.cboControl();
            this.lblTinh_Trang_HN = new Epoint.Systems.Controls.lblControl();
            this.cboGioi_Tinh = new Epoint.Systems.Controls.cboControl();
            this.lblGioi_Tinh = new Epoint.Systems.Controls.lblControl();
            this.txtNgay_Cap = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Cap = new Epoint.Systems.Controls.lblControl();
            this.lblNoi_Cap = new Epoint.Systems.Controls.lblControl();
            this.txtNoi_Cap = new Epoint.Systems.Controls.txtTextBox();
            this.picHinh = new System.Windows.Forms.PictureBox();
            this.dteNgay_Sinh = new Epoint.Systems.Controls.txtDateTime();
            this.lblNgay_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblMa_So_Thue = new Epoint.Systems.Controls.lblControl();
            this.lblNgan_Hang = new Epoint.Systems.Controls.lblControl();
            this.lblQuoc_Tich = new Epoint.Systems.Controls.lblControl();
            this.lblSo_Tk = new Epoint.Systems.Controls.lblControl();
            this.lblTon_Giao = new Epoint.Systems.Controls.lblControl();
            this.lblDan_Toc = new Epoint.Systems.Controls.lblControl();
            this.lblNguyen_Quan = new Epoint.Systems.Controls.lblControl();
            this.lblNoi_Sinh = new Epoint.Systems.Controls.lblControl();
            this.lblTen_CbNv = new Epoint.Systems.Controls.lblControl();
            this.lblControl19 = new Epoint.Systems.Controls.lblControl();
            this.lblSo_CMND = new Epoint.Systems.Controls.lblControl();
            this.lblMa_Bp = new Epoint.Systems.Controls.lblControl();
            this.lblMa_CbNv = new Epoint.Systems.Controls.lblControl();
            this.txtMa_So_Thue = new Epoint.Systems.Controls.txtTextBox();
            this.txtNgan_Hang = new Epoint.Systems.Controls.txtTextBox();
            this.txtQuoc_Tich = new Epoint.Systems.Controls.txtTextBox();
            this.txtTextBox2 = new Epoint.Systems.Controls.txtTextBox();
            this.txtTon_Giao = new Epoint.Systems.Controls.txtTextBox();
            this.txtDan_Toc = new Epoint.Systems.Controls.txtTextBox();
            this.txtNguyen_Quan = new Epoint.Systems.Controls.txtTextBox();
            this.txtNoi_Sinh = new Epoint.Systems.Controls.txtTextBox();
            this.txtTen_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.txtBi_Danh = new Epoint.Systems.Controls.txtTextBox();
            this.txtSo_CMND = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_Bp = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_CbNv = new Epoint.Systems.Controls.txtTextBox();
            this.tabDetail = new System.Windows.Forms.TabControl();
            this.pageCongTrinh = new System.Windows.Forms.TabPage();
            this.dgvCongTrinh = new Epoint.Systems.Controls.dgvControl();
            this.tabEmployee = new System.Windows.Forms.TabControl();
            this.pageEmployee = new System.Windows.Forms.TabPage();
            this.pnlControl2.SuspendLayout();
            this.splControl1.Panel2.SuspendLayout();
            this.splControl1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpTTNV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).BeginInit();
            this.tabDetail.SuspendLayout();
            this.pageCongTrinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCongTrinh)).BeginInit();
            this.tabEmployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // splControl1
            // 
            this.splControl1.Size = new System.Drawing.Size(1125, 562);
            this.splControl1.SplitterDistance = 501;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tpTTNV);
            this.tabControl1.Location = new System.Drawing.Point(260, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(862, 358);
            this.tabControl1.TabIndex = 1;
            // 
            // tpTTNV
            // 
            this.tpTTNV.Controls.Add(this.lblGhi_Chu);
            this.tpTTNV.Controls.Add(this.txtGhi_Chu);
            this.tpTTNV.Controls.Add(this.lblDia_Chi_TT);
            this.tpTTNV.Controls.Add(this.txtDia_Chi_TT);
            this.tpTTNV.Controls.Add(this.lblControl11);
            this.tpTTNV.Controls.Add(this.lblControl17);
            this.tpTTNV.Controls.Add(this.lblDia_Chi);
            this.tpTTNV.Controls.Add(this.txtSo_Phone);
            this.tpTTNV.Controls.Add(this.txtEmail);
            this.tpTTNV.Controls.Add(this.txtDia_Chi);
            this.tpTTNV.Controls.Add(this.lblMa_ViTri);
            this.tpTTNV.Controls.Add(this.txtMa_ViTri);
            this.tpTTNV.Controls.Add(this.cboTinh_Trang_HN);
            this.tpTTNV.Controls.Add(this.lblTinh_Trang_HN);
            this.tpTTNV.Controls.Add(this.cboGioi_Tinh);
            this.tpTTNV.Controls.Add(this.lblGioi_Tinh);
            this.tpTTNV.Controls.Add(this.txtNgay_Cap);
            this.tpTTNV.Controls.Add(this.lblNgay_Cap);
            this.tpTTNV.Controls.Add(this.lblNoi_Cap);
            this.tpTTNV.Controls.Add(this.txtNoi_Cap);
            this.tpTTNV.Controls.Add(this.picHinh);
            this.tpTTNV.Controls.Add(this.dteNgay_Sinh);
            this.tpTTNV.Controls.Add(this.lblNgay_Sinh);
            this.tpTTNV.Controls.Add(this.lblMa_So_Thue);
            this.tpTTNV.Controls.Add(this.lblNgan_Hang);
            this.tpTTNV.Controls.Add(this.lblQuoc_Tich);
            this.tpTTNV.Controls.Add(this.lblSo_Tk);
            this.tpTTNV.Controls.Add(this.lblTon_Giao);
            this.tpTTNV.Controls.Add(this.lblDan_Toc);
            this.tpTTNV.Controls.Add(this.lblNguyen_Quan);
            this.tpTTNV.Controls.Add(this.lblNoi_Sinh);
            this.tpTTNV.Controls.Add(this.lblTen_CbNv);
            this.tpTTNV.Controls.Add(this.lblControl19);
            this.tpTTNV.Controls.Add(this.lblSo_CMND);
            this.tpTTNV.Controls.Add(this.lblMa_Bp);
            this.tpTTNV.Controls.Add(this.lblMa_CbNv);
            this.tpTTNV.Controls.Add(this.txtMa_So_Thue);
            this.tpTTNV.Controls.Add(this.txtNgan_Hang);
            this.tpTTNV.Controls.Add(this.txtQuoc_Tich);
            this.tpTTNV.Controls.Add(this.txtTextBox2);
            this.tpTTNV.Controls.Add(this.txtTon_Giao);
            this.tpTTNV.Controls.Add(this.txtDan_Toc);
            this.tpTTNV.Controls.Add(this.txtNguyen_Quan);
            this.tpTTNV.Controls.Add(this.txtNoi_Sinh);
            this.tpTTNV.Controls.Add(this.txtTen_CbNv);
            this.tpTTNV.Controls.Add(this.txtBi_Danh);
            this.tpTTNV.Controls.Add(this.txtSo_CMND);
            this.tpTTNV.Controls.Add(this.txtMa_Bp);
            this.tpTTNV.Controls.Add(this.txtMa_CbNv);
            this.tpTTNV.Location = new System.Drawing.Point(4, 22);
            this.tpTTNV.Name = "tpTTNV";
            this.tpTTNV.Padding = new System.Windows.Forms.Padding(3);
            this.tpTTNV.Size = new System.Drawing.Size(854, 332);
            this.tpTTNV.TabIndex = 0;
            this.tpTTNV.Tag = "TTNV";
            this.tpTTNV.Text = "Thông tin nhân viên";
            this.tpTTNV.UseVisualStyleBackColor = true;
            // 
            // lblGhi_Chu
            // 
            this.lblGhi_Chu.AutoEllipsis = true;
            this.lblGhi_Chu.AutoSize = true;
            this.lblGhi_Chu.BackColor = System.Drawing.Color.Transparent;
            this.lblGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGhi_Chu.Location = new System.Drawing.Point(9, 289);
            this.lblGhi_Chu.Name = "lblGhi_Chu";
            this.lblGhi_Chu.Size = new System.Drawing.Size(44, 13);
            this.lblGhi_Chu.TabIndex = 204;
            this.lblGhi_Chu.Tag = "Ghi_Chu";
            this.lblGhi_Chu.Text = "Ghi chú";
            this.lblGhi_Chu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGhi_Chu
            // 
            this.txtGhi_Chu.AccessibleName = "6";
            this.txtGhi_Chu.bEnabled = true;
            this.txtGhi_Chu.bIsLookup = false;
            this.txtGhi_Chu.bReadOnly = false;
            this.txtGhi_Chu.bRequire = false;
            this.txtGhi_Chu.Enabled = false;
            this.txtGhi_Chu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhi_Chu.KeyFilter = "";
            this.txtGhi_Chu.Location = new System.Drawing.Point(89, 286);
            this.txtGhi_Chu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtGhi_Chu.Multiline = true;
            this.txtGhi_Chu.Name = "txtGhi_Chu";
            this.txtGhi_Chu.Size = new System.Drawing.Size(754, 37);
            this.txtGhi_Chu.TabIndex = 203;
            this.txtGhi_Chu.UseAutoFilter = false;
            // 
            // lblDia_Chi_TT
            // 
            this.lblDia_Chi_TT.AutoEllipsis = true;
            this.lblDia_Chi_TT.AutoSize = true;
            this.lblDia_Chi_TT.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi_TT.Location = new System.Drawing.Point(9, 241);
            this.lblDia_Chi_TT.Name = "lblDia_Chi_TT";
            this.lblDia_Chi_TT.Size = new System.Drawing.Size(77, 13);
            this.lblDia_Chi_TT.TabIndex = 201;
            this.lblDia_Chi_TT.Tag = "Dia_Chi_TT";
            this.lblDia_Chi_TT.Text = "Đ/c thường trú";
            this.lblDia_Chi_TT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDia_Chi_TT
            // 
            this.txtDia_Chi_TT.bEnabled = true;
            this.txtDia_Chi_TT.bIsLookup = false;
            this.txtDia_Chi_TT.bReadOnly = false;
            this.txtDia_Chi_TT.bRequire = false;
            this.txtDia_Chi_TT.KeyFilter = "";
            this.txtDia_Chi_TT.Location = new System.Drawing.Point(89, 238);
            this.txtDia_Chi_TT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi_TT.Name = "txtDia_Chi_TT";
            this.txtDia_Chi_TT.ReadOnly = true;
            this.txtDia_Chi_TT.Size = new System.Drawing.Size(380, 20);
            this.txtDia_Chi_TT.TabIndex = 202;
            this.txtDia_Chi_TT.UseAutoFilter = false;
            // 
            // lblControl11
            // 
            this.lblControl11.AutoEllipsis = true;
            this.lblControl11.AutoSize = true;
            this.lblControl11.BackColor = System.Drawing.Color.Transparent;
            this.lblControl11.Location = new System.Drawing.Point(477, 241);
            this.lblControl11.Name = "lblControl11";
            this.lblControl11.Size = new System.Drawing.Size(45, 13);
            this.lblControl11.TabIndex = 198;
            this.lblControl11.Text = "Di động";
            this.lblControl11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl17
            // 
            this.lblControl17.AutoEllipsis = true;
            this.lblControl17.AutoSize = true;
            this.lblControl17.BackColor = System.Drawing.Color.Transparent;
            this.lblControl17.Location = new System.Drawing.Point(477, 265);
            this.lblControl17.Name = "lblControl17";
            this.lblControl17.Size = new System.Drawing.Size(68, 13);
            this.lblControl17.TabIndex = 195;
            this.lblControl17.Text = "Địa chỉ Email";
            this.lblControl17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDia_Chi
            // 
            this.lblDia_Chi.AutoEllipsis = true;
            this.lblDia_Chi.AutoSize = true;
            this.lblDia_Chi.BackColor = System.Drawing.Color.Transparent;
            this.lblDia_Chi.Location = new System.Drawing.Point(9, 265);
            this.lblDia_Chi.Name = "lblDia_Chi";
            this.lblDia_Chi.Size = new System.Drawing.Size(61, 13);
            this.lblDia_Chi.TabIndex = 196;
            this.lblDia_Chi.Text = "Đ/c tạm trú";
            this.lblDia_Chi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSo_Phone
            // 
            this.txtSo_Phone.bEnabled = true;
            this.txtSo_Phone.bIsLookup = false;
            this.txtSo_Phone.bReadOnly = false;
            this.txtSo_Phone.bRequire = false;
            this.txtSo_Phone.KeyFilter = "";
            this.txtSo_Phone.Location = new System.Drawing.Point(549, 238);
            this.txtSo_Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_Phone.Name = "txtSo_Phone";
            this.txtSo_Phone.ReadOnly = true;
            this.txtSo_Phone.Size = new System.Drawing.Size(294, 20);
            this.txtSo_Phone.TabIndex = 199;
            this.txtSo_Phone.UseAutoFilter = false;
            // 
            // txtEmail
            // 
            this.txtEmail.bEnabled = true;
            this.txtEmail.bIsLookup = false;
            this.txtEmail.bReadOnly = false;
            this.txtEmail.bRequire = false;
            this.txtEmail.KeyFilter = "";
            this.txtEmail.Location = new System.Drawing.Point(549, 262);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(294, 20);
            this.txtEmail.TabIndex = 200;
            this.txtEmail.UseAutoFilter = false;
            // 
            // txtDia_Chi
            // 
            this.txtDia_Chi.bEnabled = true;
            this.txtDia_Chi.bIsLookup = false;
            this.txtDia_Chi.bReadOnly = false;
            this.txtDia_Chi.bRequire = false;
            this.txtDia_Chi.KeyFilter = "";
            this.txtDia_Chi.Location = new System.Drawing.Point(89, 262);
            this.txtDia_Chi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDia_Chi.Name = "txtDia_Chi";
            this.txtDia_Chi.ReadOnly = true;
            this.txtDia_Chi.Size = new System.Drawing.Size(380, 20);
            this.txtDia_Chi.TabIndex = 197;
            this.txtDia_Chi.UseAutoFilter = false;
            // 
            // lblMa_ViTri
            // 
            this.lblMa_ViTri.AutoEllipsis = true;
            this.lblMa_ViTri.AutoSize = true;
            this.lblMa_ViTri.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_ViTri.Location = new System.Drawing.Point(330, 59);
            this.lblMa_ViTri.Name = "lblMa_ViTri";
            this.lblMa_ViTri.Size = new System.Drawing.Size(46, 13);
            this.lblMa_ViTri.TabIndex = 194;
            this.lblMa_ViTri.Tag = "Ma_ViTri";
            this.lblMa_ViTri.Text = "Mã vị trí";
            this.lblMa_ViTri.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_ViTri
            // 
            this.txtMa_ViTri.bEnabled = true;
            this.txtMa_ViTri.bIsLookup = false;
            this.txtMa_ViTri.bReadOnly = false;
            this.txtMa_ViTri.bRequire = false;
            this.txtMa_ViTri.KeyFilter = "";
            this.txtMa_ViTri.Location = new System.Drawing.Point(412, 56);
            this.txtMa_ViTri.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_ViTri.Name = "txtMa_ViTri";
            this.txtMa_ViTri.ReadOnly = true;
            this.txtMa_ViTri.Size = new System.Drawing.Size(204, 20);
            this.txtMa_ViTri.TabIndex = 193;
            this.txtMa_ViTri.UseAutoFilter = false;
            // 
            // cboTinh_Trang_HN
            // 
            this.cboTinh_Trang_HN.Enabled = false;
            this.cboTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTinh_Trang_HN.FormattingEnabled = true;
            this.cboTinh_Trang_HN.InitValue = null;
            this.cboTinh_Trang_HN.Items.AddRange(new object[] {
            "Đã kết hôn",
            "Độc thân"});
            this.cboTinh_Trang_HN.Location = new System.Drawing.Point(412, 97);
            this.cboTinh_Trang_HN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboTinh_Trang_HN.Name = "cboTinh_Trang_HN";
            this.cboTinh_Trang_HN.Size = new System.Drawing.Size(204, 21);
            this.cboTinh_Trang_HN.strValueList = null;
            this.cboTinh_Trang_HN.TabIndex = 7;
            this.cboTinh_Trang_HN.UseAutoComplete = false;
            this.cboTinh_Trang_HN.UseBindingValue = false;
            // 
            // lblTinh_Trang_HN
            // 
            this.lblTinh_Trang_HN.AutoEllipsis = true;
            this.lblTinh_Trang_HN.AutoSize = true;
            this.lblTinh_Trang_HN.BackColor = System.Drawing.Color.Transparent;
            this.lblTinh_Trang_HN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinh_Trang_HN.Location = new System.Drawing.Point(331, 100);
            this.lblTinh_Trang_HN.Name = "lblTinh_Trang_HN";
            this.lblTinh_Trang_HN.Size = new System.Drawing.Size(54, 13);
            this.lblTinh_Trang_HN.TabIndex = 189;
            this.lblTinh_Trang_HN.Tag = "Tinh_Trang_HN";
            this.lblTinh_Trang_HN.Text = "Hôn nhân";
            this.lblTinh_Trang_HN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboGioi_Tinh
            // 
            this.cboGioi_Tinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioi_Tinh.Enabled = false;
            this.cboGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboGioi_Tinh.FormattingEnabled = true;
            this.cboGioi_Tinh.InitValue = null;
            this.cboGioi_Tinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.cboGioi_Tinh.Location = new System.Drawing.Point(89, 213);
            this.cboGioi_Tinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.cboGioi_Tinh.Name = "cboGioi_Tinh";
            this.cboGioi_Tinh.Size = new System.Drawing.Size(64, 21);
            this.cboGioi_Tinh.strValueList = null;
            this.cboGioi_Tinh.TabIndex = 15;
            this.cboGioi_Tinh.UseAutoComplete = false;
            this.cboGioi_Tinh.UseBindingValue = false;
            // 
            // lblGioi_Tinh
            // 
            this.lblGioi_Tinh.AutoEllipsis = true;
            this.lblGioi_Tinh.AutoSize = true;
            this.lblGioi_Tinh.BackColor = System.Drawing.Color.Transparent;
            this.lblGioi_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioi_Tinh.Location = new System.Drawing.Point(11, 218);
            this.lblGioi_Tinh.Name = "lblGioi_Tinh";
            this.lblGioi_Tinh.Size = new System.Drawing.Size(47, 13);
            this.lblGioi_Tinh.TabIndex = 182;
            this.lblGioi_Tinh.Tag = "Gioi_Tinh";
            this.lblGioi_Tinh.Text = "Giới tính";
            this.lblGioi_Tinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNgay_Cap
            // 
            this.txtNgay_Cap.bAllowEmpty = true;
            this.txtNgay_Cap.bRequire = false;
            this.txtNgay_Cap.bSelectOnFocus = true;
            this.txtNgay_Cap.bShowDateTimePicker = true;
            this.txtNgay_Cap.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.txtNgay_Cap.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.txtNgay_Cap.Location = new System.Drawing.Point(89, 143);
            this.txtNgay_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgay_Cap.Mask = "00/00/0000";
            this.txtNgay_Cap.Name = "txtNgay_Cap";
            this.txtNgay_Cap.ReadOnly = true;
            this.txtNgay_Cap.Size = new System.Drawing.Size(64, 20);
            this.txtNgay_Cap.TabIndex = 9;
            // 
            // lblNgay_Cap
            // 
            this.lblNgay_Cap.AutoEllipsis = true;
            this.lblNgay_Cap.AutoSize = true;
            this.lblNgay_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Cap.Location = new System.Drawing.Point(11, 145);
            this.lblNgay_Cap.Name = "lblNgay_Cap";
            this.lblNgay_Cap.Size = new System.Drawing.Size(53, 13);
            this.lblNgay_Cap.TabIndex = 165;
            this.lblNgay_Cap.Tag = "Ngay_cap";
            this.lblNgay_Cap.Text = "Ngày cấp";
            this.lblNgay_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNoi_Cap
            // 
            this.lblNoi_Cap.AutoEllipsis = true;
            this.lblNoi_Cap.AutoSize = true;
            this.lblNoi_Cap.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Cap.Location = new System.Drawing.Point(156, 146);
            this.lblNoi_Cap.Name = "lblNoi_Cap";
            this.lblNoi_Cap.Size = new System.Drawing.Size(44, 13);
            this.lblNoi_Cap.TabIndex = 166;
            this.lblNoi_Cap.Tag = "Noi_Cap";
            this.lblNoi_Cap.Text = "Nơi cấp";
            this.lblNoi_Cap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNoi_Cap
            // 
            this.txtNoi_Cap.bEnabled = true;
            this.txtNoi_Cap.bIsLookup = false;
            this.txtNoi_Cap.bReadOnly = false;
            this.txtNoi_Cap.bRequire = false;
            this.txtNoi_Cap.KeyFilter = "";
            this.txtNoi_Cap.Location = new System.Drawing.Point(204, 143);
            this.txtNoi_Cap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Cap.Name = "txtNoi_Cap";
            this.txtNoi_Cap.ReadOnly = true;
            this.txtNoi_Cap.Size = new System.Drawing.Size(108, 20);
            this.txtNoi_Cap.TabIndex = 16;
            this.txtNoi_Cap.UseAutoFilter = false;
            // 
            // picHinh
            // 
            this.picHinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picHinh.Location = new System.Drawing.Point(685, 9);
            this.picHinh.Name = "picHinh";
            this.picHinh.Size = new System.Drawing.Size(98, 123);
            this.picHinh.TabIndex = 17;
            this.picHinh.TabStop = false;
            // 
            // dteNgay_Sinh
            // 
            this.dteNgay_Sinh.bAllowEmpty = true;
            this.dteNgay_Sinh.bRequire = false;
            this.dteNgay_Sinh.bSelectOnFocus = true;
            this.dteNgay_Sinh.bShowDateTimePicker = true;
            this.dteNgay_Sinh.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.dteNgay_Sinh.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.dteNgay_Sinh.Location = new System.Drawing.Point(89, 96);
            this.dteNgay_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.dteNgay_Sinh.Mask = "00/00/0000";
            this.dteNgay_Sinh.Name = "dteNgay_Sinh";
            this.dteNgay_Sinh.ReadOnly = true;
            this.dteNgay_Sinh.Size = new System.Drawing.Size(64, 20);
            this.dteNgay_Sinh.TabIndex = 6;
            // 
            // lblNgay_Sinh
            // 
            this.lblNgay_Sinh.AutoEllipsis = true;
            this.lblNgay_Sinh.AutoSize = true;
            this.lblNgay_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNgay_Sinh.Location = new System.Drawing.Point(11, 99);
            this.lblNgay_Sinh.Name = "lblNgay_Sinh";
            this.lblNgay_Sinh.Size = new System.Drawing.Size(54, 13);
            this.lblNgay_Sinh.TabIndex = 12;
            this.lblNgay_Sinh.Tag = "Ngay_Sinh";
            this.lblNgay_Sinh.Text = "Ngày sinh";
            this.lblNgay_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_So_Thue
            // 
            this.lblMa_So_Thue.AutoEllipsis = true;
            this.lblMa_So_Thue.AutoSize = true;
            this.lblMa_So_Thue.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_So_Thue.Location = new System.Drawing.Point(331, 171);
            this.lblMa_So_Thue.Name = "lblMa_So_Thue";
            this.lblMa_So_Thue.Size = new System.Drawing.Size(60, 13);
            this.lblMa_So_Thue.TabIndex = 11;
            this.lblMa_So_Thue.Tag = "Ma_So_Thue";
            this.lblMa_So_Thue.Text = "Mã số thuế";
            this.lblMa_So_Thue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNgan_Hang
            // 
            this.lblNgan_Hang.AutoEllipsis = true;
            this.lblNgan_Hang.AutoSize = true;
            this.lblNgan_Hang.BackColor = System.Drawing.Color.Transparent;
            this.lblNgan_Hang.Location = new System.Drawing.Point(331, 193);
            this.lblNgan_Hang.Name = "lblNgan_Hang";
            this.lblNgan_Hang.Size = new System.Drawing.Size(60, 13);
            this.lblNgan_Hang.TabIndex = 11;
            this.lblNgan_Hang.Tag = "Ngan_Hang";
            this.lblNgan_Hang.Text = "Ngân hàng";
            this.lblNgan_Hang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblQuoc_Tich
            // 
            this.lblQuoc_Tich.AutoEllipsis = true;
            this.lblQuoc_Tich.AutoSize = true;
            this.lblQuoc_Tich.BackColor = System.Drawing.Color.Transparent;
            this.lblQuoc_Tich.Location = new System.Drawing.Point(331, 147);
            this.lblQuoc_Tich.Name = "lblQuoc_Tich";
            this.lblQuoc_Tich.Size = new System.Drawing.Size(53, 13);
            this.lblQuoc_Tich.TabIndex = 11;
            this.lblQuoc_Tich.Tag = "Quoc_Tich";
            this.lblQuoc_Tich.Text = "Quốc tịch";
            this.lblQuoc_Tich.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_Tk
            // 
            this.lblSo_Tk.AutoEllipsis = true;
            this.lblSo_Tk.AutoSize = true;
            this.lblSo_Tk.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_Tk.Location = new System.Drawing.Point(331, 216);
            this.lblSo_Tk.Name = "lblSo_Tk";
            this.lblSo_Tk.Size = new System.Drawing.Size(67, 13);
            this.lblSo_Tk.TabIndex = 11;
            this.lblSo_Tk.Tag = "So_Tk";
            this.lblSo_Tk.Text = "Số tài khoản";
            this.lblSo_Tk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTon_Giao
            // 
            this.lblTon_Giao.AutoEllipsis = true;
            this.lblTon_Giao.AutoSize = true;
            this.lblTon_Giao.BackColor = System.Drawing.Color.Transparent;
            this.lblTon_Giao.Location = new System.Drawing.Point(331, 124);
            this.lblTon_Giao.Name = "lblTon_Giao";
            this.lblTon_Giao.Size = new System.Drawing.Size(49, 13);
            this.lblTon_Giao.TabIndex = 11;
            this.lblTon_Giao.Tag = "Ton_Giao";
            this.lblTon_Giao.Text = "Tôn giáo";
            this.lblTon_Giao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDan_Toc
            // 
            this.lblDan_Toc.AutoEllipsis = true;
            this.lblDan_Toc.AutoSize = true;
            this.lblDan_Toc.BackColor = System.Drawing.Color.Transparent;
            this.lblDan_Toc.Location = new System.Drawing.Point(11, 194);
            this.lblDan_Toc.Name = "lblDan_Toc";
            this.lblDan_Toc.Size = new System.Drawing.Size(45, 13);
            this.lblDan_Toc.TabIndex = 11;
            this.lblDan_Toc.Tag = "Dan_Toc";
            this.lblDan_Toc.Text = "Dân tộc";
            this.lblDan_Toc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNguyen_Quan
            // 
            this.lblNguyen_Quan.AutoEllipsis = true;
            this.lblNguyen_Quan.AutoSize = true;
            this.lblNguyen_Quan.BackColor = System.Drawing.Color.Transparent;
            this.lblNguyen_Quan.Location = new System.Drawing.Point(11, 171);
            this.lblNguyen_Quan.Name = "lblNguyen_Quan";
            this.lblNguyen_Quan.Size = new System.Drawing.Size(71, 13);
            this.lblNguyen_Quan.TabIndex = 10;
            this.lblNguyen_Quan.Tag = "Nguyen_Quan";
            this.lblNguyen_Quan.Text = "Nguyên quán";
            this.lblNguyen_Quan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNoi_Sinh
            // 
            this.lblNoi_Sinh.AutoEllipsis = true;
            this.lblNoi_Sinh.AutoSize = true;
            this.lblNoi_Sinh.BackColor = System.Drawing.Color.Transparent;
            this.lblNoi_Sinh.Location = new System.Drawing.Point(156, 101);
            this.lblNoi_Sinh.Name = "lblNoi_Sinh";
            this.lblNoi_Sinh.Size = new System.Drawing.Size(45, 13);
            this.lblNoi_Sinh.TabIndex = 14;
            this.lblNoi_Sinh.Tag = "Noi_Sinh";
            this.lblNoi_Sinh.Text = "Nơi sinh";
            this.lblNoi_Sinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTen_CbNv
            // 
            this.lblTen_CbNv.AutoEllipsis = true;
            this.lblTen_CbNv.AutoSize = true;
            this.lblTen_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblTen_CbNv.Location = new System.Drawing.Point(11, 37);
            this.lblTen_CbNv.Name = "lblTen_CbNv";
            this.lblTen_CbNv.Size = new System.Drawing.Size(76, 13);
            this.lblTen_CbNv.TabIndex = 13;
            this.lblTen_CbNv.Tag = "Ten_CbNv";
            this.lblTen_CbNv.Text = "Tên nhân viên";
            this.lblTen_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl19
            // 
            this.lblControl19.AutoEllipsis = true;
            this.lblControl19.AutoSize = true;
            this.lblControl19.BackColor = System.Drawing.Color.Transparent;
            this.lblControl19.Location = new System.Drawing.Point(220, 14);
            this.lblControl19.Name = "lblControl19";
            this.lblControl19.Size = new System.Drawing.Size(45, 13);
            this.lblControl19.TabIndex = 9;
            this.lblControl19.Text = "Bí danh";
            this.lblControl19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSo_CMND
            // 
            this.lblSo_CMND.AutoEllipsis = true;
            this.lblSo_CMND.AutoSize = true;
            this.lblSo_CMND.BackColor = System.Drawing.Color.Transparent;
            this.lblSo_CMND.Location = new System.Drawing.Point(11, 123);
            this.lblSo_CMND.Name = "lblSo_CMND";
            this.lblSo_CMND.Size = new System.Drawing.Size(55, 13);
            this.lblSo_CMND.TabIndex = 9;
            this.lblSo_CMND.Tag = "So_CMND";
            this.lblSo_CMND.Text = "Số CMND";
            this.lblSo_CMND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_Bp
            // 
            this.lblMa_Bp.AutoEllipsis = true;
            this.lblMa_Bp.AutoSize = true;
            this.lblMa_Bp.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_Bp.Location = new System.Drawing.Point(11, 60);
            this.lblMa_Bp.Name = "lblMa_Bp";
            this.lblMa_Bp.Size = new System.Drawing.Size(64, 13);
            this.lblMa_Bp.TabIndex = 9;
            this.lblMa_Bp.Tag = "Ma_Bp";
            this.lblMa_Bp.Text = "Mã bộ phận";
            this.lblMa_Bp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMa_CbNv
            // 
            this.lblMa_CbNv.AutoEllipsis = true;
            this.lblMa_CbNv.AutoSize = true;
            this.lblMa_CbNv.BackColor = System.Drawing.Color.Transparent;
            this.lblMa_CbNv.Location = new System.Drawing.Point(11, 14);
            this.lblMa_CbNv.Name = "lblMa_CbNv";
            this.lblMa_CbNv.Size = new System.Drawing.Size(72, 13);
            this.lblMa_CbNv.TabIndex = 9;
            this.lblMa_CbNv.Tag = "Ma_CbNv";
            this.lblMa_CbNv.Text = "Mã nhân viên";
            this.lblMa_CbNv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMa_So_Thue
            // 
            this.txtMa_So_Thue.bEnabled = true;
            this.txtMa_So_Thue.bIsLookup = false;
            this.txtMa_So_Thue.bReadOnly = false;
            this.txtMa_So_Thue.bRequire = false;
            this.txtMa_So_Thue.KeyFilter = "";
            this.txtMa_So_Thue.Location = new System.Drawing.Point(412, 167);
            this.txtMa_So_Thue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_So_Thue.Name = "txtMa_So_Thue";
            this.txtMa_So_Thue.ReadOnly = true;
            this.txtMa_So_Thue.Size = new System.Drawing.Size(204, 20);
            this.txtMa_So_Thue.TabIndex = 12;
            this.txtMa_So_Thue.UseAutoFilter = false;
            // 
            // txtNgan_Hang
            // 
            this.txtNgan_Hang.AccessibleName = "6";
            this.txtNgan_Hang.bEnabled = true;
            this.txtNgan_Hang.bIsLookup = false;
            this.txtNgan_Hang.bReadOnly = false;
            this.txtNgan_Hang.bRequire = false;
            this.txtNgan_Hang.KeyFilter = "";
            this.txtNgan_Hang.Location = new System.Drawing.Point(412, 190);
            this.txtNgan_Hang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNgan_Hang.Name = "txtNgan_Hang";
            this.txtNgan_Hang.ReadOnly = true;
            this.txtNgan_Hang.Size = new System.Drawing.Size(204, 20);
            this.txtNgan_Hang.TabIndex = 14;
            this.txtNgan_Hang.UseAutoFilter = false;
            // 
            // txtQuoc_Tich
            // 
            this.txtQuoc_Tich.AccessibleName = "6";
            this.txtQuoc_Tich.bEnabled = true;
            this.txtQuoc_Tich.bIsLookup = false;
            this.txtQuoc_Tich.bReadOnly = false;
            this.txtQuoc_Tich.bRequire = false;
            this.txtQuoc_Tich.KeyFilter = "";
            this.txtQuoc_Tich.Location = new System.Drawing.Point(412, 144);
            this.txtQuoc_Tich.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtQuoc_Tich.Name = "txtQuoc_Tich";
            this.txtQuoc_Tich.ReadOnly = true;
            this.txtQuoc_Tich.Size = new System.Drawing.Size(204, 20);
            this.txtQuoc_Tich.TabIndex = 10;
            this.txtQuoc_Tich.UseAutoFilter = false;
            // 
            // txtTextBox2
            // 
            this.txtTextBox2.bEnabled = true;
            this.txtTextBox2.bIsLookup = false;
            this.txtTextBox2.bReadOnly = false;
            this.txtTextBox2.bRequire = false;
            this.txtTextBox2.KeyFilter = "";
            this.txtTextBox2.Location = new System.Drawing.Point(412, 213);
            this.txtTextBox2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTextBox2.Name = "txtTextBox2";
            this.txtTextBox2.ReadOnly = true;
            this.txtTextBox2.Size = new System.Drawing.Size(204, 20);
            this.txtTextBox2.TabIndex = 16;
            this.txtTextBox2.UseAutoFilter = false;
            // 
            // txtTon_Giao
            // 
            this.txtTon_Giao.bEnabled = true;
            this.txtTon_Giao.bIsLookup = false;
            this.txtTon_Giao.bReadOnly = false;
            this.txtTon_Giao.bRequire = false;
            this.txtTon_Giao.KeyFilter = "";
            this.txtTon_Giao.Location = new System.Drawing.Point(412, 121);
            this.txtTon_Giao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTon_Giao.Name = "txtTon_Giao";
            this.txtTon_Giao.ReadOnly = true;
            this.txtTon_Giao.Size = new System.Drawing.Size(204, 20);
            this.txtTon_Giao.TabIndex = 9;
            this.txtTon_Giao.UseAutoFilter = false;
            // 
            // txtDan_Toc
            // 
            this.txtDan_Toc.bEnabled = true;
            this.txtDan_Toc.bIsLookup = false;
            this.txtDan_Toc.bReadOnly = false;
            this.txtDan_Toc.bRequire = false;
            this.txtDan_Toc.KeyFilter = "";
            this.txtDan_Toc.Location = new System.Drawing.Point(89, 189);
            this.txtDan_Toc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtDan_Toc.Name = "txtDan_Toc";
            this.txtDan_Toc.ReadOnly = true;
            this.txtDan_Toc.Size = new System.Drawing.Size(223, 20);
            this.txtDan_Toc.TabIndex = 13;
            this.txtDan_Toc.UseAutoFilter = false;
            // 
            // txtNguyen_Quan
            // 
            this.txtNguyen_Quan.bEnabled = true;
            this.txtNguyen_Quan.bIsLookup = false;
            this.txtNguyen_Quan.bReadOnly = false;
            this.txtNguyen_Quan.bRequire = false;
            this.txtNguyen_Quan.KeyFilter = "";
            this.txtNguyen_Quan.Location = new System.Drawing.Point(89, 166);
            this.txtNguyen_Quan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNguyen_Quan.Name = "txtNguyen_Quan";
            this.txtNguyen_Quan.ReadOnly = true;
            this.txtNguyen_Quan.Size = new System.Drawing.Size(223, 20);
            this.txtNguyen_Quan.TabIndex = 11;
            this.txtNguyen_Quan.UseAutoFilter = false;
            // 
            // txtNoi_Sinh
            // 
            this.txtNoi_Sinh.bEnabled = true;
            this.txtNoi_Sinh.bIsLookup = false;
            this.txtNoi_Sinh.bReadOnly = false;
            this.txtNoi_Sinh.bRequire = false;
            this.txtNoi_Sinh.KeyFilter = "";
            this.txtNoi_Sinh.Location = new System.Drawing.Point(204, 97);
            this.txtNoi_Sinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtNoi_Sinh.Name = "txtNoi_Sinh";
            this.txtNoi_Sinh.ReadOnly = true;
            this.txtNoi_Sinh.Size = new System.Drawing.Size(108, 20);
            this.txtNoi_Sinh.TabIndex = 14;
            this.txtNoi_Sinh.UseAutoFilter = false;
            // 
            // txtTen_CbNv
            // 
            this.txtTen_CbNv.bEnabled = true;
            this.txtTen_CbNv.bIsLookup = false;
            this.txtTen_CbNv.bReadOnly = false;
            this.txtTen_CbNv.bRequire = false;
            this.txtTen_CbNv.KeyFilter = "";
            this.txtTen_CbNv.Location = new System.Drawing.Point(89, 34);
            this.txtTen_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTen_CbNv.Name = "txtTen_CbNv";
            this.txtTen_CbNv.ReadOnly = true;
            this.txtTen_CbNv.Size = new System.Drawing.Size(527, 20);
            this.txtTen_CbNv.TabIndex = 2;
            this.txtTen_CbNv.UseAutoFilter = false;
            // 
            // txtBi_Danh
            // 
            this.txtBi_Danh.bEnabled = true;
            this.txtBi_Danh.bIsLookup = false;
            this.txtBi_Danh.bReadOnly = false;
            this.txtBi_Danh.bRequire = false;
            this.txtBi_Danh.KeyFilter = "";
            this.txtBi_Danh.Location = new System.Drawing.Point(270, 11);
            this.txtBi_Danh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtBi_Danh.Name = "txtBi_Danh";
            this.txtBi_Danh.ReadOnly = true;
            this.txtBi_Danh.Size = new System.Drawing.Size(346, 20);
            this.txtBi_Danh.TabIndex = 1;
            this.txtBi_Danh.UseAutoFilter = false;
            // 
            // txtSo_CMND
            // 
            this.txtSo_CMND.bEnabled = true;
            this.txtSo_CMND.bIsLookup = false;
            this.txtSo_CMND.bReadOnly = false;
            this.txtSo_CMND.bRequire = false;
            this.txtSo_CMND.KeyFilter = "";
            this.txtSo_CMND.Location = new System.Drawing.Point(89, 120);
            this.txtSo_CMND.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtSo_CMND.Name = "txtSo_CMND";
            this.txtSo_CMND.ReadOnly = true;
            this.txtSo_CMND.Size = new System.Drawing.Size(223, 20);
            this.txtSo_CMND.TabIndex = 8;
            this.txtSo_CMND.UseAutoFilter = false;
            // 
            // txtMa_Bp
            // 
            this.txtMa_Bp.bEnabled = true;
            this.txtMa_Bp.bIsLookup = false;
            this.txtMa_Bp.bReadOnly = false;
            this.txtMa_Bp.bRequire = false;
            this.txtMa_Bp.KeyFilter = "";
            this.txtMa_Bp.Location = new System.Drawing.Point(89, 57);
            this.txtMa_Bp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Bp.Name = "txtMa_Bp";
            this.txtMa_Bp.ReadOnly = true;
            this.txtMa_Bp.Size = new System.Drawing.Size(223, 20);
            this.txtMa_Bp.TabIndex = 5;
            this.txtMa_Bp.UseAutoFilter = false;
            // 
            // txtMa_CbNv
            // 
            this.txtMa_CbNv.bEnabled = true;
            this.txtMa_CbNv.bIsLookup = false;
            this.txtMa_CbNv.bReadOnly = false;
            this.txtMa_CbNv.bRequire = false;
            this.txtMa_CbNv.KeyFilter = "";
            this.txtMa_CbNv.Location = new System.Drawing.Point(89, 11);
            this.txtMa_CbNv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_CbNv.Name = "txtMa_CbNv";
            this.txtMa_CbNv.ReadOnly = true;
            this.txtMa_CbNv.Size = new System.Drawing.Size(120, 20);
            this.txtMa_CbNv.TabIndex = 0;
            this.txtMa_CbNv.UseAutoFilter = false;
            // 
            // tabDetail
            // 
            this.tabDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabDetail.Controls.Add(this.pageCongTrinh);
            this.tabDetail.Location = new System.Drawing.Point(260, 364);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.SelectedIndex = 0;
            this.tabDetail.Size = new System.Drawing.Size(864, 200);
            this.tabDetail.TabIndex = 2;
            // 
            // pageCongTrinh
            // 
            this.pageCongTrinh.Controls.Add(this.dgvCongTrinh);
            this.pageCongTrinh.Location = new System.Drawing.Point(4, 22);
            this.pageCongTrinh.Name = "pageCongTrinh";
            this.pageCongTrinh.Size = new System.Drawing.Size(856, 174);
            this.pageCongTrinh.TabIndex = 8;
            this.pageCongTrinh.Tag = "CongTrinh";
            this.pageCongTrinh.Text = "Công trình";
            this.pageCongTrinh.UseVisualStyleBackColor = true;
            // 
            // dgvCongTrinh
            // 
            this.dgvCongTrinh.AllowUserToAddRows = false;
            this.dgvCongTrinh.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvCongTrinh.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCongTrinh.BackgroundColor = System.Drawing.Color.White;
            this.dgvCongTrinh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCongTrinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCongTrinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCongTrinh.EnableHeadersVisualStyles = false;
            this.dgvCongTrinh.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgvCongTrinh.Location = new System.Drawing.Point(0, 0);
            this.dgvCongTrinh.MultiSelect = false;
            this.dgvCongTrinh.Name = "dgvCongTrinh";
            this.dgvCongTrinh.ReadOnly = true;
            this.dgvCongTrinh.Size = new System.Drawing.Size(856, 174);
            this.dgvCongTrinh.strZone = "";
            this.dgvCongTrinh.TabIndex = 3;
            // 
            // tabEmployee
            // 
            this.tabEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tabEmployee.Controls.Add(this.pageEmployee);
            this.tabEmployee.Location = new System.Drawing.Point(1, 3);
            this.tabEmployee.Name = "tabEmployee";
            this.tabEmployee.SelectedIndex = 0;
            this.tabEmployee.Size = new System.Drawing.Size(257, 556);
            this.tabEmployee.TabIndex = 0;
            // 
            // pageEmployee
            // 
            this.pageEmployee.Location = new System.Drawing.Point(4, 22);
            this.pageEmployee.Name = "pageEmployee";
            this.pageEmployee.Padding = new System.Windows.Forms.Padding(3);
            this.pageEmployee.Size = new System.Drawing.Size(249, 530);
            this.pageEmployee.TabIndex = 0;
            this.pageEmployee.Text = "Danh sách nhân viên";
            this.pageEmployee.UseVisualStyleBackColor = true;
            // 
            // frmEmployee_CongTrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 562);
            this.Controls.Add(this.tabEmployee);
            this.Controls.Add(this.tabDetail);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmEmployee_CongTrinh";
            this.Text = "frmEmployee_CongTrinh_View";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Controls.SetChildIndex(this.tabControl1, 0);
            this.Controls.SetChildIndex(this.tabDetail, 0);
            this.Controls.SetChildIndex(this.tabEmployee, 0);
            this.Controls.SetChildIndex(this.splControl1, 0);
            this.pnlControl2.ResumeLayout(false);
            this.splControl1.Panel2.ResumeLayout(false);
            this.splControl1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpTTNV.ResumeLayout(false);
            this.tpTTNV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picHinh)).EndInit();
            this.tabDetail.ResumeLayout(false);
            this.pageCongTrinh.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCongTrinh)).EndInit();
            this.tabEmployee.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpTTNV;
		private System.Windows.Forms.PictureBox picHinh;
		private Epoint.Systems.Controls.txtDateTime dteNgay_Sinh;
		private Epoint.Systems.Controls.lblControl lblNgay_Sinh;
        private Epoint.Systems.Controls.lblControl lblMa_So_Thue;
		private Epoint.Systems.Controls.lblControl lblQuoc_Tich;
		private Epoint.Systems.Controls.lblControl lblTon_Giao;
		private Epoint.Systems.Controls.lblControl lblDan_Toc;
		private Epoint.Systems.Controls.lblControl lblNguyen_Quan;
		private Epoint.Systems.Controls.lblControl lblNoi_Sinh;
        private Epoint.Systems.Controls.lblControl lblTen_CbNv;
		private Epoint.Systems.Controls.lblControl lblSo_CMND;
		private Epoint.Systems.Controls.lblControl lblMa_Bp;
		private Epoint.Systems.Controls.lblControl lblMa_CbNv;
        private Epoint.Systems.Controls.txtTextBox txtMa_So_Thue;
		private Epoint.Systems.Controls.txtTextBox txtQuoc_Tich;
		private Epoint.Systems.Controls.txtTextBox txtTon_Giao;
		private Epoint.Systems.Controls.txtTextBox txtDan_Toc;
		private Epoint.Systems.Controls.txtTextBox txtNguyen_Quan;
		private Epoint.Systems.Controls.txtTextBox txtNoi_Sinh;
        private Epoint.Systems.Controls.txtTextBox txtTen_CbNv;
		private Epoint.Systems.Controls.txtTextBox txtSo_CMND;
		private Epoint.Systems.Controls.txtTextBox txtMa_Bp;
		private Epoint.Systems.Controls.txtTextBox txtMa_CbNv;
        private System.Windows.Forms.TabControl tabDetail;
        private System.Windows.Forms.TabControl tabEmployee;
		private Epoint.Systems.Controls.lblControl lblControl19;
		private Epoint.Systems.Controls.txtTextBox txtBi_Danh;
		private Epoint.Systems.Controls.txtDateTime txtNgay_Cap;
		private Epoint.Systems.Controls.lblControl lblNgay_Cap;
		private Epoint.Systems.Controls.lblControl lblNoi_Cap;
		private Epoint.Systems.Controls.txtTextBox txtNoi_Cap;
		private Epoint.Systems.Controls.lblControl lblNgan_Hang;
		private Epoint.Systems.Controls.lblControl lblSo_Tk;
		private Epoint.Systems.Controls.txtTextBox txtNgan_Hang;
        private Epoint.Systems.Controls.txtTextBox txtTextBox2;
        private System.Windows.Forms.TabPage pageEmployee;
        private Systems.Controls.cboControl cboGioi_Tinh;
        private Systems.Controls.lblControl lblGioi_Tinh;
        private System.Windows.Forms.TabPage pageCongTrinh;
        private Systems.Controls.dgvControl dgvCongTrinh;
        private Systems.Controls.cboControl cboTinh_Trang_HN;
        private Systems.Controls.lblControl lblTinh_Trang_HN;
        private Systems.Controls.lblControl lblMa_ViTri;
        private Systems.Controls.txtTextBox txtMa_ViTri;
        private Systems.Controls.lblControl lblGhi_Chu;
        private Systems.Controls.txtTextBox txtGhi_Chu;
        private Systems.Controls.lblControl lblDia_Chi_TT;
        private Systems.Controls.txtTextBox txtDia_Chi_TT;
        private Systems.Controls.lblControl lblControl11;
        private Systems.Controls.lblControl lblControl17;
        private Systems.Controls.lblControl lblDia_Chi;
        private Systems.Controls.txtTextBox txtSo_Phone;
        private Systems.Controls.txtTextBox txtEmail;
        private Systems.Controls.txtTextBox txtDia_Chi;
    }
}