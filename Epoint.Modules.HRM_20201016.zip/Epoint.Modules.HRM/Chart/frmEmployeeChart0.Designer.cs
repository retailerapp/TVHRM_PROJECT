﻿namespace Epoint.Modules.HRM
{
    partial class frmEmployeeChart0
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSize = new Epoint.Systems.Controls.lbtControl();
            this.btTag_List = new Epoint.Systems.Controls.btControl();
            this.btMa_Bp_Tag = new Epoint.Systems.Controls.btControl();
            this.btLoadData = new Epoint.Systems.Controls.btControl();
            this.btMa_Kv_Tag = new Epoint.Systems.Controls.btControl();
            this.lblControl8 = new Epoint.Systems.Controls.lblControl();
            this.lblControl7 = new Epoint.Systems.Controls.lblControl();
            this.lblControl6 = new Epoint.Systems.Controls.lblControl();
            this.txtTag_List = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_Bp_List = new Epoint.Systems.Controls.txtTextBox();
            this.txtMa_Kv_List = new Epoint.Systems.Controls.txtTextBox();
            this.tbTabcontrol1 = new Epoint.Systems.Customizes.tbTabcontrol();
            this.TabReport = new System.Windows.Forms.TabControl();
            this.tabPhongBan = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ChartPhongBan = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartKV = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabVitri = new System.Windows.Forms.TabPage();
            this.chartViTri = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabGioitinh = new System.Windows.Forms.TabPage();
            this.chartGioiTinh = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabTrinhDo = new System.Windows.Forms.TabPage();
            this.tabHopDong = new System.Windows.Forms.TabPage();
            this.chartHopDong = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartTrinhDo = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbTabcontrol1)).BeginInit();
            this.TabReport.SuspendLayout();
            this.tabPhongBan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartPhongBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartKV)).BeginInit();
            this.tabVitri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartViTri)).BeginInit();
            this.tabGioitinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGioiTinh)).BeginInit();
            this.tabTrinhDo.SuspendLayout();
            this.tabHopDong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartHopDong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTrinhDo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblSize);
            this.panel1.Controls.Add(this.btTag_List);
            this.panel1.Controls.Add(this.btMa_Bp_Tag);
            this.panel1.Controls.Add(this.btLoadData);
            this.panel1.Controls.Add(this.btMa_Kv_Tag);
            this.panel1.Controls.Add(this.lblControl8);
            this.panel1.Controls.Add(this.lblControl7);
            this.panel1.Controls.Add(this.lblControl6);
            this.panel1.Controls.Add(this.txtTag_List);
            this.panel1.Controls.Add(this.txtMa_Bp_List);
            this.panel1.Controls.Add(this.txtMa_Kv_List);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1064, 74);
            this.panel1.TabIndex = 1;
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.ForeColor = System.Drawing.Color.Blue;
            this.lblSize.Location = new System.Drawing.Point(99, 9);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(0, 13);
            this.lblSize.TabIndex = 17;
            this.lblSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btTag_List
            // 
            this.btTag_List.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btTag_List.Location = new System.Drawing.Point(449, 52);
            this.btTag_List.Name = "btTag_List";
            this.btTag_List.Size = new System.Drawing.Size(33, 20);
            this.btTag_List.TabIndex = 21;
            this.btTag_List.Tag = "";
            this.btTag_List.Text = "...";
            this.btTag_List.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btTag_List.UseVisualStyleBackColor = true;
            // 
            // btMa_Bp_Tag
            // 
            this.btMa_Bp_Tag.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btMa_Bp_Tag.Location = new System.Drawing.Point(449, 29);
            this.btMa_Bp_Tag.Name = "btMa_Bp_Tag";
            this.btMa_Bp_Tag.Size = new System.Drawing.Size(33, 20);
            this.btMa_Bp_Tag.TabIndex = 22;
            this.btMa_Bp_Tag.Tag = "";
            this.btMa_Bp_Tag.Text = "...";
            this.btMa_Bp_Tag.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btMa_Bp_Tag.UseVisualStyleBackColor = true;
            // 
            // btLoadData
            // 
            this.btLoadData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btLoadData.Image = global::Epoint.Modules.HRM.Properties.Resources.tick;
            this.btLoadData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btLoadData.Location = new System.Drawing.Point(918, 7);
            this.btLoadData.Name = "btLoadData";
            this.btLoadData.Size = new System.Drawing.Size(134, 62);
            this.btLoadData.TabIndex = 23;
            this.btLoadData.Tag = "";
            this.btLoadData.Text = "Xem báo cáo ";
            this.btLoadData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btLoadData.UseVisualStyleBackColor = true;
            // 
            // btMa_Kv_Tag
            // 
            this.btMa_Kv_Tag.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btMa_Kv_Tag.Location = new System.Drawing.Point(449, 6);
            this.btMa_Kv_Tag.Name = "btMa_Kv_Tag";
            this.btMa_Kv_Tag.Size = new System.Drawing.Size(33, 20);
            this.btMa_Kv_Tag.TabIndex = 23;
            this.btMa_Kv_Tag.Tag = "";
            this.btMa_Kv_Tag.Text = "...";
            this.btMa_Kv_Tag.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btMa_Kv_Tag.UseVisualStyleBackColor = true;
            // 
            // lblControl8
            // 
            this.lblControl8.AutoEllipsis = true;
            this.lblControl8.AutoSize = true;
            this.lblControl8.BackColor = System.Drawing.Color.Transparent;
            this.lblControl8.Location = new System.Drawing.Point(12, 56);
            this.lblControl8.Name = "lblControl8";
            this.lblControl8.Size = new System.Drawing.Size(29, 13);
            this.lblControl8.TabIndex = 24;
            this.lblControl8.Tag = "";
            this.lblControl8.Text = "Vị trí";
            this.lblControl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl7
            // 
            this.lblControl7.AutoEllipsis = true;
            this.lblControl7.AutoSize = true;
            this.lblControl7.BackColor = System.Drawing.Color.Transparent;
            this.lblControl7.Location = new System.Drawing.Point(12, 32);
            this.lblControl7.Name = "lblControl7";
            this.lblControl7.Size = new System.Drawing.Size(59, 13);
            this.lblControl7.TabIndex = 25;
            this.lblControl7.Tag = "";
            this.lblControl7.Text = "Phòng ban";
            this.lblControl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblControl6
            // 
            this.lblControl6.AutoEllipsis = true;
            this.lblControl6.AutoSize = true;
            this.lblControl6.BackColor = System.Drawing.Color.Transparent;
            this.lblControl6.Location = new System.Drawing.Point(12, 9);
            this.lblControl6.Name = "lblControl6";
            this.lblControl6.Size = new System.Drawing.Size(47, 13);
            this.lblControl6.TabIndex = 26;
            this.lblControl6.Tag = "";
            this.lblControl6.Text = "Khu vực";
            this.lblControl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTag_List
            // 
            this.txtTag_List.bEnabled = true;
            this.txtTag_List.bIsLookup = false;
            this.txtTag_List.bReadOnly = false;
            this.txtTag_List.bRequire = false;
            this.txtTag_List.KeyFilter = "";
            this.txtTag_List.Location = new System.Drawing.Point(99, 51);
            this.txtTag_List.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtTag_List.Name = "txtTag_List";
            this.txtTag_List.Size = new System.Drawing.Size(345, 20);
            this.txtTag_List.TabIndex = 20;
            this.txtTag_List.Text = "*";
            this.txtTag_List.UseAutoFilter = false;
            // 
            // txtMa_Bp_List
            // 
            this.txtMa_Bp_List.bEnabled = true;
            this.txtMa_Bp_List.bIsLookup = false;
            this.txtMa_Bp_List.bReadOnly = false;
            this.txtMa_Bp_List.bRequire = false;
            this.txtMa_Bp_List.KeyFilter = "";
            this.txtMa_Bp_List.Location = new System.Drawing.Point(99, 29);
            this.txtMa_Bp_List.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Bp_List.Name = "txtMa_Bp_List";
            this.txtMa_Bp_List.Size = new System.Drawing.Size(345, 20);
            this.txtMa_Bp_List.TabIndex = 19;
            this.txtMa_Bp_List.Text = "*";
            this.txtMa_Bp_List.UseAutoFilter = false;
            // 
            // txtMa_Kv_List
            // 
            this.txtMa_Kv_List.bEnabled = true;
            this.txtMa_Kv_List.bIsLookup = false;
            this.txtMa_Kv_List.bReadOnly = false;
            this.txtMa_Kv_List.bRequire = false;
            this.txtMa_Kv_List.KeyFilter = "";
            this.txtMa_Kv_List.Location = new System.Drawing.Point(99, 6);
            this.txtMa_Kv_List.Margin = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.txtMa_Kv_List.Name = "txtMa_Kv_List";
            this.txtMa_Kv_List.Size = new System.Drawing.Size(345, 20);
            this.txtMa_Kv_List.TabIndex = 18;
            this.txtMa_Kv_List.Text = "*";
            this.txtMa_Kv_List.UseAutoFilter = false;
            // 
            // tbTabcontrol1
            // 
            this.tbTabcontrol1.HeaderButtons = ((DevExpress.XtraTab.TabButtons)((DevExpress.XtraTab.TabButtons.Close | DevExpress.XtraTab.TabButtons.Default)));
            this.tbTabcontrol1.HeaderButtonsShowMode = DevExpress.XtraTab.TabButtonShowMode.WhenNeeded;
            this.tbTabcontrol1.Location = new System.Drawing.Point(0, 0);
            this.tbTabcontrol1.Name = "tbTabcontrol1";
            this.tbTabcontrol1.Padding = new System.Windows.Forms.Padding(2);
            this.tbTabcontrol1.PaintStyleName = "Skin";
            this.tbTabcontrol1.ShowHeaderFocus = DevExpress.Utils.DefaultBoolean.True;
            this.tbTabcontrol1.ShowTabHeader = DevExpress.Utils.DefaultBoolean.True;
            this.tbTabcontrol1.TabIndex = 0;
            // 
            // TabReport
            // 
            this.TabReport.Controls.Add(this.tabPhongBan);
            this.TabReport.Controls.Add(this.tabVitri);
            this.TabReport.Controls.Add(this.tabGioitinh);
            this.TabReport.Controls.Add(this.tabTrinhDo);
            this.TabReport.Controls.Add(this.tabHopDong);
            this.TabReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabReport.Location = new System.Drawing.Point(0, 74);
            this.TabReport.Name = "TabReport";
            this.TabReport.SelectedIndex = 0;
            this.TabReport.Size = new System.Drawing.Size(1064, 663);
            this.TabReport.TabIndex = 2;
            // 
            // tabPhongBan
            // 
            this.tabPhongBan.Controls.Add(this.splitContainer1);
            this.tabPhongBan.Location = new System.Drawing.Point(4, 22);
            this.tabPhongBan.Name = "tabPhongBan";
            this.tabPhongBan.Padding = new System.Windows.Forms.Padding(3);
            this.tabPhongBan.Size = new System.Drawing.Size(1056, 637);
            this.tabPhongBan.TabIndex = 0;
            this.tabPhongBan.Text = "Phòng ban";
            this.tabPhongBan.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.ChartPhongBan);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.chartKV);
            this.splitContainer1.Size = new System.Drawing.Size(1050, 631);
            this.splitContainer1.SplitterDistance = 350;
            this.splitContainer1.TabIndex = 0;
            // 
            // ChartPhongBan
            // 
            chartArea1.Name = "ChartArea1";
            this.ChartPhongBan.ChartAreas.Add(chartArea1);
            this.ChartPhongBan.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.ChartPhongBan.Legends.Add(legend1);
            this.ChartPhongBan.Location = new System.Drawing.Point(0, 0);
            this.ChartPhongBan.Name = "ChartPhongBan";
            this.ChartPhongBan.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.DodgerBlue;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.IsValueShownAsLabel = true;
            series1.IsXValueIndexed = true;
            series1.LabelAngle = 6;
            series1.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series1.Legend = "Legend1";
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Series1";
            series1.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series1.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series1.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series1.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            this.ChartPhongBan.Series.Add(series1);
            this.ChartPhongBan.Size = new System.Drawing.Size(1050, 350);
            this.ChartPhongBan.TabIndex = 12;
            this.ChartPhongBan.Text = "chart3";
            this.ChartPhongBan.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // chartKV
            // 
            chartArea2.Name = "ChartArea1";
            this.chartKV.ChartAreas.Add(chartArea2);
            this.chartKV.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chartKV.Legends.Add(legend2);
            this.chartKV.Location = new System.Drawing.Point(0, 0);
            this.chartKV.Name = "chartKV";
            this.chartKV.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series2.Color = System.Drawing.Color.Sienna;
            series2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series2.IsValueShownAsLabel = true;
            series2.IsXValueIndexed = true;
            series2.LabelAngle = 6;
            series2.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series2.Legend = "Legend1";
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Name = "Series1";
            series2.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series2.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series2.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series2.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            this.chartKV.Series.Add(series2);
            this.chartKV.Size = new System.Drawing.Size(1050, 277);
            this.chartKV.TabIndex = 13;
            this.chartKV.Text = "chart3";
            this.chartKV.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // tabVitri
            // 
            this.tabVitri.Controls.Add(this.chartViTri);
            this.tabVitri.Location = new System.Drawing.Point(4, 22);
            this.tabVitri.Name = "tabVitri";
            this.tabVitri.Padding = new System.Windows.Forms.Padding(3);
            this.tabVitri.Size = new System.Drawing.Size(1056, 637);
            this.tabVitri.TabIndex = 1;
            this.tabVitri.Text = "Vị trí";
            this.tabVitri.UseVisualStyleBackColor = true;
            // 
            // chartViTri
            // 
            chartArea3.Name = "ChartArea1";
            this.chartViTri.ChartAreas.Add(chartArea3);
            this.chartViTri.Dock = System.Windows.Forms.DockStyle.Fill;
            legend3.Name = "Legend1";
            this.chartViTri.Legends.Add(legend3);
            this.chartViTri.Location = new System.Drawing.Point(3, 3);
            this.chartViTri.Name = "chartViTri";
            this.chartViTri.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.DodgerBlue;
            series3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series3.IsValueShownAsLabel = true;
            series3.IsXValueIndexed = true;
            series3.LabelAngle = 6;
            series3.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series3.Legend = "Legend1";
            series3.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series3.Name = "Series1";
            series3.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series3.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series3.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series3.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series3.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            this.chartViTri.Series.Add(series3);
            this.chartViTri.Size = new System.Drawing.Size(1050, 631);
            this.chartViTri.TabIndex = 13;
            this.chartViTri.Text = "chart3";
            this.chartViTri.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // tabGioitinh
            // 
            this.tabGioitinh.Controls.Add(this.chartGioiTinh);
            this.tabGioitinh.Location = new System.Drawing.Point(4, 22);
            this.tabGioitinh.Name = "tabGioitinh";
            this.tabGioitinh.Size = new System.Drawing.Size(1056, 637);
            this.tabGioitinh.TabIndex = 2;
            this.tabGioitinh.Text = "Giới Tính";
            this.tabGioitinh.UseVisualStyleBackColor = true;
            // 
            // chartGioiTinh
            // 
            chartArea4.Name = "ChartArea1";
            this.chartGioiTinh.ChartAreas.Add(chartArea4);
            this.chartGioiTinh.Dock = System.Windows.Forms.DockStyle.Fill;
            legend4.Name = "Legend1";
            this.chartGioiTinh.Legends.Add(legend4);
            this.chartGioiTinh.Location = new System.Drawing.Point(0, 0);
            this.chartGioiTinh.Name = "chartGioiTinh";
            this.chartGioiTinh.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
            series4.Color = System.Drawing.Color.DodgerBlue;
            series4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series4.IsValueShownAsLabel = true;
            series4.IsXValueIndexed = true;
            series4.LabelAngle = 6;
            series4.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series4.Legend = "Legend1";
            series4.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series4.Name = "Series1";
            series4.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series4.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series4.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series4.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series4.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
            series5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            series5.Legend = "Legend1";
            series5.Name = "Series2";
            this.chartGioiTinh.Series.Add(series4);
            this.chartGioiTinh.Series.Add(series5);
            this.chartGioiTinh.Size = new System.Drawing.Size(1056, 637);
            this.chartGioiTinh.TabIndex = 14;
            this.chartGioiTinh.Text = "chart3";
            this.chartGioiTinh.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // tabTrinhDo
            // 
            this.tabTrinhDo.Controls.Add(this.chartTrinhDo);
            this.tabTrinhDo.Location = new System.Drawing.Point(4, 22);
            this.tabTrinhDo.Name = "tabTrinhDo";
            this.tabTrinhDo.Size = new System.Drawing.Size(1056, 637);
            this.tabTrinhDo.TabIndex = 3;
            this.tabTrinhDo.Text = "Trình độ";
            this.tabTrinhDo.UseVisualStyleBackColor = true;
            // 
            // tabHopDong
            // 
            this.tabHopDong.Controls.Add(this.chartHopDong);
            this.tabHopDong.Location = new System.Drawing.Point(4, 22);
            this.tabHopDong.Name = "tabHopDong";
            this.tabHopDong.Size = new System.Drawing.Size(1056, 637);
            this.tabHopDong.TabIndex = 4;
            this.tabHopDong.Text = "Hợp đồng";
            this.tabHopDong.UseVisualStyleBackColor = true;
            // 
            // chartHopDong
            // 
            chartArea6.Name = "ChartArea1";
            this.chartHopDong.ChartAreas.Add(chartArea6);
            this.chartHopDong.Dock = System.Windows.Forms.DockStyle.Fill;
            legend6.Name = "Legend1";
            this.chartHopDong.Legends.Add(legend6);
            this.chartHopDong.Location = new System.Drawing.Point(0, 0);
            this.chartHopDong.Name = "chartHopDong";
            this.chartHopDong.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series7.ChartArea = "ChartArea1";
            series7.Color = System.Drawing.Color.DodgerBlue;
            series7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series7.IsValueShownAsLabel = true;
            series7.IsXValueIndexed = true;
            series7.LabelAngle = 6;
            series7.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series7.Legend = "Legend1";
            series7.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series7.Name = "Series1";
            series7.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series7.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series7.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series7.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series7.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Series2";
            series9.ChartArea = "ChartArea1";
            series9.Legend = "Legend1";
            series9.Name = "Series3";
            this.chartHopDong.Series.Add(series7);
            this.chartHopDong.Series.Add(series8);
            this.chartHopDong.Series.Add(series9);
            this.chartHopDong.Size = new System.Drawing.Size(1056, 637);
            this.chartHopDong.TabIndex = 13;
            this.chartHopDong.Text = "chart3";
            this.chartHopDong.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // chartTrinhDo
            // 
            chartArea5.Name = "ChartArea1";
            this.chartTrinhDo.ChartAreas.Add(chartArea5);
            this.chartTrinhDo.Dock = System.Windows.Forms.DockStyle.Fill;
            legend5.Name = "Legend1";
            this.chartTrinhDo.Legends.Add(legend5);
            this.chartTrinhDo.Location = new System.Drawing.Point(0, 0);
            this.chartTrinhDo.Name = "chartTrinhDo";
            this.chartTrinhDo.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedColumn100;
            series6.Color = System.Drawing.Color.DodgerBlue;
            series6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series6.IsValueShownAsLabel = true;
            series6.IsXValueIndexed = true;
            series6.LabelAngle = 6;
            series6.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series6.Legend = "Legend1";
            series6.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series6.Name = "Series1";
            series6.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes;
            series6.SmartLabelStyle.CalloutBackColor = System.Drawing.Color.Empty;
            series6.SmartLabelStyle.IsMarkerOverlappingAllowed = true;
            series6.SmartLabelStyle.MovingDirection = System.Windows.Forms.DataVisualization.Charting.LabelAlignmentStyles.Top;
            series6.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            this.chartTrinhDo.Series.Add(series6);
            this.chartTrinhDo.Size = new System.Drawing.Size(1056, 637);
            this.chartTrinhDo.TabIndex = 13;
            this.chartTrinhDo.Text = "chart3";
            this.chartTrinhDo.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // frmEmployeeChart0
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 737);
            this.Controls.Add(this.TabReport);
            this.Controls.Add(this.panel1);
            this.Name = "frmEmployeeChart0";
            this.Text = "frmEmployeeChart";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbTabcontrol1)).EndInit();
            this.TabReport.ResumeLayout(false);
            this.tabPhongBan.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ChartPhongBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartKV)).EndInit();
            this.tabVitri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartViTri)).EndInit();
            this.tabGioitinh.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartGioiTinh)).EndInit();
            this.tabTrinhDo.ResumeLayout(false);
            this.tabHopDong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartHopDong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTrinhDo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Systems.Controls.lbtControl lblSize;
        private Systems.Controls.btControl btTag_List;
        private Systems.Controls.btControl btMa_Bp_Tag;
        private Systems.Controls.btControl btMa_Kv_Tag;
        private Systems.Controls.lblControl lblControl8;
        private Systems.Controls.lblControl lblControl7;
        private Systems.Controls.lblControl lblControl6;
        private Systems.Controls.txtTextBox txtTag_List;
        private Systems.Controls.txtTextBox txtMa_Bp_List;
        private Systems.Controls.txtTextBox txtMa_Kv_List;
        private Systems.Controls.btControl btLoadData;
        private Systems.Customizes.tbTabcontrol tbTabcontrol1;
        private System.Windows.Forms.TabControl TabReport;
        private System.Windows.Forms.TabPage tabPhongBan;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabPage tabVitri;
        private System.Windows.Forms.TabPage tabGioitinh;
        private System.Windows.Forms.TabPage tabTrinhDo;
        private System.Windows.Forms.TabPage tabHopDong;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartKV;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartPhongBan;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartViTri;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGioiTinh;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHopDong;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTrinhDo;
    }
}