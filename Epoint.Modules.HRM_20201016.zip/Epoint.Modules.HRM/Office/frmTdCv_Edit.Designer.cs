namespace Epoint.Modules.HRM
{
	partial class frmTdCv_Edit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.tabEdit.SuspendLayout();
            this.Page2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btgAccept
            // 
            this.btgAccept.Location = new System.Drawing.Point(398, 284);
            this.btgAccept.Size = new System.Drawing.Size(168, 33);
            // 
            // tabEdit
            // 
            this.tabEdit.Size = new System.Drawing.Size(570, 261);
            // 
            // Page1
            // 
            this.Page1.Size = new System.Drawing.Size(562, 235);
            // 
            // Page2
            // 
            this.Page2.Size = new System.Drawing.Size(562, 237);
            // 
            // frmTdCv_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 328);
            this.Name = "frmTdCv_Edit";
            this.Tag = "frmTdCv, ESC";
            this.Text = "frmTdCv";
            this.tabEdit.ResumeLayout(false);
            this.Page2.ResumeLayout(false);
            this.Page2.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

	}
}