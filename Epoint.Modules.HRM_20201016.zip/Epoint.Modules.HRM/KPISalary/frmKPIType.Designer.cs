namespace Epoint.Modules.KPI
{
    partial class frmKPIType
    {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKPIType));
            this.pnlControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splControl1)).BeginInit();
            this.splControl1.Panel2.SuspendLayout();
            this.splControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splControl1
            // 
            this.splControl1.Size = new System.Drawing.Size(792, 569);
            this.splControl1.SplitterDistance = 508;
            // 
            // frmKPIType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 607);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmKPIType";
            this.Object_ID = "KPITYPE";
            this.Tag = "frmKPITYPE";
            this.Text = "frmKPITYPE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlControl2.ResumeLayout(false);
            this.splControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splControl1)).EndInit();
            this.splControl1.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion


	}
}